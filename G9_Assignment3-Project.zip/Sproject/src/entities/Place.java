package entities;

import java.io.Serializable;
import java.sql.Time;
/**
 * The entity class that stores places.
 * @author Soaad
 *
 */
public class Place implements Serializable {

	private String LocName;
	private String LocType;
	private String LocDescription;
	private boolean accessible;
	private String SumRecommendedTime;
	private String CityName;
	
	/**
	 * a 5-argument constructor
	 * @param name
	 * @param type
	 * @param description
	 * @param accessible
	 * @param time of Visit
	 */
	public Place(String name,String type,String description,boolean accessible,String timeOfVisit)
	{
		LocName=name;
		LocType=type;
		LocDescription=description;
		this.accessible=accessible;
		SumRecommendedTime=timeOfVisit;
	}
	public Place() {
		// TODO Auto-generated constructor stub
	}
	public String getLocName() {
		return LocName;
	}
	public void setLocName(String locName) {
		LocName = locName;
	}
	public String getLocType() {
		return LocType;
	}
	public void setLocType(String locType) {
		LocType = locType;
	}
	public String getLocDescription() {
		return LocDescription;
	}
	public void setLocDescription(String locDescription) {
		LocDescription = locDescription;
	}
	public String getSumRecommendedTime() {
		return SumRecommendedTime;
	}
	public void setSumRecommendedTime(String sumRecommendedTime) {
		SumRecommendedTime = sumRecommendedTime;
	}
	public boolean getSpecial() {
		return accessible;
	}
	public void setSpecial(boolean special) {
		this.accessible = special;
	}
	

	public String getCityName() {
		return CityName;
	}
	public void setCityName(String cityName) {
		CityName = cityName;
	}
	
}
