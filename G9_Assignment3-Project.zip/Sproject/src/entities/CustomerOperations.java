package entities;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * The entity class that stores customer operations.
 * @author Soaad
 *
 */
public class CustomerOperations implements Serializable {

	private ArrayList<String> CityName;
	
	public ArrayList<String> getCityName() {
		return CityName;
	}

	public void setCityName(String cityName) {
		CityName.add(cityName);
	}

	public ArrayList<String> getDateOfPurchase() {
		return DateOfPurchase;
	}

	public void setDateOfPurchase(String dateOfPurchase) {
		DateOfPurchase.add(dateOfPurchase);
	}

	public ArrayList<String> getType() {
		return Type;
	}

	public void setType(String type) {
		Type.add(type);
	}

	private ArrayList<String> DateOfPurchase;
	private ArrayList<String> Type;

	/**
	 * an argument-less constructor
	 */
	public CustomerOperations()
	{
		CityName= new ArrayList<String>();
		DateOfPurchase= new ArrayList<String>();
		Type= new ArrayList<String>();
	}
}
