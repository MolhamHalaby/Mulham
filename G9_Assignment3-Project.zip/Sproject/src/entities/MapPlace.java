package entities;

import java.io.Serializable;
/**
 * The entity class that stores the places that appears in one map
 * @author Sahar
 *
 */
public class MapPlace implements Serializable {
 
	private String PlaceName;
	private double corX;
	private double corY;
	private String MapName;
    private String cityName;

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	/**
	 * a 2-argument constructor
	 * @param name
	 * @param x coordinate
	 * @param y coordinate
	 */
	public MapPlace(String name,double x,double y)
	{
		this.PlaceName=name;
		this.corX=x;
		this.corY=y;	
	}

	public String getPlaceName() {
		return PlaceName;
	}

	public void setPlaceName(String placeName) {
		PlaceName = placeName;
	}

	public double getCorX() {
		return corX;
	}

	public void setCorX(double corX) {
		this.corX = corX;
	}

	public double getCorY() {
		return corY;
	}

	public void setCorY(double corY) {
		this.corY = corY;
	}
	public String getMapName() {
		return MapName;
	}

	public void setMapName(String mapName) {
		MapName = mapName;
	}
	 
	
	
	
	
}
