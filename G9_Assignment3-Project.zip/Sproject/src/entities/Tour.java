package entities;

import java.io.Serializable;
import java.sql.Time;
import java.util.ArrayList;
/**
 * The entity class that stores Tour.
 * @author Soaad
 *
 */

public class Tour implements  Serializable {
	private String TourName;
	private String TourDescription;
	private ArrayList<String> Locations;
	private String SumRecommendedTime;
	private String CityName;
	
	
	public String getCityName() {
		return CityName;
	}



	public void setCityName(String cityName) {
		CityName = cityName;
	}


	/**
	 * a 3-argument constructor
	 * @param name
	 * @param description
	 * @param time
	 */
	public Tour(String name,String description,String time)
	{
		TourName=name;
		TourDescription=description;
		SumRecommendedTime=time;
		Locations= new ArrayList<String>();
		
	}
	
	

	public String getTourName() {
		return TourName;
	}

	public void setTourName(String tourName) {
		TourName = tourName;
	}

	public String getTourDescription() {
		return TourDescription;
	}

	public void setTourDescription(String tourDescription) {
		TourDescription = tourDescription;
	}

	public ArrayList<String> getLocations() {
		return Locations;
	}

	public void setLocations(ArrayList<String> locations) {
		Locations = locations;
	}

	public Time getRecommendedTime() {
		return getRecommendedTime();
	}
	
	public void setRecommendedTime(String recommendedTime) {
		SumRecommendedTime = recommendedTime;
	}

	public String getSumRecommendedTime() {
		return SumRecommendedTime;
	}

	public void setSumRecommendedTime(String sumRecommendedTime) {
		SumRecommendedTime = sumRecommendedTime;
	}

	
	
	
	
	
	
	
}
