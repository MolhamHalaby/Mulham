package entities;

public class Report {

}
