package entities;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * The entity class that stores cities reports according to period.
 * @author Soaad
 *
 */

public class timedCityReport implements Serializable{
  
	
	public timedCityReport(){
	 cityname=new ArrayList<String>();
	 Datestr=new ArrayList<String>();
	 NumOfMaps=new ArrayList<Integer>();
	 NumOfPurchases=new ArrayList<Integer>();
	 NumOfSubscriptions=new ArrayList<Integer>();
	 NumOfRenewals=new ArrayList<Integer>();
	 NumOfViews=new ArrayList<Integer>();
	 NumOfDownloads=new ArrayList<Integer>();

	}
	public ArrayList<String> cityname,Datestr;
	public ArrayList<Integer> NumOfMaps, NumOfPurchases, NumOfSubscriptions, NumOfRenewals, NumOfViews, NumOfDownloads;
	
}
