package entities;

import java.io.Serializable;
import java.sql.Blob;
import java.util.ArrayList;
/**
 * The entity class that stores Download maps.
 * @author Soaad
 *
 */
public class DownloadMap implements Serializable {

	
	ArrayList<byte[]> images;
	ArrayList<String> textfilestrings;
	ArrayList<String> mapsnames;
	public ArrayList<byte[]> getImages() {
		return images;
	}

	public void setImages(byte[] image) {
		this.images.add(image);
	}

	public ArrayList<String> getTextfilestrings() {
		return textfilestrings;
	}

	public void setTextfilestrings(String textfilestring) {
		this.textfilestrings.add(textfilestring);
	}
	/**
	 * an argument-less constructor
	 */
	public DownloadMap()
	{
		images= new ArrayList<byte[]>();
		textfilestrings = new ArrayList<String>();
	     mapsnames=new ArrayList<String>();
		}

	public ArrayList<String> getMapsnames() {
		return mapsnames;
	}

	public void setMapsnames(String mapsname) {
		this.mapsnames.add(mapsname);
	}
}
