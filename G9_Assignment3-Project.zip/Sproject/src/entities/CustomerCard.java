package entities;

import java.util.ArrayList;
/**
 * The entity class that stores subscriptions.
 * @author Sahar
 *
 */

public class CustomerCard {

	
	private Subscription subscriptions;

	public Subscription getSubscriptions() {
		return subscriptions;
	}

	public void setSubscriptions(Subscription subscriptions) {
		this.subscriptions = subscriptions;
	}
}


	

