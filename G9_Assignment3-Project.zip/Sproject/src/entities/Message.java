package entities;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
/**
 * The entity class that stores messages
 * @author Sahar
 *
 */
public class Message implements Serializable{
	
	public String rtnMessage;
	public String rtnTitle;
	public String rtnSender;
	public String rtnReceiver;
	public LocalDate rtnDate;
	
	public LocalDate getRtnDate() {
		return rtnDate;
	}

	public void setRtnDate(LocalDate rtnNum) {
		this.rtnDate = rtnNum;
	}
	public ArrayList<String> messages=new ArrayList<String>();
	public ArrayList<String> titles=new ArrayList<String>();
	public ArrayList<String> senders=new ArrayList<String>();
	public ArrayList<String> receivers=new ArrayList<String>();
	public ArrayList<String> dateOfMessage=new ArrayList<String>();
	
	public String getRtnMessage() {
		return rtnMessage;
	}
	
	public  ArrayList<String> getdateOfMessage() {
		return dateOfMessage;
	}
	public void setdateOfMessage(String numOfMessage) {
		this.dateOfMessage.add(numOfMessage);
	}
	public void setRtnMessage(String rtnMessage) {
		this.rtnMessage = rtnMessage;
	}
	public String getRtnTitle() {
		return rtnTitle;
	}
	public void setRtnTitle(String rtnTitle) {
		this.rtnTitle = rtnTitle;
	}
	public String getRtnSender() {
		return rtnSender;
	}
	public void setRtnSender(String rtnSender) {
		this.rtnSender = rtnSender;
	}
	public String getRtnReceiver() {
		return rtnReceiver;
	}
	public void setRtnReceiver(String rtnReceiver) {
		this.rtnReceiver = rtnReceiver;
	}
	
	public ArrayList<String> getSenders() {
		return senders;
	}
	public void setSenders(String senders) {
		this.senders.add(senders);
	}
	public ArrayList<String> getReceivers() {
		return receivers;
	}
	public void setReceivers(String receivers) {
		this.receivers.add(receivers);
	}
	
	public void setTitles(String titles) {
		this.titles.add(titles);
	}
	
	
	public ArrayList<String> getMessages() {
		return messages;
	}
	public void setMessages(String messages) {
		this.messages.add(messages);
	}
	public ArrayList<String> getTitles() {
		return titles;
	}
	
}
