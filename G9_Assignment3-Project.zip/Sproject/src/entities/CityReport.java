package entities;
/**
 * The entity class that stores Cities reports.
 * @author Sahar
 *
 */
public class CityReport {

	public String cityname,Datestr;
	public int NumOfMaps, NumOfPurchases, NumOfSubscriptions, NumOfRenewals, NumOfViews, NumOfDownloads, currentdate;
	
}
