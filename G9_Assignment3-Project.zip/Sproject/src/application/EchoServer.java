package application;

import java.io.*;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;

import javax.management.relation.Role;


import Controller.CityController;

import com.mysql.cj.protocol.a.MysqlBinaryValueDecoder;

import entities.City;
import entities.CityReport;
import entities.Customer;
import entities.CustomerOperations;
import entities.Map;
import entities.MapPlace;
import entities.Message;
import entities.Place;
import entities.Purchase;
import entities.Tour;
import entities.DownloadMap;
import entities.timedCityReport;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import ocsf.server.*;
/**
 * this class is responsible for running all sql queries working as a connector between the database and the client
 * @author whole group
 *
 */
public class EchoServer extends AbstractServer 
{
	final public static int DEFAULT_PORT = 5555;
	static Connection con1;
	ResultSet rs;
	Statement stmt;

	////////////////////////////////////////Constructor////////////////////////////////////////////////

	public EchoServer(int port) 
	{
		super(port);
//new Thread(new dailyCityreportUpdate()).start();
		}


	///////////////////////////////////HandleMessageFromClient//////////////////////////////////////
	public void handleMessageFromClient(Object obj, ConnectionToClient client)
	{
		if(obj instanceof Customer)
		{
			AddCustomer(obj);
		}
		else if(obj instanceof City)
		{
			try {
				AddCity(obj);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(obj instanceof Place)
		{
			AddPlace(obj);
		}

		else if(obj instanceof Purchase)//ADDED 18.6 1:42 AM BY ANAN
		{
			if(((Purchase) obj).getPurchaseType().equals("OneTime"))
			{
				try {
					AddOneTimePurchase(obj,client);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(((Purchase) obj).getPurchaseType().equals("subscription") || ((Purchase) obj).getPurchaseType().equals("renew"))
			{
				try {
					AddSubscription(obj,client);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		else if(obj instanceof Tour)
		{
			AddTour(obj);
		}


		else if(obj instanceof Message) // new eyal
		{
			AddMessage(obj);
		}
		else if(obj instanceof MapPlace)   
		{
			UpdatePlaceCordinates(obj);
		}

		else if(obj instanceof ArrayList<?>)
		{
			if(((ArrayList<String>)obj).get(0) instanceof String)
			{
				if(((ArrayList<String>)obj).get(0).equals("GetPlacesNames"))
				{
					try {
						GetPlacesList(obj,client);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(((ArrayList<String>)obj).get(0).equals("getprice"))
				{		
						try {
							getprice(obj,client);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}//0 get price 1 city 2 id
				}
				else if(((ArrayList<String>)obj).get(0).equals("DeletePlace"))   /////////new molham
				{
					DeletePlace(obj);

				}
				else if(((ArrayList<String>)obj).get(0).equals("customersemails"))   /////////new molham
				{
					try {
						getallcustomersemails(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

				else if(((ArrayList<String>)obj).get(0).equals("contentmanagermail"))   /////////266
				{
					try {
						getcontentmanageremail(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("employeesmails"))   /////////new molham
				{
					try {
						getallemployeesemails(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("DeleteTour"))   /////////new molham
				{
					DeleteTour(obj);

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetPlacesForThisCity"))
				{

					GetPlacesForThisCity(obj,client);
				}

				else if(((ArrayList<String>)obj).get(0).equals("UpdateDescriptionToMap"))
				{

					UpdateDescriptionToMap(obj);


				}
				else if (((ArrayList<String>)obj).get(0).equals("AddViewers")) {// new eyal
					AddViewers(obj,client);
				}

				else if (((ArrayList<String>)obj).get(0).equals("addtocityprice")) {// 266
					try {
						addtocityprice(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if (((ArrayList<String>)obj).get(0).equals("getfromcityprice")) {// 266
					try {
						getfromcityprice(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				else if(((ArrayList<String>)obj).get(0).equals("DownloadMap"))
				{
					try {
						DownloadMap(obj,client);
					} catch (SQLException | IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetDescription"))
				{
					GetDescription(obj,client);

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetRequestsForList"))
				{
					try {
						getrequests(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("LogOutClient"))
				{
					try {
						LogOutClient(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetCityReport"))
				{
					try {
						GetCityReport(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(((ArrayList<String>)obj).get(0).equals("GetCityNames"))
				{
					try {

						GetCityList(obj, client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetMapsForList"))
				{

					GetMapList(obj, client); 

				}
				else if(((ArrayList<String>)obj).get(0).equals("ReleaseVersion"))
				{

					try {
						ReleaseNewVersion(obj, client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 

				}
				else if(((ArrayList<String>)obj).get(0).equals("AcceptPrice"))
				{

					try {
						AcceptPrice(obj, client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetplacesForList"))
				{	 
					try {
						GetPlacesForCatalogList(obj, client);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 			 
				}
				else if(((ArrayList<String>)obj).get(0).equals("GetplacesWithCordinatesForList"))  //new
				{

					GetPlacesWithCordinates(obj, client); 	

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetMapsForCatalogList"))
				{
					try {
						GetMapsForCatalogSearch(obj, client);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 	

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetCityForCatalogList"))
				{
					GetCityForCatalogSearch(obj, client); 	

				}
				else if(((ArrayList<String>)obj).get(0).equals("DescriptionToFindMap"))
				{
					try {
						GetMapWithDescription(obj, client);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetImageForMap"))     
				{
					try {
						GetImageForMap(obj, client);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(((ArrayList<String>)obj).get(0).equals("LoginCheck"))
				{
					try {
						CheckLogin(obj,client);
					} 
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetNotRelatedMaps"))  // newwwwwwwwwwwwww eyal
				{
					try {
						GetNotRelatedMaps(obj,client);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				/*else if(((ArrayList<String>)obj).get(0).equals("getCusToAlarm"))
				{
					try {
						getCusToAlarm();
					} 
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}*/


				else if(((ArrayList<String>)obj).get(0).equals("GetUserDetails"))
				{
					getUserDetails(obj,client);
				}
				else if(((ArrayList<String>)obj).get(0).equals("GetMyCities"))
				{
					getMyCities(obj,client);
				}
				else if(((ArrayList<String>)obj).get(0).equals("GetToursForCity"))
				{
					getToursForCity(obj,client);

				}
				else if(((ArrayList<String>)obj).get(0).equals("getPlacesForTour"))
				{
					getPlacesForTour(obj,client);

				}
				else if(((ArrayList<String>)obj).get(0).equals("getTourDetails"))
				{
					getTourDetails(obj,client);

				}
				/*else if(((ArrayList<String>)obj).get(0).equals("savedailyreport"))
				{
					try {
						savedailyreport(obj,client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}*/
				else if(((ArrayList<String>)obj).get(0).equals("GetPlaceDetails"))
				{
					getPlaceDetails(obj,client);

				}
			
				else if(((ArrayList<String>)obj).get(0).equals("getCityDailyInfo"))      ///new
				{
					try {
						GetCityDailyInfo(obj, client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(((ArrayList<String>)obj).get(0).equals("GetCustomersNames"))      ///new
				{
					try {
						GetCustomersNames(obj, client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(((ArrayList<String>)obj).get(0).equals("CustomerInfo"))      ///new
				{
					try {
						GetCustomeroperations(obj, client);
					} catch (SQLException | ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(((ArrayList<String>)obj).get(0).equals("CustomerProfile"))      ///new
				{
					try {
						GetCusProfile(obj, client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if(((ArrayList<String>)obj).get(0).equals("getpureprice"))      ///new
				{
					try {
						getpureprice(obj, client);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if (((ArrayList<String>)obj).get(0).equals("GetMessages"))
				{
					try {
						GetMessages(obj,client);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else if (((ArrayList<String>)obj).get(0).equals("UpdateCityPrice"))// eyal 256
				{
					UpdateCityPrice(obj);
				}
				else if (((ArrayList<String>)obj).get(0).equals("GetBigBossID"))// eyal 256
				{
					GetBigBossID(obj, client);
				}
				else if (((ArrayList<String>)obj).get(0).equals("RequestNewVersion"))
				{
					RequestNewVersion(obj);

				}
			}
			else if((((ArrayList<Place>)obj).get(0)) instanceof Place)
			{
				UpdatePlaceDetails(obj);
			}
		}



	}

	/**
	 * this method recieves id of client after he has clicked logout, removes him from logged in list in DB
	 * @param obj recieves obj of arraylist(1)= id 
	 * @param client
	 * @throws SQLException
	 */
	private void LogOutClient(Object obj, ConnectionToClient client) throws SQLException {
		
		PreparedStatement stmt3 = con1.prepareStatement("Delete FROM loggedin Where id=?");
		stmt3.setString(1, ((ArrayList<String>)obj).get(1));
        stmt3.executeUpdate();
	}

/**
 * this method gets city name and returns the price of the city with no changes at all (pure) to be displaed
 * @param obj recieves obj of arraylist where arraylist(1)= city name
 * @param client
 * @throws SQLException
 */
	private void getpureprice(Object obj, ConnectionToClient client) throws SQLException {
		int price=0;
		ArrayList<String> pureprice=new ArrayList<String>();
		PreparedStatement stmt3 = con1.prepareStatement("SELECT Price FROM project.city Where CityName=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1));
        ResultSet rs2=stmt3.executeQuery();		
        pureprice.add("pureprice");
        if(rs2.next())
        {
        	price=rs2.getInt(1);
        }		
        String stringprice=Integer.toString(price);
        pureprice.add(stringprice);
        try {
			client.sendToClient(pureprice);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	}

	/**
	 * this method changes the city's price offically from all tables after the big boss has decided to accept the manager's change request
	 * @param obj recieves obj of arraylist where arraylist(1) = city name
	 * @param client
	 * @throws SQLException
	 */
	private void AcceptPrice(Object obj, ConnectionToClient client) throws SQLException {//266
		int price=0;
		PreparedStatement stmt3 = con1.prepareStatement("SELECT price FROM project.city_price Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1));
		ResultSet rs2=stmt3.executeQuery();		
		if(rs2.next())
		{
			price=rs2.getInt(1);
		}
		stmt3 = con1.prepareStatement("Update city SET Price=? Where CityName=?");
		stmt3.setInt(1, price);
		stmt3.setString(2,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();
		stmt3 = con1.prepareStatement("Update cityreleased SET Price=? Where CityName=?");
		stmt3.setInt(1, price);
		stmt3.setString(2,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();	
		stmt3 = con1.prepareStatement("Delete FROM city_price Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();	
	}		


/**
 * this method returns all the ids of the content managers so we can "email" them 
 * @param obj
 * @param client
 * @throws SQLException
 */
	private void getcontentmanageremail(Object obj, ConnectionToClient client) throws SQLException {
		ArrayList<String> ContentManagerEmails=new ArrayList<String>();
		ContentManagerEmails.add("ContentManagerEmails");
		PreparedStatement stmt3 = con1.prepareStatement("SELECT id FROM project.content_department_employee Where Role=?");
		stmt3.setString(1,"Manager");
		ResultSet rs2=stmt3.executeQuery();		
		while(rs2.next())
		{
			ContentManagerEmails.add(rs2.getString(1));
		}

		stmt3 = con1.prepareStatement("Delete FROM city_price Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();
		try {
			client.sendToClient(ContentManagerEmails);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

/**
 * returns the requests of city-price to be displayed to the big boss
 * @param obj
 * @param client
 * @throws SQLException
 */
	private void getfromcityprice(Object obj, ConnectionToClient client) throws SQLException {//266
		ArrayList<String> cityprices=new ArrayList<String>();
		cityprices.add("citypricelist");
		PreparedStatement stmt3 = con1.prepareStatement("SELECT city_name,price FROM project.city_price");
		ResultSet rs2=stmt3.executeQuery();		
		while(rs2.next())
		{
			cityprices.add(String.valueOf(rs2.getInt(2))+","+rs2.getString(1));
		}		
		try {
			client.sendToClient(cityprices);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

/**
 * this method adds a request to the city price table in the database (adding a city-price change request)
 * @param obj
 * @param client
 * @throws SQLException
 */
	private void addtocityprice(Object obj, ConnectionToClient client) throws SQLException {//266
		PreparedStatement stmt3 = con1.prepareStatement("Select * From project.city_price Where city_name=?");
		stmt3.setString(1, ((ArrayList<String>)obj).get(1));
		ResultSet rs2=stmt3.executeQuery();
		if(rs2.next()){
			stmt3 = con1.prepareStatement("Update project.city_price SET price=? Where city_name=?");
			stmt3.setInt(2, Integer.parseInt(((ArrayList<String>)obj).get(2)));
			stmt3.setString(2, ((ArrayList<String>)obj).get(1));
			stmt3.executeUpdate();	
		}
		else {
			stmt3 = con1.prepareStatement("INSERT INTO project.city_price Values(?,?)");
			stmt3.setString(1, ((ArrayList<String>)obj).get(1));
			stmt3.setInt(2, Integer.parseInt(((ArrayList<String>)obj).get(2)));
			stmt3.executeUpdate();		
		}
	}

/**
 * this method returns all employees ids to use for sending all employees an "email"
 * @param obj
 * @param client
 * @throws SQLException
 */
	private void getallemployeesemails(Object obj, ConnectionToClient client) throws SQLException {
		ArrayList<String> EmployeesEmails=new ArrayList<String>();
		EmployeesEmails.add("EmployeesEmails");
		PreparedStatement stmt3 = con1.prepareStatement("SELECT id FROM project.content_department_employee");
		ResultSet rs2=stmt3.executeQuery();		
		while(rs2.next())
		{
			EmployeesEmails.add(rs2.getString(1));
		}

		stmt3 = con1.prepareStatement("Delete FROM city_request Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();


		try {
			client.sendToClient(EmployeesEmails);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

/**
 * this method returns all the customers ids' to use in an emailing process to all employees (email is sent by id)
 * @param obj
 * @param client
 * @throws SQLException
 */
	private void getallcustomersemails(Object obj, ConnectionToClient client) throws SQLException {
		ArrayList<String> CustomersEmails=new ArrayList<String>();
		CustomersEmails.add("CustomersEmails");
		PreparedStatement stmt3 = con1.prepareStatement("SELECT customer_id FROM currentlyowned Where OwnedCity=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1));
		ResultSet rs2=stmt3.executeQuery();		
		while(rs2.next())
		{
			CustomersEmails.add(rs2.getString(1));
		}

		stmt3 = con1.prepareStatement("Delete FROM city_request Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();

		try {
			client.sendToClient(CustomersEmails);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

/**
 * this method is used to release a new version of a city -- transfers all data from a city in editing process to released table
 * @param obj gets arraylist holding the city name to be released in arraylist(1)
 * @param client
 * @throws SQLException
 */
	private void ReleaseNewVersion(Object obj, ConnectionToClient client) throws SQLException {   //256
		PreparedStatement stmt3 = con1.prepareStatement("Delete FROM cityreleased Where CityName=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		/////////////////deleted city
		stmt3 = con1.prepareStatement("Delete FROM mapreleased Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		/////////////////deleted all maps
		stmt3 = con1.prepareStatement("Delete FROM tourreleased Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		/////////////////deleted all tours
		stmt3 = con1.prepareStatement("Delete FROM placereleased Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		/////////////////deleted all places
		stmt3 = con1.prepareStatement("Delete FROM map_place_released Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		//////////////////deleted all map_places
		stmt3 = con1.prepareStatement("Delete FROM tour_place_released Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		///////////////// deleted all tour_places
		stmt3 = con1.prepareStatement("INSERT INTO cityreleased (CityName, VersionNo, Price) SELECT city.CityName, city.VersionNo, city.Price FROM city Where city.CityName=?;");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		////////////////////////// added confirmed city row
		stmt3 = con1.prepareStatement("INSERT INTO mapreleased (Name, Description, Price, NumberOfTours, Version, mapImage, city_name) SELECT map.Name, map.Description, map.Price, map.NumberOfTours, map.Version, map.mapImage, map.city_name FROM map Where map.city_name=?;");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		/////////////////////////// added all confirmed maps rows
		stmt3 = con1.prepareStatement("INSERT INTO tourreleased (TourName, Description, TimeOfTour, city_name) SELECT tour.TourName, tour.Description, tour.TimeOfTour, tour.city_name FROM tour Where tour.city_name=?;");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		/////////////////////////// added all confirmed tours rows
		stmt3 = con1.prepareStatement("INSERT INTO placereleased (Name,Description,Classification,Accessibility,TimeOfVisit,city_name) SELECT place.Name,place.Description,place.Classification,place.Accessibility,place.TimeOfVisit,place.city_name FROM place Where place.city_name=?;");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		////////////////////////// added confirmed placereleased rows
		stmt3 = con1.prepareStatement("INSERT INTO map_place_released (map_name, place_name, corX, corY, city_name) SELECT map_place.map_name, map_place.place_name, map_place.corX, map_place.corY,map_place.city_name FROM map_place Where map_place.city_name=?;");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		///////////////////////// update relationship table of map_place
		stmt3 = con1.prepareStatement("INSERT INTO tour_place_released (tour_name, place_name, city_name) SELECT tour_place.tour_name, tour_place.place_name, tour_place.city_name FROM tour_place Where tour_place.city_name=?;");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		stmt3.executeUpdate();
		///////////////////////// update relationship table of tour_place
		stmt3 = con1.prepareStatement("Select VersionNo From cityreleased Where CityName=?;");
		stmt3.setString(1,((ArrayList<String>)obj).get(1) );
		rs=stmt3.executeQuery();
		rs.next();
		int i=rs.getInt(1);
		stmt3 = con1.prepareStatement("UPDATE cityreleased SET VersionNo = ? Where CityName=?;");
		stmt3.setInt(1,i+1 );
		stmt3.setString(2,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();
		stmt3 = con1.prepareStatement("UPDATE city SET VersionNo = ? Where CityName=?;");
		stmt3.setInt(1,i+1 );
		stmt3.setString(2,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();
		///////////////////////// updated city version + 1
		stmt3 = con1.prepareStatement("Delete FROM city_request Where city_name=?");
		stmt3.setString(1,((ArrayList<String>)obj).get(1));
		stmt3.executeUpdate();	
	}

/**
 * this method returns all new versions requests and returns it to be displayed according to page/request
 * @param obj
 * @param client
 * @throws SQLException
 */
	private void getrequests(Object obj, ConnectionToClient client) throws SQLException {//256
		ArrayList<String> RequestsNames=new ArrayList<String>();
		RequestsNames.add("RequestsNames");
		PreparedStatement stmt3 = con1.prepareStatement("SELECT city_name FROM city_request");
		ResultSet rs2=stmt3.executeQuery();
		rs2.beforeFirst();
		while(rs2.next()) {
			RequestsNames.add(rs2.getString(1));
		}
		try {
			client.sendToClient(RequestsNames);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

/**
 * this method works as a thread -- working parrallel to the program its triggered daily and it saves the city report 
 * into a new table with the date of the day hence storing city reports by dates for further use
 * @return returns null when it's job is done for the day
 * @throws SQLException
 */
	public Runnable savedailyreport() throws SQLException {
		ArrayList<String> CityNames=new ArrayList<String>();
		while(true) {
		PreparedStatement stmt3 = con1.prepareStatement("SELECT CityReport FROM cityreport");
		ResultSet rs2=stmt3.executeQuery();
		rs2.beforeFirst();
		while(rs2.next()) {
			CityNames.add(rs2.getString(1));
			stmt3 = con1.prepareStatement("SELECT * FROM cityreport WHERE CityReport=?");
			stmt3.setString(1, CityNames.get(0));
			rs=stmt3.executeQuery();
			rs.beforeFirst();
			rs.next();
			CityReport report= new CityReport();
			report.cityname=rs.getString(1);
			report.NumOfMaps=rs.getInt(2);
			report.NumOfPurchases=rs.getInt(3);
			report.NumOfSubscriptions=rs.getInt(4);
			report.NumOfRenewals=rs.getInt(5);
			report.NumOfViews=rs.getInt(6);
			report.NumOfDownloads=rs.getInt(7);
			stmt3 = con1.prepareStatement("SELECT * FROM currentdate");	
			rs=stmt3.executeQuery();
			rs.beforeFirst();
			rs.next();
			String date=rs.getString(1);
			stmt3 = con1.prepareStatement("Delete FROM currentdate");	
			stmt3.executeUpdate();
			LocalDate locallydate;
			locallydate=LocalDate.now();
			String formattedStartDate = locallydate.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
			stmt3 = con1.prepareStatement("INSERT INTO currentdate Values(?)");
			stmt3.setString(1, formattedStartDate);
			stmt3.executeUpdate();
			PreparedStatement stmt2 = con1.prepareStatement("INSERT INTO citydailyreport Values(?,?,?,?,?,?,?,?)");
			stmt2.setString(1, report.cityname);
			stmt2.setInt(2, report.NumOfMaps);	
			stmt2.setInt(3, report.NumOfPurchases);	
			stmt2.setInt(4, report.NumOfSubscriptions);	
			stmt2.setInt(5, report.NumOfRenewals);	
			stmt2.setInt(6, report.NumOfViews);	
			stmt2.setInt(7, report.NumOfDownloads);	
			stmt2.setString(8,date);	
			stmt2.executeUpdate();
			stmt2 = con1.prepareStatement("UPDATE cityreport SET NumOfMaps=?,NumOfPurchases=?,NumOfSubscriptions=?,NumOfRenewals=?,NumOfViews=?,NumOfDownloads=? WHERE CityReport=?");
			//stmt2.setString(1, report.cityname);
			stmt2.setInt(1, 0);	
			stmt2.setInt(2, 0);	
			stmt2.setInt(3, 0);	
			stmt2.setInt(4, 0);	
			stmt2.setInt(5, 0);	
			stmt2.setInt(6, 0);		
			stmt2.setString(7, report.cityname);
			stmt2.executeUpdate();  
			CityNames.remove(0);
		}
			return null;
		}
	}

/**
 * this method works in building the downloading process for the customer - it builds an entity holding bytes array of the maps
 * of the city to be downloaded along with building text files to be downloaded for the customer
 * @param obj recieves an arraylist with the city to download name in arraylist(1)
 * @param client
 * @throws SQLException
 * @throws IOException
 */
	private void DownloadMap(Object obj, ConnectionToClient client) throws SQLException, IOException {
		PreparedStatement stmt50 = con1.prepareStatement("SELECT NumOfDownloads FROM cityreport WHERE CityReport=?");
		stmt50.setString(1, ((ArrayList<String>)obj).get(1));	
		rs=stmt50.executeQuery();
		rs.beforeFirst();
		rs.next();
		PreparedStatement stmt44 = con1.prepareStatement("UPDATE cityreport SET NumOfDownloads=? WHERE CityReport=?");
		stmt44.setString(2, ((ArrayList<String>)obj).get(1));
		stmt44.setInt(1, rs.getInt(1)+1);
		stmt44.executeUpdate();
		ArrayList<String> placesinfo=new ArrayList<String>();
		PreparedStatement stmt3 = con1.prepareStatement("SELECT mapImage,Name FROM mapreleased WHERE city_name=?");
		stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
		rs = stmt3.executeQuery();
		DownloadMap transfermaps = new DownloadMap();
		rs.beforeFirst();
		while(rs.next()) {
			Blob b=rs.getBlob(1);
			String mapname;
			mapname=rs.getString(2);
			transfermaps.setMapsnames(mapname);
			byte barr[]=new byte[(int)b.length()];
			barr=b.getBytes(1,(int)b.length());	
			transfermaps.setImages(barr);
			PreparedStatement stmt2 = con1.prepareStatement("SELECT place_name FROM map_place_released WHERE map_name =?");
			stmt2.setString(1,mapname);	
			ResultSet rs2 = stmt2.executeQuery();
			while(rs2.next())
			{
				String placename;
				placename=rs2.getString(1);
				PreparedStatement stmt4 = con1.prepareStatement("SELECT Name,Description,Classification,Accessibility,TimeOfVisit FROM project.placereleased WHERE Name=?;");
				stmt4.setString(1,placename);	
				ResultSet rs3 = stmt4.executeQuery();
				if(rs3.next())
				{			
					transfermaps.setTextfilestrings("PlaceName: " + rs3.getString(1) + " " + "Description: " + rs3.getString(2) + " " + "Classification: " + rs3.getString(3) + " " + "Accessibility: " +
							((rs3.getBoolean(4)==true)? "yes":"no") + " " + "TimeOfVisit: " + rs3.getString(5));
				}
			}
			
		}
		client.sendToClient(transfermaps);

	}

	////////////////////////////////////Returns to Client////////////////////////////////////////////

/**
 * this method is used to aquire the big boss's id for emailing or other purposes
 * @param obj
 * @param client
 */
	private void GetBigBossID(Object obj, ConnectionToClient client) // eyal 256
	{  

		ResultSet rs12;
		String sql = "SELECT id FROM project.content_department_employee WHERE Role = 'Big Boss';"; // new eyal 256

		try {
			PreparedStatement stmt = con1.prepareStatement(sql);
			rs12 = stmt.executeQuery();
			rs12.beforeFirst();
			rs12.next();

			ArrayList<String> rtn = new ArrayList<String>();
			rtn.add("GetBigBossID");
			rtn.add(rs12.getString(1));
			client.sendToClient(rtn);
		}
		catch(Exception e){
			e.printStackTrace();
		}


	}
/**
 * this method is used to get a certain selected place's details and returns it to be displayed according to a client's request
 * @param obj recieves an arraylist holding the place's name in arraylist(1)
 * @param client
 */
	private void getPlaceDetails(Object obj, ConnectionToClient client)      ////256
	{
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT * FROM project.placereleased WHERE Name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();

				while(rs.next())
				{
					Place details=new Place(rs.getString(1),rs.getString(3),rs.getString(2),rs.getBoolean(4),rs.getString(5));
					client.sendToClient(details);
				}


			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT * FROM project.place WHERE Name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();

				while(rs.next())
				{
					Place details=new Place(rs.getString(1),rs.getString(3),rs.getString(2),rs.getBoolean(4),rs.getString(5));
					client.sendToClient(details);
				}


			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

	}

/**
 * this method returns the price to be displayed to a customer purchasing a city - it also returns if the price will involve
 * a discount (incase he is renewing a subscription)
 * @param obj recieves an arraylist holding city name in arraylist(1) and customer id in arraylist(2)
 * @param client
 * @throws SQLException
 */
	private void getprice(Object obj, ConnectionToClient client) throws SQLException {
		ResultSet rs2;
		String sql = "SELECT Price FROM cityreleased WHERE CityName = ?";
		String sql2 = "SELECT * FROM currentlyowned WHERE customer_id=? and OwnedCity=? ";
		try {
			
			PreparedStatement stmt3 = con1.prepareStatement(sql);
			stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
			rs = stmt3.executeQuery();
			ArrayList<String> Price=new ArrayList<String>();
			rs.beforeFirst();
			rs.next();
			Price.add("CityPrice");
			Price.add(String.valueOf(rs.getInt(1)));
			PreparedStatement stmt2 = con1.prepareStatement(sql2);
			stmt2.setString(1, ((ArrayList<String>)obj).get(2));
			stmt2.setString(2,((ArrayList<String>)obj).get(1) );
			rs2 = stmt2.executeQuery();
			rs2.beforeFirst();
			rs2.beforeFirst();
			if(!rs2.next())
			{
				Price.add("nodiscount");
				client.sendToClient(Price);
			}
			else
			{
				Price.add("discountYes");
				client.sendToClient(Price);
			}




		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
	/**
	 * this method is used to aquire a customer's profile in order to be displayed in a certain page 
	 * @param obj recieves an arraylist holding the customer's id in arraylist(1)
	 * @param client
	 * @throws SQLException
	 */
	private void GetCusProfile(Object obj, ConnectionToClient client) throws SQLException {
		String sql = "SELECT firstname,lastname,PhoneNumber,mail,id,password FROM customer Where id=?";
		PreparedStatement stmt3 = con1.prepareStatement(sql);
		stmt3.setString(1, ((ArrayList<String>)obj).get(1));
		rs = stmt3.executeQuery();
		Customer cus=new Customer();
		int i=1;
		rs.next();
		cus.setFirstName(rs.getString(i));
		i++;
		cus.setLastName(rs.getString(i));
		i++;
		cus.setMobileNum(rs.getString(i));
		i++;
		cus.seteMail(rs.getString(i));
		i++;
		cus.setID(rs.getString(i));
		i++;
		cus.setPassword(rs.getString(i));
		try {
			client.sendToClient(cus);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	/**
	 * this method is used to acquire all customer's operations - it works by selecting all his operations from a view built 
	 * in the DB -- it returns all subscriptions and one time purchases he has ever done including the date of the operation
	 * @param obj receives an arraylist holding the customer's id in it in arraylist(1)
	 * @param client
	 * @throws SQLException
	 * @throws ParseException
	 */
	private void GetCustomeroperations(Object obj, ConnectionToClient client) throws SQLException, ParseException {
		// TODO Auto-generated method stub
		String sql2 = "SELECT subscription_city,PurchaseDate FROM allcustomersubscriptions WHERE customer_id=?;";
		String sql = "SELECT CityName,DateOfPurchase FROM allcustomeronetime WHERE customer_id=?;";
		PreparedStatement stmt3 = con1.prepareStatement(sql);
		stmt3.setString(1, ((ArrayList<String>)obj).get(1));
		rs = stmt3.executeQuery();
		CustomerOperations Operations=new CustomerOperations();
		while(rs.next()) {
			Operations.setCityName(rs.getString(1));
			Operations.setDateOfPurchase(rs.getString(2));
			Operations.setType("OneTime");
		}
		ResultSet rs2;
		PreparedStatement stmt2 = con1.prepareStatement(sql2);
		stmt2.setString(1, ((ArrayList<String>)obj).get(1));
		rs2 = stmt2.executeQuery();
		while(rs2.next())
		{
			Operations.setCityName(rs2.getString(1));
			Operations.setDateOfPurchase(rs2.getString(2));
			Operations.setType("Subscription");
		}
		try {
			client.sendToClient(Operations);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

/**
 * this method returns all customer's names and ids in the DB to be displayed in a combobox or a list according to page's request
 * @param obj
 * @param client
 * @throws SQLException
 */
	private void GetCustomersNames(Object obj, ConnectionToClient client) throws SQLException {
		// TODO Auto-generated method stub
		String sql = "SELECT firstname,id FROM customer";
		PreparedStatement stmt3 = con1.prepareStatement(sql);
		rs = stmt3.executeQuery();
		ArrayList<String> namesids=new ArrayList<String>();
		namesids.add("GetCustomersNames");
		while(rs.next()) {
			namesids.add(rs.getString(1)+","+rs.getString(2));
		}
		try {
			client.sendToClient(namesids);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

/**
 * this method is used to acquire daily info about the city the info contains total amount of purchases - amount of subscriptions
 * and amount of one time purchases for a certain city 
 * @param obj receieves an arraylist containing city name in the index 1 slot
 * @param client
 * @throws SQLException
 */
	private void GetCityDailyInfo(Object obj, ConnectionToClient client) throws SQLException {
		String sql = "SELECT COUNT(*) FROM subscriptiontoday WHERE subscription_city=?;";//the query to be executed in the next method 
		ResultSet rs2;
		PreparedStatement stmt3 = con1.prepareStatement(sql);
		stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
		rs = stmt3.executeQuery();
		ArrayList<String> DailyInfo=new ArrayList<String>();
		DailyInfo.add("DailyInfo");
		rs.next();
		int subs=rs.getInt(1);
		DailyInfo.add(Integer.toString(subs));
		String sql2 = "SELECT COUNT(*) FROM onetimetoday WHERE CityName=?;";//the query to be executed in the next method 
		PreparedStatement stmt2 = con1.prepareStatement(sql2);
		stmt2.setString(1, ((ArrayList<String>)obj).get(1));	
		rs2 = stmt2.executeQuery();
		rs2.next();
		int onetime=rs2.getInt(1);
		DailyInfo.add(Integer.toString(onetime));
		int total=onetime+subs;
		DailyInfo.add(Integer.toString(total));
		try {
			client.sendToClient(DailyInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
/**
 * this method returns all places names for a certain city 
 * @param obj receieves arraylist containing city name in the first index slot
 * @param client
 */
	private void GetPlacesForThisCity(Object obj, ConnectionToClient client )                 ///256
	{
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{

			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT Name FROM project.placereleased WHERE city_name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("PlacesNames");
				while(rs.next())
				{
					names.add(rs.getString(1));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT Name FROM project.place WHERE city_name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("PlacesNames");
				while(rs.next())
				{
					names.add(rs.getString(1));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}


	}
/**
 * this method returns all stored details about a tour to be displayed according to a client's request and selection 
 * @param obj recieves an arraylist containing tour name in 1 index slot
 * @param client
 */
	private void getTourDetails(Object obj, ConnectionToClient client )     ///256
	{
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT Description,TimeOfTour FROM project.tourreleased WHERE TourName = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("TourDetails");
				while(rs.next())
				{
					names.add(rs.getString(1));
					names.add(rs.getString(2));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT Description,TimeOfTour FROM project.tour WHERE TourName = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("TourDetails");
				while(rs.next())
				{
					names.add(rs.getString(1));
					names.add(rs.getString(2));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

	}
/**
 * returns all tour names for a certain selected city to be displayed according to a client's request
 * @param obj recieves an arraylist containing city's name in index 1 of the arraylist
 * @param client
 */
	private void getToursForCity(Object obj, ConnectionToClient client)             ///256
	{//gets all city's tours names -- non duplicates -- recieves obj arraylist(1) = city name
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT DISTINCT TourName FROM project.tourreleased WHERE city_name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("ToursNames");
				while(rs.next())
				{
					names.add(rs.getString(1));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT DISTINCT TourName FROM project.tour WHERE city_name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("ToursNames");
				while(rs.next())
				{
					names.add(rs.getString(1));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

	}
/**
 * this method returns all places names that belong to a certain selected tour according to the selection and request of a client
 * @param obj recieves an arraylist which contains the tour name in index 1
 * @param client
 */
	private void getPlacesForTour(Object obj, ConnectionToClient client)     ///256
	{//gets all tour's places names -- recieves obj arraylist(1) tour name
		if( ((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT place_name FROM project.tour_place_released WHERE tour_name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("PlacesNames");
				while(rs.next())
				{
					names.add(rs.getString(1));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT place_name FROM project.tour_place WHERE tour_name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("PlacesNames");
				while(rs.next())
				{
					names.add(rs.getString(1));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}


	}
/**
 * this method returns map's description to client according to his request
 * @param obj recieves an arraylist which contain map's name in arraylist(1)
 * @param client
 */
	private void GetDescription(Object obj, ConnectionToClient client)                     /////256
	{//gets map's description according to its name , recieves obj of arraylist(1) = mapname

		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT Description FROM project.mapreleased WHERE Name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("MapDescription");
				while(rs.next())
				{
					names.add(rs.getString(1));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else
		{
			try{
				PreparedStatement stmt3 = con1.prepareStatement("SELECT Description FROM project.map WHERE Name = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
				rs = stmt3.executeQuery();
				ArrayList<String> names= new ArrayList<String>();
				names.add("MapDescription");
				while(rs.next())
				{
					names.add(rs.getString(1));

				}

				client.sendToClient(names);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}

	}
/**
 * this method returns all cities that the client currently owns (one time purchases are not included)
 * @param obj recieves an arraylist containing the customer's id in arraylist(1)
 * @param client
 */
	private void getMyCities(Object obj, ConnectionToClient client)
	{//returns to client cities names that were bought by the client according to his id
		//recieves obj of arraylist(1) = customer id
		try{
			PreparedStatement stmt3 = con1.prepareStatement("SELECT OwnedCity FROM currentlyowned WHERE customer_id = ?");
			stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
			rs = stmt3.executeQuery();
			ArrayList<String> names= new ArrayList<String>();
			names.add("CityNames");
			while(rs.next())
			{
				names.add(rs.getString(1));

			}

			client.sendToClient(names);
		}
		catch(Exception e){
			e.printStackTrace();
		}



	}
	/**
	 * this method returns all client's messages to be displayed in the messages page
	 * @param obj recieves an arraylist containing the client's id in arraylist(1)
	 * @param client
	 * @throws IOException
	 */
	private void GetMessages(Object obj,ConnectionToClient client) throws IOException{ 
		//returns all messages sent to a person according to his id
		//recieves obj of arraylist(1) = reciever id
		String dater;
		try {
			PreparedStatement stmt1=con1.prepareStatement("SELECT * FROM project.messages WHERE receiver = ?;");
			stmt1.setString(1, ((ArrayList<String>)obj).get(1));
			rs = stmt1.executeQuery();
			Message mesage = new Message();
			while(rs.next()) {

				mesage.setSenders(rs.getString(1));
				mesage.setReceivers(rs.getString(2));
				mesage.setMessages(rs.getString(3));
				mesage.setTitles(rs.getString(4));
				dater=rs.getString(5);
				//convert String to LocalDate
				mesage.setdateOfMessage(dater);

				/*
				mesage.setMessages(rs.getString(1));
				mesage.setTitles(rs.getString(2));
				mesage.setSenders(rs.getString(3));
				mesage.setReceivers(rs.getString(4));
				mesage.setNumOfMessage(rs.getInt(5));*/
			}

			client.sendToClient(mesage);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();}
	}
/**
 * this method returns a user's details for purpose of displaying it in profile page or other purposes 
 * @param obj recieves obj of arraylist(1) customer id 
 * @param client
 */
	private void getUserDetails(Object obj, ConnectionToClient client)
	{//gets user details from DB according to id and returns it to be displayed by client
		Customer details;
		try{
			PreparedStatement stmt3 = con1.prepareStatement("SELECT * FROM customer WHERE id = ?");
			stmt3.setString(1, ((ArrayList<String>)obj).get(1));	
			rs = stmt3.executeQuery();
			while(rs.next())
			{
				details=new Customer(rs.getString(6),rs.getString(1),rs.getString(2),rs.getString(4),rs.getString(3),rs.getString(7),rs.getString(5));
				client.sendToClient(details);
			}


		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
	/**
	 * this method triggers a thread - CusToAlarm method
	 * @return returns null when it's job is done for the day
	 * @throws SQLException
	 */
	private void threadsrunner()
	{
		try {
			new Thread(getCusToAlarm()).start();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	/**
	 * this method triggers another thread - savedailyreport method
	 * @return returns null when it's job is done for the day
	 * @throws SQLException
	 */
	private void threadsrunner2()
	{
		try {
			new Thread(savedailyreport()).start();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	/**
	 * this method is used to check if the logger's id and password are entered correctly according to the information in the 
	 * Database and also checks the type of the logger returning it so different autherization could be given to him according
	 * to his role. 
	 * @param obj recieves an arraylist containing arraylist(1) = id and arraylist(2) = password
	 * @param client
	 * @throws SQLException
	 */
	private void CheckLogin(Object obj, ConnectionToClient client) throws SQLException
	{//checks if user id and password are correct and returns answer to client to deal with accordingly
		String role;
		String sql = "SELECT * FROM customer WHERE id = ? and password = ?";
		try{
			PreparedStatement stmt3 = con1.prepareStatement(sql);
			stmt3.setString(1, ((ArrayList<String>)obj).get(1));
			stmt3.setString(2, ((ArrayList<String>)obj).get(2));
			rs = stmt3.executeQuery();
			ArrayList<String> answer=new ArrayList<String>();
			answer.add("LoginAnswer");
			rs.beforeFirst();
			rs.beforeFirst();
			if(!rs.next())
			{
				answer.add("LogFailed");
				client.sendToClient(answer);
			}
			else
			{	
				stmt3 = con1.prepareStatement("SELECT * FROM loggedin  WHERE id = ?");
				stmt3.setString(1, ((ArrayList<String>)obj).get(1));
				rs = stmt3.executeQuery();
				rs.beforeFirst();
				if(rs.next())
				{
					answer.add("LoginAnswer");
					answer.add("LogFailed");
					client.sendToClient(answer);

				}
				else {
					stmt3 = con1.prepareStatement("INSERT INTO loggedin Values(?)");
					stmt3.setString(1, ((ArrayList<String>)obj).get(1));
					stmt3.executeUpdate();
				String sql2 = "SELECT * FROM content_department_employee WHERE id = ?";
				PreparedStatement stmt4 = con1.prepareStatement(sql2);
				stmt4.setString(1, ((ArrayList<String>)obj).get(1)); 
				rs = stmt4.executeQuery();
				ArrayList<String> answer2=new ArrayList<String>();
				answer2.add("LoginAnswer");
				if(rs.next())
				{
					role=rs.getString(5);
					if(role.equals("Employee"))
					{
						answer2.add("LogEmployee");
					}
					else if(role.equals("Manager"))
					{
						answer2.add("Manager");
					}
					else if(role.equals("Big Boss"))
					{
						answer2.add("Big Boss");
					}
					client.sendToClient(answer2);

				}
				else
				{

					answer2.add("LogCustomer");
					client.sendToClient(answer2);
				}
			}
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
/**
 * this method works in getting an image of a map out of the DB to be displayed to the client according to a request
 * it returns the image in a file to the client and from there its dealt with accordingly
 * @param obj recieves an arraylist , the map's name in arraylist(1)
 * @param client
 * @throws IOException
 */
	private void GetImageForMap(Object obj,ConnectionToClient client) throws IOException    ////256
	{//gets image from DB to be displayed according to map name - obj -> arraylist(1) = Name
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			File file=null;
			MyFile msg;
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT mapImage FROM project.mapreleased WHERE Name=?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();

				if(rs.next())
				{
					InputStream input= rs.getBinaryStream(1);
					byte[] buffer= new byte[1024]; 	 
					file=new File("src\\Img\\k.jpg");
					OutputStream output= new FileOutputStream(file);
					int size=0;
					while((size=input.read(buffer))!=-1)
					{
						output.write(buffer, 0, size);
					}
					msg=new MyFile("k.jpg");
					FileInputStream fis = new FileInputStream(file);
					byte[] bufferPic= new byte[(int)file.length()]; 
					BufferedInputStream bis = new BufferedInputStream(fis);	
					msg.initArray(bufferPic.length);
					msg.setSize(bufferPic.length);
					bis.read(msg.getMybytearray(),0,bufferPic.length);

					try {

						client.sendToClient(msg);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			File file=null;
			MyFile msg;
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT mapImage FROM project.map WHERE Name=?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();

				if(rs.next())
				{
					InputStream input= rs.getBinaryStream(1);
					byte[] buffer= new byte[1024]; 	 
					file=new File("src\\Img\\k.jpg");
					OutputStream output= new FileOutputStream(file);
					int size=0;
					while((size=input.read(buffer))!=-1)
					{
						output.write(buffer, 0, size);
					}
					msg=new MyFile("k.jpg");
					FileInputStream fis = new FileInputStream(file);
					byte[] bufferPic= new byte[(int)file.length()]; 
					BufferedInputStream bis = new BufferedInputStream(fis);	
					msg.initArray(bufferPic.length);
					msg.setSize(bufferPic.length);
					bis.read(msg.getMybytearray(),0,bufferPic.length);

					try {

						client.sendToClient(msg);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}




	}
	/**
	 * this method returns all maps names and desciptions to be displayed in the city's page 
	 * @param obj 
	 * @param client
	 * @throws IOException
	 */
	private void GetMapWithDescription(Object obj,ConnectionToClient client) throws IOException          ////256
	{//gets map's names and descriptions to return to client
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT Description,Name FROM project.mapreleased");
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				ArrayList<String> descriptions= new ArrayList<String>();
				//names.add("MapsNames");//return the job name so we continue working right
				while(rs.next()) {
					descriptions.add(rs.getString(1));
				}
				names.add("MapsNames");
				rs.beforeFirst();
				for(int i=1;i<=descriptions.size();i++)
				{
					if((descriptions.get(i-1).contains(((ArrayList<String>)obj).get(1))))
					{
						rs.next();
						names.add(rs.getString(2)); 

					}
				}
				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT Description,Name FROM project.map");
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				ArrayList<String> descriptions= new ArrayList<String>();
				//names.add("MapsNames");//return the job name so we continue working right
				while(rs.next()) {
					descriptions.add(rs.getString(1));
				}
				names.add("MapsNames");
				rs.beforeFirst();
				for(int i=1;i<=descriptions.size();i++)
				{
					if((descriptions.get(i-1).contains(((ArrayList<String>)obj).get(1))))
					{
						rs.next();
						names.add(rs.getString(2)); 

					}
				}
				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}




	}
/**
 * this method returns all maps according to his selection in the catalog search - in this case place_name
 * @param obj recieves place name in arraylist(1)
 * @param client
 * @throws IOException
 */
	private void GetMapsForCatalogSearch(Object obj,ConnectionToClient client) throws IOException          ///256
	{
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT map_name FROM project.map_place_released WHERE place_name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("MapsNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));
				}
				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT map_name FROM project.map_place WHERE place_name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("MapsNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));
				}
				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}



	}
	/**
	 * this method returns all maps's city names according to his selection in the catalog search - in this case map_name
	 * @param obj recieves map name in arraylist(1)
	 * @param client
	 * @throws IOException
	 */
	private void GetCityForCatalogSearch(Object obj,ConnectionToClient client)                         ////256
	{//gets map's city names and returns them to client, recieves obj of arraylist(1)= map name

		if(((ArrayList<String>)obj).get(1).equals("Customer"))
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT city_name FROM project.mapreleased WHERE Name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("CityNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));
				}
				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT city_name FROM project.map WHERE Name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("CityNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));
				}
				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}
/**
 * returns place name with it's coordinates to be displayed in the map page when a customer wants to see the 
 * whereabouts of a place in the map
 * @param obj recieves arraylist contianing map_name in arraylist(1)
 * @param client
 */
	private void GetPlacesWithCordinates(Object obj,ConnectionToClient client)    
	{

		if(((ArrayList<String>)obj).size()==2)
		{
			PreparedStatement stmt2;
			try {

				stmt2 = con1.prepareStatement("SELECT place_name,corX,corY FROM project.map_place_released WHERE map_name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<MapPlace> names=new ArrayList<MapPlace>();

				names.add(new MapPlace("returnedMapPlaces", 0, 0));
				while(rs.next()) {
					names.add(new MapPlace(rs.getString(1), rs.getDouble(2), rs.getDouble(3)));
				}
				try {

					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			PreparedStatement stmt2;
			ArrayList<MapPlace> names=new ArrayList<MapPlace>();
			try {

				stmt2 = con1.prepareStatement("SELECT Name FROM project.place WHERE city_name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(2));
				rs=stmt2.executeQuery();

				names.add(new MapPlace("returnedMapPlaces", 0, 0));
				while(rs.next()) {
					names.add(new MapPlace(rs.getString(1), 0,0));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			PreparedStatement stmt3;
			try {
				stmt3 = con1.prepareStatement("SELECT place_name,corX,corY FROM project.map_place WHERE map_name = ?");
				stmt3.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt3.executeQuery();
				while(rs.next()) {
					for(int i=0;i<names.size();i++)
					{
						if(names.get(i).getPlaceName().equals(rs.getString(1)))
						{
							names.get(i).setCorX(rs.getDouble(2));
							names.get(i).setCorY(rs.getDouble(3));
						}
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {

				client.sendToClient(names);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

/**
 * this method returns all places names for a certain map to be displayed according to the selection in the catalog list
 * @param obj recieves map's name in arraylist(1)
 * @param client
 * @throws IOException
 */
	private void GetPlacesForCatalogList(Object obj,ConnectionToClient client) throws IOException     ///256
	{//gets map's places names and returns them to be displayed to client -- obj > arraylist(1) = map name
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT place_name FROM project.map_place_released WHERE map_name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("PlacesNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));
				}
				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT place_name FROM project.map_place WHERE map_name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("PlacesNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));
				}
				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

/**
 * this method gets all city's map names from the DB to be displayed to the client 
 * @param obj recieves obj instance of arraylist containing city name in index 1 of arraylist
 * @param client
 */
	public void GetMapList(Object obj,ConnectionToClient client)                                      /////256
	{//gets and returns city's maps names in order to be displayed to client - obj > arraylist(1) = city name
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT Name FROM project.mapreleased WHERE city_name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("MapsNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));

				}

				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			PreparedStatement stmt2;
			try {
				stmt2 = con1.prepareStatement("SELECT Name FROM project.map WHERE city_name = ?");
				stmt2.setString(1,((ArrayList<String>)obj).get(1));
				rs=stmt2.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("MapsNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));

				}

				try {
					client.sendToClient(names);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
/**
 * this method gets all cities names from the database and returns it to the client 
 * @param obj recieves the query to be ran in arraylist(1)
 * @param client
 * @throws SQLException
 */
	public void GetCityList(Object obj,ConnectionToClient client) throws SQLException        ///256
	{//gets city lists and return it to be displayed to client, recieves query to be ran in arraylist(1)
		stmt= con1.createStatement();
		rs = stmt.executeQuery(((ArrayList<String>)obj).get(1));//executed the required query
		ArrayList<String> names=new ArrayList<String>();
		names.add("CityNames");//return the job name so we continue working right
		while(rs.next()) {
			names.add(rs.getString(1));
		}
		try {
			client.sendToClient(names);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
/**
 * this method returns all daily reports of a certain city - returns all reports of all dates , further filters are put on 
 * the client - contoller side to keep the reports of the selected time space 
 * @param obj recieve obj instance of arraylist including city name in arraylist(1)
 * @param client
 * @throws SQLException
 */
	private void GetCityReport(Object obj,ConnectionToClient client) throws SQLException
	{//gets city report and returns it in order to be displayed -- recieves obj of arraylist(1) city name
		timedCityReport timedreport= new timedCityReport();
		PreparedStatement stmt1=con1.prepareStatement("SELECT CityReport,NumOfMaps,NumOfPurchases,NumOfSubscriptions,NumOfRenewals,NumOfViews,NumOfDownloads,currentdate FROM project.citydailyreport WHERE CityReport=?;");//to get city version for the selected city
		stmt1.setString(1, ((ArrayList<String>)obj).get(1));
		rs = stmt1.executeQuery();
		while(rs.next()) {
			timedreport.cityname.add(rs.getString(1));
			timedreport.NumOfMaps.add(rs.getInt(2));
			timedreport.NumOfPurchases.add(rs.getInt(3));
			timedreport.NumOfSubscriptions.add(rs.getInt(4));
			timedreport.NumOfRenewals.add(rs.getInt(5));
			timedreport.NumOfViews.add(rs.getInt(6));
			timedreport.NumOfDownloads.add(rs.getInt(7));
			timedreport.Datestr.add(rs.getString(8));
		}

		try {
			client.sendToClient(timedreport);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
/**
 * this method is used as a thread ran daily every 24 hours in order to acquire all customer's ids who's subscription
 * is running out in 3 days or less so we can email and alarm them about their subscription running out in 3 days or less
 * @return
 * @throws SQLException
 */
	public Runnable getCusToAlarm() throws SQLException
	{//gets customers ids to warn about 3 days remaining for subscription and returns to checker thread
		int i=0;
		while(true) 
		{
			i =0;
		PreparedStatement stmt1=con1.prepareStatement("SELECT DISTINCT customer_id FROM project.3daysremaining");//to get city version for the selected city
		rs = stmt1.executeQuery();
		ArrayList<String> CustomersToAlarm=new ArrayList<String>();
		while(rs.next())
			CustomersToAlarm.add(rs.getString(1));
		 Message SendAlarm= new Message();
		    while(i<CustomersToAlarm.size()) {
		    SendAlarm.setRtnMessage("Your subscription is ending in 3 days!! hurry up and renew it");
		    SendAlarm.setRtnSender("system");
		    SendAlarm.setRtnReceiver(CustomersToAlarm.get(i));
		    SendAlarm.setRtnTitle("Subscription Ending in 3 days");
		    SendAlarm.setRtnDate(LocalDate.now());
		    i++;
			String formattedDate = SendAlarm.getRtnDate().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));// changes localized dates to strings
			try {
				stmt1 = con1.prepareStatement("INSERT INTO project.messages VALUES (?,?,?,?,?)");
				stmt1.setString(1, SendAlarm.getRtnSender());
				stmt1.setString(2, SendAlarm.getRtnReceiver());
				stmt1.setString(3, SendAlarm.getRtnMessage());
				stmt1.setString(4, SendAlarm.getRtnTitle());
				stmt1.setString(5, formattedDate);
				stmt1.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    }
		return null;
	}

	}
	/**
	 * this method is used to return all places names in order to build a places list in the client's gui
	 * @param obj instance of arraylist , recieves city name in arraylist(1)
	 * @param client
	 * @throws IOException
	 */
	private void GetPlacesList(Object obj,ConnectionToClient client) throws IOException    ////256
	{//gets the places list to return to client, recieves query in arraylist(1)
		if(((ArrayList<String>)obj).get(2).equals("Customer"))
		{
			try {
				PreparedStatement stmt1;
				stmt1= con1.prepareStatement("SELECT Name FROM project.placereleased WHERE city_name=?");
				stmt1.setString(1, ((ArrayList<String>)obj).get(1));
				rs=stmt1.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("PlacesNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));
				}

				client.sendToClient(names);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			try {
				PreparedStatement stmt1;
				stmt1= con1.prepareStatement("SELECT Name FROM project.place WHERE city_name=?");
				stmt1.setString(1, ((ArrayList<String>)obj).get(1));
				rs=stmt1.executeQuery();
				ArrayList<String> names=new ArrayList<String>();
				names.add("PlacesNames");//return the job name so we continue working right
				while(rs.next()) {
					names.add(rs.getString(1));
				}

				client.sendToClient(names);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	}
/**
 * this method gets maps which are not yet assosciated or linked with a city  
 * @param obj recieves the query to be ran in an obj instance of arraylist , arralist(1) - query
 * @param client
 * @throws IOException
 */
	private void GetNotRelatedMaps(Object obj,ConnectionToClient client) throws IOException{ 
		try {//gets maps that are not yet assosciated with cities to return to client, recieve arraylist(1) - query

			stmt= con1.createStatement();
			rs = stmt.executeQuery(((ArrayList<String>)obj).get(1));//executed the required query
			ArrayList<String> NotRelatedMaps=new ArrayList<String>();
			NotRelatedMaps.add("NotRelatedMaps");//return the job name so we continue working right
			while(rs.next()) {
				NotRelatedMaps.add(rs.getString(1));
			}

			client.sendToClient(NotRelatedMaps);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	////////////////////////////////////////////////////////Adding new Data to DB////////////////////////////////////////////////////////
	/**
	 * this method is used to insert a new tour into the DB
	 * @param obj recieves obj instance of tour
	 */
	private void AddTour(Object obj)                             
	{//adds tour into DB , recieves obj instance of tour
		PreparedStatement stmt2;
		PreparedStatement stmt1;
		try {

			stmt1=con1.prepareStatement("SELECT * FROM project.tour WHERE TourName=?");
			stmt1.setString(1, ((Tour)obj).getTourName());
			rs = stmt1.executeQuery();

			rs.beforeFirst();
			if(rs.next())
			{
				try {
					stmt2 = con1.prepareStatement("UPDATE project.tour SET Description=?,TimeOfTour=?,city_name=? WHERE TourName = ?");
					stmt2.setString(1, ((Tour)obj).getTourDescription());
					stmt2.setString(2, ((Tour)obj).getSumRecommendedTime());
					stmt2.setString(3, ((Tour)obj).getCityName());
					stmt2.setString(4, ((Tour)obj).getTourName());
					stmt2.executeUpdate();


				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ArrayList<String> arr=new ArrayList<String>();
				PreparedStatement stmt3;
				stmt3=con1.prepareStatement("SELECT place_name FROM project.tour_place WHERE tour_name=?");
				stmt3.setString(1, ((Tour)obj).getTourName());
				rs = stmt3.executeQuery();
				rs.beforeFirst();
				while(rs.next())
				{
					arr.add(rs.getString(1));	
				}
				PreparedStatement stmt4;
				for(int i=0;i<((Tour)obj).getLocations().size();i++)
				{
					if(!(arr.contains(((Tour)obj).getLocations().get(i))))
					{
						try {
							stmt4 = con1.prepareStatement("INSERT INTO project.tour_place VALUES (?,?,?)");
							stmt4.setString(1, ((Tour)obj).getTourName());
							stmt4.setString(2, ((Tour)obj).getLocations().get(i));
							stmt4.setString(3, ((Tour)obj).getCityName());
							stmt4.executeUpdate();

						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

				}

				for(int j=0;j<arr.size();j++)
				{
					if(!(((Tour)obj).getLocations().contains(arr.get(j))))
					{

						try {

							stmt4 = con1.prepareStatement("DELETE FROM project.tour_place WHERE tour_name=? AND place_name=?;");
							stmt4.setString(1, ((Tour)obj).getTourName());	
							stmt4.setString(2, arr.get(j));
							stmt4.executeUpdate();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}

				}

			}
			else
			{
				try {
					stmt2 = con1.prepareStatement("INSERT INTO project.tour VALUES (?,?,?,?)");
					stmt2.setString(1, ((Tour)obj).getTourName());
					stmt2.setString(2, ((Tour)obj).getTourDescription());
					stmt2.setString(3, ((Tour)obj).getSumRecommendedTime());
					stmt2.setString(4, ((Tour)obj).getCityName());
					stmt2.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				PreparedStatement stmt3;
				for(int i=0;i<((Tour)obj).getLocations().size();i++)
				{
					try {

						stmt3 = con1.prepareStatement("INSERT INTO project.tour_place VALUES (?,?,?)");
						stmt3.setString(1, ((Tour)obj).getTourName());
						stmt3.setString(2, ((Tour)obj).getLocations().get(i));
						stmt3.setString(3, ((Tour)obj).getCityName());
						stmt3.executeUpdate();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}//update the version of the selected city accordingly

				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}//update the version of the selected city accordingly	
	}

/**
 * this method is used to add in a request for a new version for a city , the request is then after forwarded to content manager
 * @param obj recieves arraylist containing city name in arraylist(1)
 */
	private void RequestNewVersion(Object obj)              ///////256
	{
		PreparedStatement stmt1;
		PreparedStatement stmt2;
		try {
			stmt1 = con1.prepareStatement("SELECT city_name FROM project.city_request WHERE city_name=?");
			stmt1.setString(1, ((ArrayList<String>)obj).get(1));
			rs= stmt1.executeQuery();
			if(!rs.next())
			{
				stmt2 = con1.prepareStatement("INSERT INTO project.city_request VALUES (?)");
				stmt2.setString(1, ((ArrayList<String>)obj).get(1));
				stmt2.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

	/**
	 * this method is used to insert a new place into the DB
	 * @param obj recieves obj instance of place
	 */
	private void AddPlace(Object obj) {//adds place to DB table  , recieves obj instance of place
		PreparedStatement stmt2;
		try {
			stmt2 = con1.prepareStatement("INSERT INTO project.place VALUES (?,?,?,?,?,?)");
			stmt2.setString(1, ((Place)obj).getLocName());
			stmt2.setString(2, ((Place)obj).getLocDescription());
			stmt2.setString(3 , ((Place)obj).getLocType());
			stmt2.setBoolean(4 , ((Place)obj).getSpecial());
			stmt2.setString(5,  ((Place)obj).getSumRecommendedTime());
			stmt2.setString(6 ,  ((Place)obj).getCityName());
			stmt2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*PreparedStatement stmt4;
		try {
			stmt4 = con1.prepareStatement("UPDATE project.city SET NoOfPOI = NoOfPOI + 1 WHERE CityName = ?");
			stmt4.setString(1, ((Place)obj).getLocName());
			stmt4.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}
	/**
	 * this method is used to insert a new message into the DB
	 * @param obj recieves obj instance of message
	 */
	private void AddMessage(Object obj) // adds message to DB , recieves obj instance of Message
	{
		String formattedDate = ((Message)obj).getRtnDate().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));// changes localized dates to strings
		PreparedStatement stmt1;
		try {
			stmt1 = con1.prepareStatement("INSERT INTO project.messages VALUES (?,?,?,?,?)");
			stmt1.setString(1, ((Message)obj).getRtnSender());
			stmt1.setString(2, ((Message)obj).getRtnReceiver());
			stmt1.setString(3, ((Message)obj).getRtnMessage());
			stmt1.setString(4, ((Message)obj).getRtnTitle());
			stmt1.setString(5, formattedDate);
			stmt1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}
	/**
	 * this method is used to insert a new subscription into the DB
	 * @param obj recieves obj instance of purchase 
	 */
	private void AddSubscription(Object obj,ConnectionToClient client) throws IOException {//adds purchase of type subscription to DB, recieves obj instance of purchase
		PreparedStatement stmt2;
		PreparedStatement stmt3;
		PreparedStatement stmt4;
		PreparedStatement stmt6;
		PreparedStatement stmt7;
		String formattedDate = ((Purchase)obj).getPurchaseDate().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));// changes localized dates to strings
		String formattedStartDate = ((Purchase)obj).getDateStart().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
		String formattedEndDate = ((Purchase)obj).getDateEnd().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
		try {
			stmt3=con1.prepareStatement("SELECT * FROM currentlyowned WHERE customer_id=? AND OwnedCity=?");
			stmt3.setString(1, ((Purchase)obj).getCustomerid());
			stmt3.setString(2, ((Purchase)obj).getCityname());
			rs = stmt3.executeQuery();
			rs.beforeFirst();
			if(rs.next())
			{
				if(((Purchase)obj).getPurchaseType().equals("renew"))
				{
					stmt6 = con1.prepareStatement("UPDATE project.customer_subscription SET startDate=?,endDate=?,Type=? WHERE customer_id = ? and subscription_city=? ");
					stmt6.setString(1,formattedStartDate );
					stmt6.setString(2,formattedEndDate );
					stmt6.setString(3, "Renewal");
					stmt6.setString(4, ((Purchase)obj).getCustomerid());
					stmt6.setString(5, ((Purchase)obj).getCityname());
					stmt6.executeUpdate();	
					try {
						stmt7 = con1.prepareStatement("UPDATE project.cityreport SET NumOfRenewals = NumOfRenewals + 1 WHERE CityReport = ?");
						stmt7.setString(1,((Purchase)obj).getCityname());
						stmt7.executeUpdate();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else {
					client.sendToClient("CityAlreadyPurchased");
				}
			}
			else
			{
				stmt2 = con1.prepareStatement("INSERT INTO project.customer_subscription VALUES (?,?,?,?,?,?)");
				stmt2.setString(2, ((Purchase)obj).getCityname());
				stmt2.setString(1, ((Purchase)obj).getCustomerid());
				stmt2.setString(3, formattedStartDate);
				stmt2.setString(4, formattedEndDate);
				stmt2.setString(5,formattedDate);
				stmt2.setString(6,"Subscription");
				stmt2.executeUpdate();
				PreparedStatement stmt5;
				try {
					stmt5 = con1.prepareStatement("UPDATE project.cityreport SET NumOfSubscriptions = NumOfSubscriptions + 1 WHERE CityReport = ?");
					stmt5.setString(1,((Purchase)obj).getCityname());
					stmt5.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("adding to customer city");
				stmt4 = con1.prepareStatement("INSERT INTO project.customer_city VALUES (?,?)");
				stmt4.setString(2, ((Purchase)obj).getCityname());
				stmt4.setString(1, ((Purchase)obj).getCustomerid());
				stmt4.executeUpdate();
			}} catch (SQLException e) {
				e.printStackTrace();
			}//update the version of the selected city accordingly	


	}
	/**
	 * this method is used to insert a new one_time_purchase into the DB
	 * @param obj recieves obj instance of purchase
	 */
	private void AddOneTimePurchase(Object obj,ConnectionToClient client) throws IOException {//adds purchase of type onetime, recieves obj instance of purchase
		PreparedStatement stmt2;
		PreparedStatement stmt3;
		PreparedStatement stmt5;
		PreparedStatement stmt8;
		PreparedStatement stmt15;
		PreparedStatement stmt14;
		String formattedDate = ((Purchase)obj).getPurchaseDate().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)); // turn localdate to string
		try {
			stmt3=con1.prepareStatement("SELECT * FROM currentlyowned WHERE customer_id=? AND OwnedCity=?");
			stmt3.setString(1, ((Purchase)obj).getCustomerid());
			stmt3.setString(2, ((Purchase)obj).getCityname());
			rs = stmt3.executeQuery();
			if(rs.next())
			{
				client.sendToClient("CityAlreadyPurchased");
			}
			else 
			{
				stmt8=con1.prepareStatement("SELECT PurchaseNum FROM customer_onetimebuy ORDER BY PurchaseNum Desc;");
				rs=stmt8.executeQuery();
				int i;
				if(rs.next())
					i=rs.getInt(1);
				else
					i=0;
				stmt2 = con1.prepareStatement("INSERT INTO project.customer_onetimebuy VALUES (?,?,?,?,?)");//inserts into one time table
				stmt2.setString(2, ((Purchase)obj).getCityname());
				stmt2.setString(1, ((Purchase)obj).getCustomerid());
				stmt2.setString(3, (formattedDate));
				stmt2.setString(4,"OneTime");
				stmt2.setInt(5, i+1);
				stmt2.executeUpdate();
				stmt14 = con1.prepareStatement("SELECT * From project.customer_city Where customer_id=? and city_name=?");
				stmt14.setString(2, ((Purchase)obj).getCityname());
				stmt14.setString(1, ((Purchase)obj).getCustomerid());
				rs=stmt14.executeQuery();
				
				stmt5 = con1.prepareStatement("UPDATE project.cityreport SET NumOfPurchases = NumOfPurchases + 1 WHERE CityReport = ?");
				stmt5.setString(1,((Purchase)obj).getCityname());
				stmt5.executeUpdate();
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly		 

	}
	/**
	 * this method is used to insert a new city into the DB 
	 * @param obj recieves obj instance of city
	 */
	private void AddCity(Object obj) throws SQLException { //adds city to DB recieves obj instance of city

		PreparedStatement stmt2;
		PreparedStatement stmt1;

		stmt1=con1.prepareStatement("SELECT * FROM project.city WHERE CityName=? ");
		stmt1.setString(1, ((City)obj).getCityName());
		rs=stmt1.executeQuery();
		if(rs.next())
		{
			PreparedStatement stmt3;
			try {
				stmt3 = con1.prepareStatement("UPDATE project.map SET city_name=? WHERE Name = ?;");  
				stmt3.setString(1, ((City)obj).getCityName());
				stmt3.setString(2, ((City)obj).getMaps().get(0));
				stmt3.executeUpdate();

				stmt3=con1.prepareStatement("Select NumOfMaps From project.cityreport WHERE CityReport=?;");
				stmt3.setString(1, ((City)obj).getCityName());
				rs=stmt3.executeQuery();
				rs.next();
				int i=rs.getInt(1);
				stmt3 = con1.prepareStatement("UPDATE project.cityreport SET NumOfMaps=? WHERE CityReport=?;"); 
				stmt3.setInt(1,i+1);
				stmt3.setString(2, ((City)obj).getCityName());
				stmt3.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//update the version of the selected city accordingly



		}
		else
		{

			try {
				stmt2 = con1.prepareStatement("INSERT INTO project.city VALUES (?,?,?)");//adds to city table
				stmt2.setString(1, ((City)obj).getCityName());
				stmt2.setInt(2, 0);
				stmt2.setInt(3, 0);
				stmt2.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//update the version of the selected city accordingly

			PreparedStatement stmt5;

			try {
				stmt5 = con1.prepareStatement("INSERT INTO project.cityreport VALUES (?,?,?,?,?,?,?)");//adds to city table
				stmt5.setString(1, ((City)obj).getCityName());
				stmt5.setInt(2, 0);
				stmt5.setInt(3, 0);
				stmt5.setInt(4, 0);
				stmt5.setInt(5, 0);
				stmt5.setInt(6, 0);
				stmt5.setInt(7, 0);
				stmt5.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//update the version of the selected city accordingly

			PreparedStatement stmt3;
			try {
				stmt3 = con1.prepareStatement("UPDATE project.map SET city_name=? WHERE Name = ?;");//updates map_table column cityname accordingly  
				stmt3.setString(1, ((City)obj).getCityName());
				stmt3.setString(2, ((City)obj).getMaps().get(0));
				stmt3.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//update the version of the selected city accordingly

		}
	}
	/**
	 * this method is used to insert a new customer into the DB
	 * @param obj recieves obj instance of customer
	 */
	private void AddCustomer(Object obj) { //adds customer to DB recieves obj instance of customer

		PreparedStatement stmt2;
		PreparedStatement stmt3;
		PreparedStatement stmt4;
		try {
			stmt3 = con1.prepareStatement("Select * From project.customer Where id=?");
			stmt3.setString(1, ((Customer)obj).getID());
			rs=stmt3.executeQuery();
			if(rs.next())
			{
				stmt2 = con1.prepareStatement("UPDATE project.customer SET firstname=?,lastname=?,PhoneNumber=?,mail=?,CreditCard=?,id=? Where id=?");
				stmt2.setString(1, ((Customer)obj).getFirstName());
				stmt2.setString(2, ((Customer)obj).getLastName());
				stmt2.setString(3, ((Customer)obj).getMobileNum());
				stmt2.setString(4, ((Customer)obj).geteMail());
				stmt2.setString(5, ((Customer)obj).getCreditCard());
				stmt2.setString(6, ((Customer)obj).getID());
				stmt2.setString(7, ((Customer)obj).getID());
				stmt2.executeUpdate();
			}
			else {
				stmt2 = con1.prepareStatement("INSERT INTO project.customer VALUES (?,?,?,?,?,?,?)");
				stmt2.setString(1, ((Customer)obj).getFirstName());
				stmt2.setString(2, ((Customer)obj).getLastName());
				stmt2.setString(3, ((Customer)obj).getMobileNum());
				stmt2.setString(4, ((Customer)obj).geteMail());
				stmt2.setString(5, ((Customer)obj).getCreditCard());
				stmt2.setString(6, ((Customer)obj).getID());
				stmt2.setString(7, ((Customer)obj).getPassword());
				stmt2.executeUpdate();
			} 
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly

	}







	/////////////////////////////////////////////////////////Updating Data in DB///////////////////////////////
	/**
	 * this method is used to remove a tour from the DB , also unlinking it from every table its connected to
	 * @param obj recieves arraylist containing the tour's name in arraylist(1)
	 */
	private void DeleteTour(Object obj)                   
	{
		PreparedStatement stmt2;
		try { 
			stmt2 = con1.prepareStatement("DELETE FROM project.tour WHERE TourName=?;");  
			stmt2.setString(1, ((ArrayList<String>)obj).get(1));
			stmt2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly

		PreparedStatement stmt3;
		try { 
			stmt3 = con1.prepareStatement("DELETE FROM project.tour_place WHERE tour_name=?;");  
			stmt3.setString(1, ((ArrayList<String>)obj).get(1));
			stmt3.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly

	}

	/**
	 * this method is used to remove a place from the DB , also unlinking it from every table its connected to
	 * @param obj recieves arraylist containing the place's name in arraylist(1)
	 */
	private void DeletePlace(Object obj)                
	{
		PreparedStatement stmt2;
		try { 
			stmt2 = con1.prepareStatement("DELETE FROM project.place WHERE Name=?;");  
			stmt2.setString(1, ((ArrayList<String>)obj).get(1));
			stmt2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly

		PreparedStatement stmt3;
		try { 
			stmt3 = con1.prepareStatement("DELETE FROM project.tour_place WHERE place_name=?;");  
			stmt3.setString(1, ((ArrayList<String>)obj).get(1));
			stmt3.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly

		PreparedStatement stmt4;
		try { 
			stmt4 = con1.prepareStatement("DELETE FROM project.map_place WHERE place_name=?;");  
			stmt4.setString(1, ((ArrayList<String>)obj).get(1));
			stmt4.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly

	}
/**
 * this method is used to edit the map's description - updating the DB according to the change
 * @param obj recieves an arraylist containing the new description in arraylist(1) and the map's name in arraylist(2)
 */
	private void UpdateDescriptionToMap(Object obj)//edits the map description accordingly
	{
		PreparedStatement stmt2;
		try { //recieves description in arraylist(1) and map name is arraylist(2)
			stmt2 = con1.prepareStatement("UPDATE project.map SET Description = ? WHERE Name = ?;");  
			stmt2.setString(1, ((ArrayList<String>)obj).get(1));
			stmt2.setString(2, ((ArrayList<String>)obj).get(2));
			stmt2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly

	}

/**
 * this method is used to edit the place's coordinates, updating the coordinates according to the client's request in the DB
 * @param obj recieves obj instance of MapPlace
 */
	private void UpdatePlaceCordinates(Object obj) //edits the place coordinates accordingly
	{

		PreparedStatement stmt1,stmt2,stmt3;
		try {
			stmt1 = con1.prepareStatement("SELECT place_name FROM project.map_place WHERE map_name = ?");

			stmt1.setString(1,((MapPlace)obj).getMapName());
			rs=stmt1.executeQuery();
			ArrayList<String> name=new ArrayList<String>();
			while(rs.next())
			{	
				name.add(rs.getString(1));
			}

			if(name.contains(((MapPlace)obj).getPlaceName()))
			{
				try {
					stmt2 = con1.prepareStatement("UPDATE project.map_place SET corX = ?, corY= ? WHERE place_name = ?;");  
					stmt2.setDouble(1, ((MapPlace)obj).getCorX());
					stmt2.setDouble(2, ((MapPlace)obj).getCorY());
					stmt2.setString(3, ((MapPlace)obj).getPlaceName());
					stmt2.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}//update the version of the selected city accordingly
			}
			else
			{

				try {
					stmt3 = con1.prepareStatement("INSERT INTO project.map_place VALUES (?,?,?,?,?)");
					stmt3.setString(1, ((MapPlace)obj).getMapName());
					stmt3.setString(2, ((MapPlace)obj).getPlaceName());
					stmt3.setDouble(3, ((MapPlace)obj).getCorX());
					stmt3.setDouble(4, ((MapPlace)obj).getCorY());
					stmt3.setString(5, ((MapPlace)obj).getCityName() );
					//change
					stmt3.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}//update the version of the selected city accordingly


			}


		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly	



	}
/**
 * this method is used to update place's details in the DB according to the client's wishes
 * @param obj recieves obj instance of place
 */
	private void UpdatePlaceDetails(Object obj)

	{//updates place details accordingly -- recieves obj instance of place
		PreparedStatement stmt2;
		try {
			stmt2 = con1.prepareStatement("UPDATE project.place SET Name = ?,Description = ?,Classification = ?,Accessibility = ?,TimeOfVisit = ?,city_name = ? WHERE Name = ?;");  
			stmt2.setString(1, ((ArrayList<Place>)obj).get(1).getLocName());
			stmt2.setString(2, ((ArrayList<Place>)obj).get(1).getLocDescription());
			stmt2.setString(3 , ((ArrayList<Place>)obj).get(1).getLocType());
			stmt2.setBoolean(4 , ((ArrayList<Place>)obj).get(1).getSpecial());
			stmt2.setString(5,  ((ArrayList<Place>)obj).get(1).getSumRecommendedTime());
			stmt2.setString(6 ,  ((ArrayList<Place>)obj).get(1).getCityName());
			stmt2.setString(7 ,  ((ArrayList<Place>)obj).get(0).getLocName());

			stmt2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly
	}
/**
 * increases the viewer's count - this method is triggered when a customer views a certain city's page
 * @param obj recieves obj instance of arraylist containing the viewed city name
 * @param client
 */
	private void AddViewers(Object obj, ConnectionToClient client) // new eyal
	{
		PreparedStatement stmt1;
		try { 
			stmt1=con1.prepareStatement("SELECT NumOfViews FROM project.cityreport WHERE CityReport=?;");//to get city version for the selected city
			stmt1.setString(1, ((ArrayList<String>)obj).get(1));
			rs = stmt1.executeQuery();		
			rs.next();
			int i=rs.getInt(1);
			stmt1 = con1.prepareStatement("UPDATE project.cityreport SET NumOfViews = ? WHERE CityReport = ?;");  
			stmt1.setInt(1, i+1);
			stmt1.setString(2, ((ArrayList<String>)obj).get(1));
			stmt1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//update the version of the selected city accordingly		

	}
/**
 * this method is used to add in a request for a price change , this helps in forward the request to the big boss
 * @param obj recieves city's name and the desired new price in an arraylist
 */
	private void UpdateCityPrice(Object obj) 
	{
		PreparedStatement stmt;
		try {
			stmt = con1.prepareStatement("UPDATE project.city SET Price = ? WHERE CityName = ?;");  
			double price = Double.parseDouble(((ArrayList<String>)obj).get(2));
			stmt.setDouble(1, price);
			stmt.setString(2, ((ArrayList<String>)obj).get(1));
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////

	protected void serverStarted()
	{
		System.out.println ("Server listening for connections on port " + getPort());
	}


	protected void serverStopped()
	{
		System.out.println ("Server has stopped listening for connections.");
	}


	public static void main(String[] args) 
	{
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		} catch (Exception ex) {/* handle the error*/}

		try 
		{
			con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?serverTimezone=IST","root","Aa123456");
			System.out.println("SQL connection succeed");

		} catch (SQLException ex) 
		{/* handle any errors*/
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}

		int port = 0; //Port to listen on

		try
		{
			port = Integer.parseInt(args[0]); //Get port from command line
			port = Integer.parseInt(args[0]); //Get port from command line
		}
		catch(Throwable t)
		{
			port = DEFAULT_PORT; //Set port to 5555
		}

		EchoServer sv = new EchoServer(port);

		try 
		{
			sv.listen(); //Start listening for connections
			while(true) 
			{
			sv.threadsrunner2();
			sv.threadsrunner();
			Thread.currentThread().sleep(86400000);
			}
		} 
		catch (Exception ex) 
		{
			System.out.println("ERROR - Could not listen for clients!");
		}
		
	}
}
//End of EchoServer class
