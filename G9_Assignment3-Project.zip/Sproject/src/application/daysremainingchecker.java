package application;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

import entities.Message;

class daysremainingchecker implements Runnable {	
  ArrayList<String> getCustomersToAlarm= new ArrayList<String>();
  ArrayList<String> CustomersToAlarm= new ArrayList<String>();

public void run() {
	getCustomersToAlarm.add("getCusToAlarm");
	while(true) {
	try {
		Main.getClient().getClient().StringsToServer(getCustomersToAlarm);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		Thread.currentThread().sleep(15000);
	} catch (InterruptedException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	int i=0;
	CustomersToAlarm=Main.getClient().getClient().getCustomersToAlarm();
    Message SendAlarm= new Message();
    while(i<CustomersToAlarm.size()) {
    	System.out.println("sending message to" + " " + CustomersToAlarm.get(i));
    SendAlarm.setRtnMessage("Your subscription is ending in 3 days!! hurry up and renew it");
    SendAlarm.setRtnSender("system");
    SendAlarm.setRtnReceiver(CustomersToAlarm.get(i));
    SendAlarm.setRtnTitle("Subscription Ending in 3 days");
    SendAlarm.setRtnDate(LocalDate.now());
    i++;
    try {
		Main.getClient().getClient().AddingNewData(SendAlarm);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	try {
		Thread.currentThread().sleep(259200000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
}

