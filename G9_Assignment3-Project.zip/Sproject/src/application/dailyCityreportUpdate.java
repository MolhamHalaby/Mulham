package application;

import java.io.IOException;
import java.util.ArrayList;

class dailyCityreportUpdate implements Runnable {	
ArrayList<String> updatecityreport = new ArrayList<String>();	
public void run() {
 updatecityreport.add("savedailyreport");

 try {
	Main.getClient().getClient().StringsToServer(updatecityreport);
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
 try {
	Thread.currentThread().sleep(86400000);
} catch (InterruptedException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
 
 
}
}

