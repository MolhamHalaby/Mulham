package application;

import ocsf.client.*;
import java.io.*;
import java.net.MalformedURLException;
import java.util.ArrayList;

import Controller.EditPlaceController;
import Controller.LoginController;
import entities.Customer;
import entities.CustomerOperations;
import entities.DownloadMap;
import entities.MapPlace;
import entities.Message;
import entities.Place;
import entities.timedCityReport;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
/**
 * this class's purpose is to link between the server,DB and the client - forward the requests from the client to the server
 * and returning the server's data and answers back to the client
 * @author the whole group
 */
public class ChatClient extends AbstractClient
{
	ChatIF clientUI; 
	ArrayList<String> PlacesNames;
	ArrayList<String> cityNames;
	ArrayList<String> cityReport;
	ArrayList<String> MapsNames;
	ArrayList<String> ToursNames;
	ArrayList<String> TourDetails;
	ArrayList<String> CustomersToAlarm;  
	ArrayList<String> DailyInfo;
	ArrayList<String> CustomersNamesIds;
	ArrayList<String> RequestsNames;//256
	ArrayList<String> CustomersEmails;//256
	ArrayList<String> EmployeesEmails;//256
	ArrayList<String> cityprice;//266
	ArrayList<String> ContentEmails;//266
	timedCityReport timedreport;
	 String BigBossID; // eyal 256 + getters and setters
		int pureprice;
    DownloadMap transferdata;
	 


	Customer CustomerProfile;
	Image image;
	String s;        
	double Price;
	boolean discount;
Place Pdetails;
CustomerOperations Operations;
	ArrayList<MapPlace> MapPlaces; 
	String LoginAnswer;
	Customer details;
	 Message message;////// new eyal 

	//////////////////////////////////////////////////Constructor////////////////////////////////////


	public ChatClient(String host, int port, ChatIF clientUI)  throws IOException 
	{
		super(host, port); //Call the superclass constructor
		this.clientUI = clientUI;
		openConnection();
		PlacesNames=new ArrayList<String>();
		cityNames=new ArrayList<String>();
		cityReport=new ArrayList<String>();
		MapsNames=new ArrayList<String>();
		cityprice=new ArrayList<String>();//266
		ContentEmails=new ArrayList<String>();//266
		RequestsNames=new ArrayList<String>();//256
		EmployeesEmails=new ArrayList<String>();//256
		CustomersEmails=new ArrayList<String>();//256
		image=null;
		s= new String();                                    //
		MapPlaces=new ArrayList<MapPlace>();  
		LoginAnswer= new String();
		Operations=new CustomerOperations();
		CustomersToAlarm=new ArrayList<String>();
		CustomersNamesIds=new ArrayList<String>();
		DailyInfo=new ArrayList<String>();
		CustomerProfile=new Customer();
		message = new Message();//////////////////// new eyal
	    timedreport=new timedCityReport();
	    transferdata=new DownloadMap();
	}
	public DownloadMap getTransferdata() {
		return transferdata;
	}
	public void setTransferdata(DownloadMap transferdata) {
		this.transferdata = transferdata;
	}
	public ArrayList<String> getContentEmails() {
		return ContentEmails;
	}

	public void setContentEmails(ArrayList<String> contentEmails) {
		ContentEmails = contentEmails;
	}

	public ArrayList<String> getCityprice() {
		return cityprice;
	}

	public void setCityprice(ArrayList<String> cityprice) {
		this.cityprice = cityprice;
	}
	public ArrayList<String> getCustomersEmails() {
		return CustomersEmails;
	}

	public void setCustomersEmails(ArrayList<String> customersEmails) {
		CustomersEmails = customersEmails;
	}
	 public int getPureprice() {
			return pureprice;
		}

		public void setPureprice(int pureprice) {
			this.pureprice = pureprice;
		}

	public String getBigBossID() {
		return BigBossID;
	}

	public void setBigBossID(String bigBossID) {
		BigBossID = bigBossID;
	}

	public ArrayList<String> getEmployeesEmails() {
		return EmployeesEmails;
	}

	public void setEmployeesEmails(ArrayList<String> employeesEmails) {
		EmployeesEmails = employeesEmails;
	}

	public ArrayList<String> getRequestsNames() {//256
		return RequestsNames;
	}

	public void setRequestsNames(ArrayList<String> requestsNames) {//256
		RequestsNames = requestsNames;
	}

	public timedCityReport getTimedreport() {
		return timedreport;
	}

	public void setTimedreport(timedCityReport timedreport) {
		this.timedreport = timedreport;
	}

	/////////////////////////////////////////////////getters&setters//////////////////////////////////  
	public Place getPdetails() {
	return Pdetails;
}

public void setPdetails(Place pdetails) {
	Pdetails = pdetails;
}
public Message getMessage() {// new eyal 
	return message;
}

public void setMessage(Message message) {// new eyal
	this.message = message;
}
	public ArrayList<String> getTourDetails() {
		return TourDetails;
	}

	public void setTourDetails(ArrayList<String> tourDetails) {
		TourDetails = tourDetails;
	}

	public ArrayList<String> getToursNames() {
		return ToursNames;
	}

	public void setToursNames(ArrayList<String> toursNames) {
		ToursNames = toursNames;
	}

	public Customer getDetails() {
		return details;
	}

	public void setDetails(Customer details) {
		this.details = details;
	}

	public ArrayList<MapPlace> getMapPlaces() {
		return MapPlaces;
	}

	public void setMapPlaces(ArrayList<MapPlace> mapPlaces) {
		MapPlaces = mapPlaces;
	}

	public String getLoginAnswer() {
		return LoginAnswer;
	}

	public void setLoginAnswer(String loginAnswer) {
		LoginAnswer = loginAnswer;
	}

	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}
	public CustomerOperations getOperations() {
		return this.Operations;
	}

	public void setOperations(CustomerOperations operations) {
		this.Operations = operations;
	}
	public Customer getCustomerProfile() {
		return CustomerProfile;
	}

	public void setCustomerProfile(Customer customerProfile) {
		CustomerProfile = customerProfile;
	}
	public ArrayList<String> getDailyInfo() {
		return DailyInfo;
	}

	public void setDailyInfo(ArrayList<String> dailyInfo) {
		DailyInfo = dailyInfo;
	}
	public ArrayList<String> getCustomersNamesIds() {
		return this.CustomersNamesIds;
	}

	public void setCustomersNamesIds(ArrayList<String> customersNamesIds) {
		this.CustomersNamesIds = customersNamesIds;
	}
	public ArrayList<String> getCustomersToAlarm() {
		return CustomersToAlarm;
	}

	public void setCustomersToAlarm(ArrayList<String> customersToAlarm) {
		CustomersToAlarm = customersToAlarm;
	}
	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public ArrayList<String> getCityNames() {
		return cityNames;
	}

	public ArrayList<String> getMapsNames() {
		return MapsNames;
	}

	public void setMapsNames(ArrayList<String> mapsNames) {
		this.MapsNames = mapsNames;
	}

	public void setCityNames(ArrayList<String> cityNames) {
		this.cityNames = cityNames;
	}

	public ArrayList<String> getCityReport() {
		return cityReport;
	}

	public void setCityReport(ArrayList<String> cityReport) {
		this.cityReport = cityReport;
	}

	public ArrayList<String> getPlacesNames() {
		return PlacesNames;
	}

	public void setPlacesNames(ArrayList<String> placesNames) {
		PlacesNames = placesNames;
	}

	public double getPrice() {
		return Price;
	}

	public void setPrice(String string,double d) {//d is 1 if no discount and 0.9 if there is a discount
		Price = Double.parseDouble(string) * d;

	}
	public boolean isDiscount() {
		return discount;
	}
	public void setDiscount(boolean discount) {
		this.discount = discount;
	}


	//////////////////////////////////////////Returns from server!!!!!!!!/////////////////////////////////////////////////////

	public void handleMessageFromServer(Object obj) 
	{

		if(obj instanceof Customer)
		{
			details=new Customer();
			setDetails((Customer)obj);

		}
		else if((obj instanceof Message))
			setMessage((Message)obj);
		else if((obj instanceof CustomerOperations ))
		{
			setOperations((CustomerOperations)obj);
		}
		else if(obj instanceof Place)
		{
			Pdetails= new Place();
			setPdetails((Place)obj);
			
		}
		else if(obj instanceof DownloadMap)
		{
			setTransferdata((DownloadMap)obj);
			
		}
		else if(obj instanceof String)
		{
			if(((String)obj).equals("CityAlreadyPurchased"))
			{
				setS(((String)obj));
				
			}
			
		}
		else if(obj instanceof timedCityReport)
		{
			setTimedreport((timedCityReport)obj);
		}
		else if(obj instanceof MyFile)
		{
			MyFile file;
			int fileSize =((MyFile)obj).getSize(); 
			file=new MyFile(((MyFile)obj).getFileName());
			File picfile=new File("src\\Images\\"+file.getFileName());
			try { 
				FileOutputStream fos = new FileOutputStream(picfile);
				try {
					fos.write(((MyFile)obj).getMybytearray());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				FileInputStream input = new FileInputStream(picfile);
				image= new Image(input);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
		}

		else if(obj instanceof ArrayList)
		{
			if(((ArrayList<String>)obj).get(0) instanceof String )
			{
				if(((ArrayList<String>)obj).get(0).equals("PlacesNames")) 
				{
					((ArrayList<String>)obj).remove(0);
					setPlacesNames((ArrayList<String>)obj);
				}
				else if(((ArrayList<String>)obj).get(0).equals("CityNames"))
				{
					((ArrayList<String>)obj).remove(0);
					setCityNames((ArrayList<String>)obj);

				}
				else if(((ArrayList<String>)obj).get(0).equals("GetBigBossID"))// eyal 256
				{
					((ArrayList<String>)obj).remove(0);
					setBigBossID(((ArrayList<String>)obj).get(0));
					

				}
				else if(((ArrayList<String>)obj).get(0).equals("CustomersEmails"))
				{
					((ArrayList<String>)obj).remove(0);
					setCustomersEmails((ArrayList<String>)obj);

				}
				else if(((ArrayList<String>)obj).get(0).equals("citypricelist"))//266
				{
					((ArrayList<String>)obj).remove(0);
					setCityprice((ArrayList<String>)obj);

				}
				else if(((ArrayList<String>)obj).get(0).equals("EmployeesEmails"))
				{
					((ArrayList<String>)obj).remove(0);
					setEmployeesEmails((ArrayList<String>)obj);

				}
				else if(((ArrayList<String>)obj).get(0).equals("ContentManagerEmails"))//266
				{
					((ArrayList<String>)obj).remove(0);
					setContentEmails((ArrayList<String>)obj);

				}
				else if(((ArrayList<String>)obj).get(0).equals("ReportNames"))
				{
					((ArrayList<String>)obj).remove(0);
					setCityReport((ArrayList<String>)obj);
				}
				else if(((ArrayList<String>)obj).get(0).equals("pureprice"))
				{
					((ArrayList<String>)obj).remove(0);
					setPureprice(Integer.parseInt(((ArrayList<String>)obj).get(0)));
				}
				else if(((ArrayList<String>)obj).get(0).equals("RequestsNames"))//256
				{
					((ArrayList<String>)obj).remove(0);
					setRequestsNames((ArrayList<String>)obj);
				}
				else if(((ArrayList<String>)obj).get(0).equals("MapsNames"))
				{
					((ArrayList<String>)obj).remove(0);
					setMapsNames((ArrayList<String>)obj);
				}
				else if(((ArrayList<String>)obj).get(0).equals("NotRelatedMaps")) 
				{
					((ArrayList<String>)obj).remove(0);
					setMapsNames((ArrayList<String>)obj);
				}
				else if(((ArrayList<String>)obj).get(0).equals("MapDescription")) 
				{
					((ArrayList<String>)obj).remove(0);
					setS(((ArrayList<String>)obj).get(0));
				}
				else if(((ArrayList<String>)obj).get(0).equals("ToursNames")) 
				{
					((ArrayList<String>)obj).remove(0);
					setToursNames(((ArrayList<String>)obj));
				}
				else  if(((ArrayList<String>)obj).get(0).equals("TourDetails")) 
				{
					((ArrayList<String>)obj).remove(0);
					setTourDetails(((ArrayList<String>)obj));
				}

				else if(((ArrayList<String>)obj).get(0).equals("LoginAnswer"))
				{
					((ArrayList<String>)obj).remove(0);
					if(((ArrayList<String>)obj).get(0).equals("LogCustomer")) 
					{
						setLoginAnswer("Customer");
					}
					else if (((ArrayList<String>)obj).get(0).equals("LogEmployee")) 
					{
						setLoginAnswer("Employee");
					}
					else if(((ArrayList<String>)obj).get(0).equals("LogFailed")) {
						setLoginAnswer("Failed");
						}
					else if (((ArrayList<String>)obj).get(0).equals("Manager")) 
					{
						setLoginAnswer("Manager");
					}
					else if (((ArrayList<String>)obj).get(0).equals("Big Boss")) 
					{
						setLoginAnswer("Big Boss");
					}
				}

				else if(((ArrayList<String>)obj).get(0).equals("CityPrice")) //ADDED 18.6 1:42 AM DONT FORGET GETTERS+SETTERS
				{   //DOUBLE PRICE,DISCOUNT BOOLEAN
					
					((ArrayList<String>)obj).remove(0);
					if(((ArrayList<String>)obj).get(1).equals("discountYes")) {
						setPrice(((ArrayList<String>)obj).get(0),0.9);
						System.out.println(((ArrayList<String>)obj).get(0));
						setDiscount(true);
					}
					else if(((ArrayList<String>)obj).get(1).equals("nodiscount")) {
						setPrice(((ArrayList<String>)obj).get(0),1);
						setDiscount(false);
					}

				}
				else if(((ArrayList<String>)obj).get(0).equals("ReturningAlarms"))
				{
					((ArrayList<String>)obj).remove(0);
					setCustomersToAlarm(((ArrayList<String>)obj));
				}
				else if(((ArrayList<String>)obj).get(0).equals("DailyInfo"))
				{
					((ArrayList<String>)obj).remove(0);
					setDailyInfo((ArrayList<String>)obj);
				}
				else if(((ArrayList<String>)obj).get(0).equals("GetCustomersNames"))
				{
					((ArrayList<String>)obj).remove(0);
					setCustomersNamesIds((ArrayList<String>)obj);
				}
				else if(((ArrayList<String>)obj).get(0).equals("CustomerProfile"))
				{
					((ArrayList<String>)obj).remove(0);
					setCustomersNamesIds((ArrayList<String>)obj);
				}
			
			
			}
			else if(((ArrayList<MapPlace>)obj).get(0) instanceof MapPlace )
			{

				if(((ArrayList<MapPlace>)obj).get(0).getPlaceName().equals("returnedMapPlaces"))       //////////
				{
					((ArrayList<MapPlace>)obj).remove(0);
					setMapPlaces((ArrayList<MapPlace>)obj);

				}
			}

		}

	}

	//////////////////////////////////////////Sending To server ///////////////////////////////////////////////////////////////
	public void AddingNewData(Object obj) throws IOException
	{

		sendToServer(obj);

	}
public void UpdatePlace(Object obj)
{
	ArrayList<Place> places=new ArrayList<Place>();
   places.add(new Place(EditPlaceController.previousName,"","",false,""));
   places.add((Place)obj);
	try {
		sendToServer(places);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

    public void StringsToServer(ArrayList<String> strings) throws IOException
	{
    	sendToServer(strings);
	}

	public void MapToUpdate(MapPlace x) throws IOException         
	{

		sendToServer(x);
	}

	public void handleMessageFromClientUI(String message)  
	{
		try
		{
			if(message.equals("GetCitiesForComboBox")) //incase the job is to get city names for combobox
			{

				ArrayList<String> toGetCities=new ArrayList<String>();
				toGetCities.add("GetCityNames"); //fill the first slot with the job name for the next method to work right
				if(LoginController.type.equals("Customer"))
				{
				toGetCities.add("SELECT CityName FROM project.cityreleased;");//the query to be executed in the next method 
				}
				else
				{
					toGetCities.add("SELECT CityName FROM project.city;");
				}
				sendToServer(toGetCities);
			}
			else if(message.equals("GetNotRelatedMaps"))
			{
				ArrayList<String> toGetMapsNotRelated=new ArrayList<String>();
				toGetMapsNotRelated.add("GetNotRelatedMaps"); //fill the first slot with the job name for the next method to work right
				toGetMapsNotRelated.add("SELECT Name FROM project.map WHERE city_name IS NULL;"); //the query to be executed in the next method 

				sendToServer(toGetMapsNotRelated);
			}
			else if(message.equals("GetAlarm")) //incase the job is to get city names for combobox
			{

				ArrayList<String> toGetAlarms=new ArrayList<String>();
				toGetAlarms.add("GetAlarm"); //fill the first slot with the job name for the next method to work right
				sendToServer(toGetAlarms);
			}
			else if(message.equals("GetCustomersNames")) //incase the job is to get city names for combobox
			{

				ArrayList<String> toGetNames=new ArrayList<String>();
				toGetNames.add("GetCustomersNames"); //fill the first slot with the job name for the next method to work right
				sendToServer(toGetNames);
			}
			else if(message.equals("CustomerProfile")) //incase the job is to get city names for combobox
			{

				ArrayList<String> GetCusPro=new ArrayList<String>();
				GetCusPro.add("CustomerProfile"); //fill the first slot with the job name for the next method to work right
				sendToServer(GetCusPro);
			}
			else if (message.equals("GetMessages")) 
				{
				ArrayList<String> toGetMessages=new ArrayList<String>();
				toGetMessages.add("GetMessages"); //fill the first slot
				toGetMessages.add(LoginController.id);
				sendToServer(toGetMessages);
				}
			else if (message.equals("GetBigBossID")){
				ArrayList<String> toGetBigBossID=new ArrayList<String>();
				toGetBigBossID.add("GetBigBossID");
				sendToServer(toGetBigBossID);
				
			}

		}
		catch(IOException e)
		{
			clientUI.display ("Could not send message to server.  Terminating client.");
			quit();
		}
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void quit()
	{
		try
		{
			closeConnection();
		}
		catch(IOException e) {}
		System.exit(0);
	}
}