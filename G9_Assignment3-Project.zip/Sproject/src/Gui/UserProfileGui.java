package Gui;

import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import entities.Customer;
import entities.CustomerOperations;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * This class is for the user's information 
 * @author Sahar
 *
 */
public class UserProfileGui {

	  @FXML
	    private ResourceBundle resources;

	    @FXML
	    private URL location;

	    @FXML
	    private Text UserFirstNamelbl;

	    @FXML
	    private Text LastNameLBL;

	    @FXML
	    private Text PhoneID;

	    @FXML
	    private Text firstNameID;

	    @FXML
	    private Text MailLBL;

	    @FXML
	    private Text CreaditCardLbL;

	    @FXML
	    private Text IDLBL;

	    @FXML
	    private TextField firstNameTXT;

	    @FXML
	    private TextField LastNameTXT;

	    @FXML
	    private TextField PhoneTxt;

	    @FXML
	    private TextField MailTxt;

	    @FXML
	    private TextField IDtxt;

	    @FXML
	    private TextField CreditCardTXT;

	    @FXML
	    private ImageView GcmImgID;

	    @FXML
	    private ImageView ProfileIconId;

	    @FXML
	    private Button LogOutBtn;

	    @FXML
	    private Button HomeBtn;

	    @FXML
	    private Button MyCitiesBtn;

	    @FXML
	    private Button EditProfileBtn;

	    @FXML
	    private Button PurchaseHistory;

	    @FXML
	    private Button SaveEdit;

	    @FXML
	    private Button CancelEdit;

	    /**
	     * this method handles the cancel button, when the user clicks on this button he 
	     * can cancel the edits the he has made in his profile iformation
	     * @param event
	     */
	    @FXML
	    void CancelEdit(ActionEvent event) {
	          SaveEdit.setVisible(false);
	          CancelEdit.setVisible(false);
	          firstNameTXT.setEditable(false);
	          LastNameTXT.setEditable(false);
	          PhoneTxt.setEditable(false);
	          CreditCardTXT.setEditable(false);
	          IDtxt.setEditable(false);
	          MailTxt.setEditable(false);
	          UserFirstNamelbl.setText(Main.getClient().getClient().getDetails().getFirstName());
	     	  firstNameTXT.setText(Main.getClient().getClient().getDetails().getFirstName());
	     	  LastNameTXT.setText(Main.getClient().getClient().getDetails().getLastName());
	     	  PhoneTxt.setText(Main.getClient().getClient().getDetails().getMobileNum());
	     	  CreditCardTXT.setText(Main.getClient().getClient().getDetails().getCreditCard());
	     	  IDtxt.setText(Main.getClient().getClient().getDetails().getID());
	     	  MailTxt.setText(Main.getClient().getClient().getDetails().geteMail());
	    }
	    /**
	     * this method handles the edit info button, when the user click on this buton 
	     * he will be able to edit his profile info. 
	     * @param event
	     */
	    @FXML
	    void EditInfo(ActionEvent event) {
	          SaveEdit.setVisible(true);
	          CancelEdit.setVisible(true);
	          firstNameTXT.setEditable(true);
	          LastNameTXT.setEditable(true);
	          PhoneTxt.setEditable(true);
	          CreditCardTXT.setEditable(true);
	          MailTxt.setEditable(true);
	    }
	    /**
	     * this method handles the home button that takes back to the home page according to the logger's type
	     * @param event
	     */
	    @FXML
	    void HomeButton(ActionEvent event) {
			if(LoginController.type.equals("Employee")) {
				try {
					Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
					Scene scene = new Scene(root);
					scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
					Stage stage = new Stage();
					stage.setScene(scene);
					((Node) event.getSource()).getScene().getWindow().hide(); 
					stage.show();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			else if (LoginController.type.equals("Manager")) {
				try {
					Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
					Scene scene = new Scene(root);
					scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
					Stage stage = new Stage();
					stage.setScene(scene);
					((Node) event.getSource()).getScene().getWindow().hide(); 
					stage.show();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			else  if (LoginController.type.equals("Customer"))
			{
				try {
					Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));//build the gui
					Scene scene = new Scene(root);
					scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
					Stage stage = new Stage();
					stage.setScene(scene);
					((Node) event.getSource()).getScene().getWindow().hide(); 
					stage.show();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			else  if (LoginController.type.equals("Big Boss"))
			{
				try {
					Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
					Scene scene = new Scene(root);
					scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
					Stage stage = new Stage();
					stage.setScene(scene);
					((Node) event.getSource()).getScene().getWindow().hide(); 
					stage.show();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
	        	
	    }
	  
	    /**
	    * this method handles the Purchase History button, when the user clicks on this button
	    * he will be moves to a Purchase History page
	    * @param event
	    */
	    @FXML
	    void PurchaseHistory(ActionEvent event) {
	    	ArrayList<String> CustomerInfo=new ArrayList<String>();
			CustomerInfo.add("CustomerInfo");
			CustomerInfo.add(LoginController.id);
			try {
				Main.getClient().getClient().StringsToServer(CustomerInfo);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CustomerOperations Operations=new CustomerOperations();
			Operations=Main.getClient().getClient().getOperations();
			ArrayList<String> CombinedOperations = new ArrayList<String>();
			int i=0;
	         while(i < Operations.getCityName().size())
			{
				CombinedOperations.add(i,Operations.getCityName().get(i) + "  " +  Operations.getType().get(i) + "  " + Operations.getDateOfPurchase().get(i));
				CombinedOperations.add("\n");
				i++;
			}
			String listString = String.join("\n", CombinedOperations);
			Alert alert = new Alert(AlertType.INFORMATION);
			TextArea area = new TextArea(listString);
			area.setWrapText(true);
			area.setEditable(false);
			alert.getDialogPane().setContent(area);
			alert.setTitle( (firstNameTXT.getText() + " " + "Operations:"));
			alert.setHeaderText(null);
			alert.showAndWait();
		}
	    
	    /**
	     * this method handles the save button, when the user click on this buton 
	     * he will save the edit info that he has made on his info. 
	     * @param event
	     */
	    @FXML
	    void SaveEdit(ActionEvent event) {
        Customer UpdatedCus=new Customer();
        UpdatedCus.setCreditCard(CreditCardTXT.getText());
	    UpdatedCus.seteMail(MailTxt.getText());
	    UpdatedCus.setFirstName(firstNameTXT.getText());
	    UpdatedCus.setLastName(LastNameTXT.getText());
	    UpdatedCus.setID(IDtxt.getText());
	    UpdatedCus.setMobileNum(PhoneTxt.getText());
      	try {
			Main.getClient().getClient().AddingNewData(UpdatedCus);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   	  SaveEdit.setVisible(false);
   	  CancelEdit.setVisible(false);
   	  SaveEdit.setVisible(false);
      CancelEdit.setVisible(false);
      firstNameTXT.setEditable(false);
      LastNameTXT.setEditable(false);
      PhoneTxt.setEditable(false);
      CreditCardTXT.setEditable(false);
      IDtxt.setEditable(false);
      MailTxt.setEditable(false);
	    }
	   
	    /**
	     * this method handles the logout button that makes the user logs out from the app
	     * @param event
	     */
	    @FXML
	    void LogOutButton(ActionEvent event) {
	    	ArrayList<String> logoutsender= new ArrayList<String>();
			logoutsender.add("LogOutClient");
			logoutsender.add(LoginController.id);
			try {
				Main.getClient().getClient().StringsToServer(logoutsender);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	    	try {
	    	
	    	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//build the gui
	    }
/**
 * this method handles the my cities button, when the customer clicks on this button 
 * he will be moved to my cities page.
 * @param event
 */
	    @FXML
	    void MyCitiesButton(ActionEvent event) {
	    	try {
		    	
		    	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/MyCities.fxml"));
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}//build the gui
	    	
	    	
	    	
	    }

	    /**
		 * This method is called when the FXML file is loaded, it initializes the
		 * variables and some GUI elements.
		 */
    @FXML
    void initialize() {
        assert UserFirstNamelbl != null : "fx:id=\"UserFirstNamelbl\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert LastNameLBL != null : "fx:id=\"LastNameLBL\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert PhoneID != null : "fx:id=\"PhoneID\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert firstNameID != null : "fx:id=\"firstNameID\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert MailLBL != null : "fx:id=\"MailLBL\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert CreaditCardLbL != null : "fx:id=\"CreaditCardLbL\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert IDLBL != null : "fx:id=\"IDLBL\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert firstNameTXT != null : "fx:id=\"firstNameTXT\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert LastNameTXT != null : "fx:id=\"LastNameTXT\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert PhoneTxt != null : "fx:id=\"PhoneTxt\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert MailTxt != null : "fx:id=\"MailTxt\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert IDtxt != null : "fx:id=\"IDtxt\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert CreditCardTXT != null : "fx:id=\"CreditCardTXT\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert GcmImgID != null : "fx:id=\"GcmImgID\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert ProfileIconId != null : "fx:id=\"ProfileIconId\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert MyCitiesBtn != null : "fx:id=\"MyCitiesBtn\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert EditProfileBtn != null : "fx:id=\"EditProfileBtn\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert PurchaseHistory != null : "fx:id=\"PurchaseHistory\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert SaveEdit != null : "fx:id=\"SaveEdit\" was not injected: check your FXML file 'UserProfile.fxml'.";
        assert CancelEdit != null : "fx:id=\"CancelEdit\" was not injected: check your FXML file 'UserProfile.fxml'.";
        ArrayList<String> toServer= new ArrayList<String>();
        toServer.add("GetUserDetails");
        toServer.add(LoginController.id);
        try {
          	Main.getClient().getClient().StringsToServer(toServer);
          } catch (IOException e1) {
          	// TODO Auto-generated catch block
          	e1.printStackTrace();
          }//incase the job is to get city names for combobox
     	  try {
       		Thread.currentThread().sleep(1000);
       	} catch (InterruptedException e) {
       		// TODO Auto-generated catch block
       		e.printStackTrace();
       	}
     	 Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
			GcmImgID.setImage(logo);
			 Image profile= new Image(getClass().getResourceAsStream("/Img/Profile.png"));
				ProfileIconId.setImage(profile);
				
     	  UserFirstNamelbl.setText(Main.getClient().getClient().getDetails().getFirstName());
     	  firstNameTXT.setText(Main.getClient().getClient().getDetails().getFirstName());
     	  LastNameTXT.setText(Main.getClient().getClient().getDetails().getLastName());
     	  PhoneTxt.setText(Main.getClient().getClient().getDetails().getMobileNum());
     	  CreditCardTXT.setText(Main.getClient().getClient().getDetails().getCreditCard());
     	  IDtxt.setText(Main.getClient().getClient().getDetails().getID());
     	  MailTxt.setText(Main.getClient().getClient().getDetails().geteMail());
          firstNameTXT.setEditable(false);
          LastNameTXT.setEditable(false);
          PhoneTxt.setEditable(false);
          CreditCardTXT.setEditable(false);
          IDtxt.setEditable(false);
          MailTxt.setEditable(false);
          SaveEdit.setVisible(false);
          CancelEdit.setVisible(false);

    }
}

