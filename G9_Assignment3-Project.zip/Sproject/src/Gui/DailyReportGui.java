package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.LoginController;
import Controller.ReportController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
*  This class is the GUI controller responsible for showing numbers and types of purchases in the current day. 
 * @author Anan & Sahar
 */
public class DailyReportGui {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private ComboBox<String> CitiesCombo;


	@FXML
	private Label TotalPurchases;

	@FXML
	private Label Subscriptions;

	@FXML
	private Button InfoBtn;

	@FXML
	private Label onetimepurchases;


	@FXML
	private ImageView GcmImage;

	@FXML
	private Button LogOutBtn;

	@FXML
	private Button HomeBtn;
	

    @FXML
    private Button BackBtn;

	/**
	 * This method closes the current window and goes back to the previous window.
	 * @param event
	 */
    @FXML
    void BackButton(ActionEvent event) {

		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/ChooseReportGui.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	
    	
    }
    /**
	 * This method handles the event where the user click on "DisplayInfo" button
	 * and view numbers and types of purchases in the current day
 	 * @param event
	 * @throws IOException
	 */
	@FXML
	void DisplayInfo(ActionEvent event) {
		ArrayList<String> SelectedCity=new ArrayList<String>();
    	if((String)CitiesCombo.getSelectionModel().getSelectedItem()!=null) // eyal 266
    	{
    	SelectedCity.add("getCityDailyInfo");
        SelectedCity.add((String)CitiesCombo.getSelectionModel().getSelectedItem());
        try {
			Main.getClient().getClient().StringsToServer(SelectedCity);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       ArrayList<String> DailyInfoToDisplay=new ArrayList<String>();
       DailyInfoToDisplay=(Main.getClient().getClient().getDailyInfo());
       TotalPurchases.setText("total purchases:" + "  " + DailyInfoToDisplay.get(2));
        Subscriptions.setText("total Subscriptions:" +  "  " + DailyInfoToDisplay.get(1));
        onetimepurchases.setText("total One Time Purchases:" +  "  " + DailyInfoToDisplay.get(0));
    	}
    	else   // eyal 266
    	{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("No city was selected! ");
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.showAndWait();
    	}
	}
	/**
	 *  This method closes the current window and goes back to the home window, according to the logger's type.
	 * @param event
	 */
	@FXML
	void HomeButton(ActionEvent event) {
		if(LoginController.type.equals("Manager"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}

	}
	/**
	 * This method handles the event where the user click on "LogOut" button to log out from the system
	 * @param event
	 */
	@FXML
	void LogOutButton(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	@FXML
	void WomboCombo(ActionEvent event) {


	}
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	@FXML
	void initialize() {
		assert CitiesCombo != null : "fx:id=\"CitiesCombo\" was not injected: check your FXML file 'DailyReport.fxml'.";
		try {
			Main.getClient().sendToMyCLient("GetCitiesForComboBox");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list;
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
		CitiesCombo.setItems(list);//update the ComboxBox with the list of cities 
		new AutoCompleteComboBoxListener<>(CitiesCombo);
		assert TotalPurchases != null : "fx:id=\"TotalPurchases\" was not injected: check your FXML file 'DailyReport.fxml'.";
		assert Subscriptions != null : "fx:id=\"Subscriptions\" was not injected: check your FXML file 'DailyReport.fxml'.";
		assert InfoBtn != null : "fx:id=\"InfoBtn\" was not injected: check your FXML file 'DailyReport.fxml'.";
		assert onetimepurchases != null : "fx:id=\"onetimepurchases\" was not injected: check your FXML file 'DailyReport.fxml'.";
		assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'DailyReport.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
		assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'DailyReport.fxml'.";
		assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'DailyReport.fxml'.";
		   assert BackBtn != null : "fx:id=\"BackBtn\" was not injected: check your FXML file 'DailyReport.fxml'.";
	}
}
