package Gui;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 *  This class is the GUI controller responsible for showing a catalog that contain cities,maps and places.
 * @author Molham & Soaad
 *
 */
public class CatalogGui {

	ArrayList<String> cities;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private ImageView GcmImage;

	@FXML
	private TextField SearchTxt;

	@FXML
	private RadioButton CityRadio;

	@FXML
	private RadioButton PlaceRadio;

	@FXML
	private RadioButton DescriptionRadio;

	@FXML
	private Label WelcomeLBL;

	@FXML
	private Button LogInBtn;

	@FXML
	private Button SearchBtn;

	@FXML
	private ListView<String> CityList;

	@FXML
	private ListView<String> MapList;

	@FXML
	private ListView<String> PlaceList;

	@FXML
	private Label CityLbl;

	@FXML
	private Label MapLbl;

	@FXML
	private Label PlaceLbl;
	///////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * This method handles the event where the user chose a city from the cities list 
	 * then maps of the selected city will appear.
	 * @param event
	 */
	@FXML
	void CityListFunc(MouseEvent event) {
		if(CityList.getSelectionModel().getSelectedItem()!=null)
		{
			MapList.setItems(null);
			PlaceList.setItems(null);
			ArrayList<String> toServer= new ArrayList<String>();
			toServer.add("GetMapsForList");
			toServer.add(CityList.getSelectionModel().getSelectedItem());
			toServer.add(LoginController.type);                                 
			try {
				Main.getClient().getClient().StringsToServer(toServer);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}//incase the job is to get city names for combobox
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ObservableList<String> list;
			list = FXCollections.observableArrayList(Main.getClient().getClient().getMapsNames());
			MapList.setItems(list);	
		}
	}
	//////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * This method handles the event where the user choose to search maps according to place name.
	 * @param event
	 */
	@FXML
	void PlaceRadioBtn(ActionEvent event) {

		DescriptionRadio.setSelected(false);
		CityRadio.setSelected(false);
	}
	/**
	 * This method handles the event where the user choose to search maps according to city name.
	 * @param event
	 */
	@FXML
	void CityRadioBtn(ActionEvent event) {
		PlaceRadio.setSelected(false);
		DescriptionRadio.setSelected(false);

	}
	/**
	 * This method handles the event where the user choose to search maps according to description.
	 * @param event
	 */
	@FXML
	void DescriptionRadioBtn(ActionEvent event) {
		CityRadio.setSelected(false);
		PlaceRadio.setSelected(false);

	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 *  This method handles the event where the user click on "LogIn" button to log in by user name and password to the system
	 * @param event
	 */
	@FXML
	void LogInButton(ActionEvent event) {

		try {
			( (Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * This method handles the event where the user chose a map from the maps list 
	 * then places of the selected map will appear.
	 * @param event
	 */
	@FXML
	void MapListFunc(MouseEvent event) {
		if(MapList.getSelectionModel().getSelectedItem()!=null)
		{
			PlaceList.setItems(null);
			ArrayList<String> toServer= new ArrayList<String>();
			toServer.add("GetplacesForList");
			toServer.add(MapList.getSelectionModel().getSelectedItem());
			toServer.add(LoginController.type);                               
			try {
				Main.getClient().getClient().StringsToServer(toServer);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}//incase the job is to get city names for combobox
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ObservableList<String> list;
			list = FXCollections.observableArrayList(Main.getClient().getClient().getPlacesNames());
			PlaceList.setItems(list);	
		}

	}
	/**
	 * This method handles the event where the user click on search button 
	 * and showing the results according to the entered text.
	 * @param event
	 */
	@FXML
	void SearchButton(ActionEvent event) {

		if(CityRadio.isSelected())
		{
			if(!SearchTxt.getText().isEmpty())                              //266
			{
				if(cities.contains((String)SearchTxt.getText()))
				{
					CityList.setItems(null);
					ObservableList<String> list1;
					list1 = FXCollections.observableArrayList((String)SearchTxt.getText());
					CityList.setItems(list1);

					MapList.setItems(null);
					PlaceList.setItems(null);
					ArrayList<String> toServer= new ArrayList<String>();
					toServer.add("GetMapsForList");
					toServer.add(SearchTxt.getText());
					toServer.add(LoginController.type);                           
					try {
						Main.getClient().getClient().StringsToServer(toServer);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}//incase the job is to get city names for combobox
					try {
						Thread.currentThread().sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					ObservableList<String> list2;
					list2 = FXCollections.observableArrayList(Main.getClient().getClient().getMapsNames());
					MapList.setItems(list2);
				}
				else                                                     //266
				{
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setContentText("There is no results!");
					alert.setTitle("Note");
					alert.setHeaderText(null);
					alert.showAndWait();
				}
			}
			else                                                        ///266
			{
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Please enter text to search!");
				alert.setTitle("Note");
				alert.setHeaderText(null);
				alert.showAndWait();
			}


		}
		else if(PlaceRadio.isSelected())
		{


			if(!SearchTxt.getText().isEmpty())                       ///266
			{

				ArrayList<String> MapstoServer= new ArrayList<String>();
				MapstoServer.add("GetMapsForCatalogList");
				MapstoServer.add((String)SearchTxt.getText());
				MapstoServer.add(LoginController.type);                                
				try {
					Main.getClient().getClient().StringsToServer(MapstoServer);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}//incase the job is to get city names for combobox
				try {
					Thread.currentThread().sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(!Main.getClient().getClient().getMapsNames().isEmpty())         
				{
					CityList.setItems(null);
					ObservableList<String> list1;
					System.out.println(Main.getClient().getClient().getMapsNames());

					list1 = FXCollections.observableArrayList((String)SearchTxt.getText());
					PlaceList.setItems(list1);
					ObservableList<String> list2;  
					list2 = FXCollections.observableArrayList(Main.getClient().getClient().getMapsNames());
					MapList.setItems(list2);

					ArrayList<String> CitytoServer= new ArrayList<String>();
					CitytoServer.add("GetCityForCatalogList");
					System.out.println(Main.getClient().getClient().getMapsNames().get(0));
					CitytoServer.add(Main.getClient().getClient().getMapsNames().get(0));

					CitytoServer.add(LoginController.type);                                
					try {
						Main.getClient().getClient().StringsToServer(CitytoServer);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}//incase the job is to get city names for combobox
					try {
						Thread.currentThread().sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					ObservableList<String> list3;
					list3 = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
					CityList.setItems(list3);
				}           
				else                                                    ///266
				{
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setContentText("There is no results!");
					alert.setTitle("Note");
					alert.setHeaderText(null);
					alert.showAndWait();
				}
			}
			else                                                     //266
			{
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Please enter text to search!");
				alert.setTitle("Note");
				alert.setHeaderText(null);
				alert.showAndWait();
			}

		}
		else if(DescriptionRadio.isSelected())
		{
			if(!SearchTxt.getText().isEmpty())                                    //266
			{ 
				CityList.setItems(null);
				PlaceList.setItems(null);
				ArrayList<String> DescriptiontoFindMap= new ArrayList<String>();
				DescriptiontoFindMap.add("DescriptionToFindMap");
				DescriptiontoFindMap.add((String)SearchTxt.getText());
				DescriptiontoFindMap.add(LoginController.type);                              
				try {
					Main.getClient().getClient().StringsToServer(DescriptiontoFindMap);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}//incase the job is to get city names for combobox
				try {
					Thread.currentThread().sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(!Main.getClient().getClient().getMapsNames().isEmpty())
				{
					ObservableList<String> list2;  
					list2 = FXCollections.observableArrayList(Main.getClient().getClient().getMapsNames());
					MapList.setItems(list2);
				}
				else                                                        //266
				{
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setContentText("There is no results!");
					alert.setTitle("Note");
					alert.setHeaderText(null);
					alert.showAndWait();
				}

			} 
			else                                                                      //266
			{
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Please enter text to search!");
				alert.setTitle("Note");
				alert.setHeaderText(null);
				alert.showAndWait();
			}
		}
		else                                                                          ///266
		{
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Please choose search category");
			alert.setTitle("Note");
			alert.setHeaderText(null);
			alert.showAndWait();
		}



	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	
	@FXML
	void initialize() {
		assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'Catalog.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);

		assert SearchTxt != null : "fx:id=\"SearchTxt\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert CityRadio != null : "fx:id=\"CityRadio\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert PlaceRadio != null : "fx:id=\"PlaceRadio\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert DescriptionRadio != null : "fx:id=\"DescriptionRadio\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert WelcomeLBL != null : "fx:id=\"WelcomeLBL\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert LogInBtn != null : "fx:id=\"LogInBtn\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert SearchBtn != null : "fx:id=\"SearchBtn\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert CityList != null : "fx:id=\"CityList\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert MapList != null : "fx:id=\"MapList\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert PlaceList != null : "fx:id=\"PlaceList\" was not injected: check your FXML file 'Catalog.fxml'.";
		cities= new ArrayList<String>();
		try {
			LoginController.type="Customer";    
			Main.getClient().sendToMyCLient("GetCitiesForComboBox");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//incase the job is to get city names for combobox
		try {
			Thread.currentThread().sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list;

		list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
		CityList.setItems(list);

		cities= Main.getClient().getClient().getCityNames();
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assert CityLbl != null : "fx:id=\"CityLbl\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert MapLbl != null : "fx:id=\"MapLbl\" was not injected: check your FXML file 'Catalog.fxml'.";
		assert PlaceLbl != null : "fx:id=\"PlaceLbl\" was not injected: check your FXML file 'Catalog.fxml'.";

	}
}