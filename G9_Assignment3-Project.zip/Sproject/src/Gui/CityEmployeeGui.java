package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.CityController;
import Controller.LoginController;
import Controller.MapController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *  This class is the GUI controller responsible for showing maps that related to the selected city from the previews page
 *   user can edit this maps by adding new places, descriptions and tours.
 * @author Molham & Anan
 */
public class CityEmployeeGui {              

	ArrayList<String> CityMap;
	
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField SearchTXT;

    @FXML
    private Button searchBtn;


    @FXML
    private ListView<String> MapList;

    @FXML
    private Button ShowProfileBtn;

    @FXML
    private Label MapsLbl;

    @FXML
    private Label CityName;

    @FXML
    private Button LogOutBtn;


    @FXML
    private Button EditMapBtn;

    @FXML
    private Button EditPlaceBtn;

    @FXML
    private Button EditTours;

    @FXML
    private Label MapDescriptionLbl;

    @FXML
    private TextArea DescriptionTxt;

    @FXML
    private Button SaveDescriptionBtn;
    
    @FXML
    private ImageView GcmImage;

    @FXML
    private Button HomeBtn;


    @FXML
    private Button BuyCity;

    /**
	 * This method handles the event where the user click on "buy" button 
	 * the current window will be closed and goes to the "buy" page.
	 * @param event 
	 */
    @FXML
    void BuyPage(ActionEvent event) {
    	try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Purchase.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	
    }
    
    /**
   	 * This method handles the event where the user click on "EditMap" button 
   	 * user can editing the selected map by adding new places or changing cordinates of existing places .
   	 * @param event 
   	 */
    @FXML
    void EditMapButton(ActionEvent event) {

    	try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Map.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	
    	
    }
    /**
   	 * This method handles the event where the user click on "Editplace" button 
   	 * and adding new places or editing existing places.
   	 * @param event 
   	 */
    @FXML
    void EditPlaceButton(ActionEvent event) {
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/EditPlace.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	
    	
    }
    /**
   	 * This method handles the event where the user click on "EditTours" button 
   	 * and adding new tours or editing existing tours.
   	 * @param event 
   	 */
    @FXML
    void EditToursButton(ActionEvent event) {

    	try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/AddTour.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	
    	
    }
    /**
     * * This method closes the current window and goes back to the "Home" window, according to the logger's type.
     * @param event
     */

    @FXML
    void HomeButton(ActionEvent event) {

    	if(LoginController.type.equals("Employee"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
    	
    	
    }
    /**
	 * This method handles the event where the user click on "LogOut" button to log out from the system
	 * @param event
	 */
    @FXML
    void LogOutButton(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    /**
   	 * This method handles the event where the user click on one of the maps in the list, user can view the description 
   	 * of the selected map and places.
   	 * @param event 
   	 */
    @FXML
    void MapsListFunc(MouseEvent event) {
    	if(!(MapList.getSelectionModel().isEmpty()))
    	{
    		MapController.MapName=MapList.getSelectionModel().getSelectedItem();
    	   ArrayList<String> toServer= new ArrayList<String>();
       	toServer.add("GetDescription");
       	toServer.add(MapList.getSelectionModel().getSelectedItem());
       	toServer.add(LoginController.type);                                          ////256
       	try {
            	Main.getClient().getClient().StringsToServer(toServer);
            } catch (IOException e1) {
            	// TODO Auto-generated catch block
            	e1.printStackTrace();
            }//incase the job is to get city names for combobox
             try {
            		Thread.currentThread().sleep(1000);
            	} catch (InterruptedException e) {
            		// TODO Auto-generated catch block
            		e.printStackTrace();
            	}
             DescriptionTxt.setText(Main.getClient().getClient().getS());
    }
    }
    /**
   	 * This method handles the event where the user need to add/edit description of the selected map.
   	 *  he will click on Save description after he changed
   	 * @param event 
   	 */
    @FXML
    void SaveDescriptionButton(ActionEvent event) {
      if(DescriptionTxt.getText()!=null)
      {
    	  ArrayList<String> toServer=new ArrayList<String>();
    	  toServer.add("UpdateDescriptionToMap");
    	  toServer.add(DescriptionTxt.getText());
    	  toServer.add(MapList.getSelectionModel().getSelectedItem());
    	  try {
          	Main.getClient().getClient().StringsToServer(toServer);
          } catch (IOException e1) {
          	// TODO Auto-generated catch block
          	e1.printStackTrace();
          }//incase the job is to get city names for combobox
           try {
          		Thread.currentThread().sleep(1000);
          	} catch (InterruptedException e) {
          		// TODO Auto-generated catch block
          		e.printStackTrace();
          	}
      }
    	
    	
    }
    /**
	 *  This method closes the current window and goes back to the profile window.
	 * @param event
	 */

    @FXML
    void ShowProfileButton(ActionEvent event) {
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/UserProfile.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
    	} catch (IOException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}//build the gui
    }
	/**
	 * This method handles the event where the user click on search button 
	 * and showing the results according to the entered text, by description of map
	 * @param event
	 */
    @FXML
    void searchButton(ActionEvent event) {
    	ArrayList<String> SearchMaps=new ArrayList<String>();
    	ArrayList<String> DescriptiontoFindMap= new ArrayList<String>();
    	DescriptiontoFindMap.add("DescriptionToFindMap");
    	DescriptiontoFindMap.add((String)SearchTXT.getText());
    	DescriptiontoFindMap.add(LoginController.type);                   ///256
    	try {
    		Main.getClient().getClient().StringsToServer(DescriptiontoFindMap);
    	} catch (IOException e1) {
    		// TODO Auto-generated catch block
    		e1.printStackTrace();
    	}//incase the job is to get city names for combobox
    	try {
    		Thread.currentThread().sleep(1000);
    	} catch (InterruptedException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    	if(Main.getClient().getClient().getMapsNames().size()!=0)
    	{
    		for(int i=0;i<CityMap.size();i++)
    		{
    			for(int j=0;j<Main.getClient().getClient().getMapsNames().size();j++)
    			{
    				if(CityMap.get(i).equals(Main.getClient().getClient().getMapsNames().get(j)))
    				{
    					SearchMaps.add(CityMap.get(i));
    				}
    			}
    		}
    		ObservableList<String> list2; 
    		MapList.setItems(null);
    		list2 = FXCollections.observableArrayList(SearchMaps);
    		MapList.setItems(list2);
    		if(SearchMaps.size()==0)
    		{
    			for(int i=0;i<CityMap.size();i++)
    			{
    				if(CityMap.get(i).equals((String)SearchTXT.getText()))
    				{
    					SearchMaps.add(CityMap.get(i));
    				}

    			}
    			ObservableList<String> list3;  
    			list3 = FXCollections.observableArrayList(SearchMaps);
    			MapList.setItems(list3);
    		}
    	}
    	else
    	{
    	
    		MapList.setItems(null);
    	}
    	
    	
    }
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */

    @FXML
    void initialize() {
    	   
        assert SearchTXT != null : "fx:id=\"SearchTXT\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert searchBtn != null : "fx:id=\"searchBtn\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert MapList != null : "fx:id=\"MapList\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        CityMap=new ArrayList<String>();
        ArrayList<String> toServer= new ArrayList<String>();
    	toServer.add("GetMapsForList");
    	toServer.add(CityController.CityName);
    	toServer.add(LoginController.type);                                   ////256
    	try {
         	Main.getClient().getClient().StringsToServer(toServer);
         } catch (IOException e1) {
         	// TODO Auto-generated catch block
         	e1.printStackTrace();
         }//incase the job is to get city names for combobox
          try {
         		Thread.currentThread().sleep(1000);
         	} catch (InterruptedException e) {
         		// TODO Auto-generated catch block
         		e.printStackTrace();
         	}
         ObservableList<String> list;
         CityMap=Main.getClient().getClient().getMapsNames();
         list = FXCollections.observableArrayList(Main.getClient().getClient().getMapsNames());
         MapList.setItems(list);
        
     
        assert ShowProfileBtn != null : "fx:id=\"ShowProfileBtn\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert MapsLbl != null : "fx:id=\"MapsLbl\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert CityName != null : "fx:id=\"CityName\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        CityName.setText(CityController.CityName);
        assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert EditMapBtn != null : "fx:id=\"EditMapBtn\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert EditPlaceBtn != null : "fx:id=\"EditPlaceBtn\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert EditTours != null : "fx:id=\"EditTours\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert MapDescriptionLbl != null : "fx:id=\"MapDescriptionLbl\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert DescriptionTxt != null : "fx:id=\"DescriptionTxt\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert SaveDescriptionBtn != null : "fx:id=\"SaveDescriptionBtn\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'CityEmployee.fxml'.";
    	Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'CityEmployee.fxml'.";
        assert BuyCity != null : "fx:id=\"BuyCity\" was not injected: check your FXML file 'CityEmployee.fxml'.";

        

    }
}
