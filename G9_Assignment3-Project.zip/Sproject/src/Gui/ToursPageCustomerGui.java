package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.CityController;
import Controller.LoginController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * This class is for reviewing the tours for the customers.
 * @author Sahar + Soaad
 *
 */
public class ToursPageCustomerGui {

	ArrayList<String> Tnames;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private ImageView GcmImage;

	@FXML
	private Label TitleId;

	@FXML
	private ListView<String> PlacesList;

	@FXML
	private Button LogOutBtn;

	@FXML
	private Button HomeBtn;

	@FXML
	private Label PlacesLbl;

	@FXML
	private Button BackBtn;

	@FXML
	private ListView<String> ToursList;

	@FXML
	private Label toursLabel;

	@FXML
	private Label CityNameLbl;

	@FXML
	private TextField CityNameTxt;

	@FXML
	private TextArea DescriptionTxt;

	@FXML
	private Label DescriptionLbl;

	@FXML
	private Label TimeLbl;

	@FXML
	private TextField TimeTxt;
/**
 * this method handles the back button, that gets the user to previos page. 
 * @param event
 */
	@FXML
	void BackButton(ActionEvent event) {
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityGuiCustomer.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
	}

	 /**
     * this method handles the home button that takes back to the home page according to the logger's type
     * @param event
     */
	@FXML
	void HomeButton(ActionEvent event) {
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
	}
	 /**
     * this method handles the logout button that makes the user logs out from the app
     * @param event
     */
	@FXML
	void LogOutButton(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
	}

	/**
	 * this method handles the clicks on the tour list, when the user chose a tour from the list,
	 * the system while show him the places in this tour and the description
	 * @param event
	 */
	@FXML
	void ToursListOnClick(MouseEvent event) {
		if(ToursList.getSelectionModel().getSelectedItem()!=null) // eyal 266
		{
			ArrayList<String> placesInTour=new ArrayList<String>();
			placesInTour.add("getPlacesForTour");
			placesInTour.add(ToursList.getSelectionModel().getSelectedItem());
			placesInTour.add(LoginController.type);                                     ///256
			try {
				Main.getClient().getClient().StringsToServer(placesInTour);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}//incase the job is to get city names for combobox
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ObservableList<String> list;

			list = FXCollections.observableArrayList(Main.getClient().getClient().getPlacesNames());
			PlacesList.setItems(list);

			ArrayList<String> TourDetails=new ArrayList<String>();
			TourDetails.add("getTourDetails");
			TourDetails.add(ToursList.getSelectionModel().getSelectedItem());
			TourDetails.add(LoginController.type);                                    ////256 
			try {
				Main.getClient().getClient().StringsToServer(TourDetails);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}//incase the job is to get city names for combobox
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DescriptionTxt.setText(Main.getClient().getClient().getTourDetails().get(0));
			DescriptionTxt.setEditable(false);
			TimeTxt.setText(Main.getClient().getClient().getTourDetails().get(1));
			TimeTxt.setEditable(false);

		}
		else 
		{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("No tour was selected! ");
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.showAndWait();
		}

	}
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	@FXML
	void initialize() {
		assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
		assert TitleId != null : "fx:id=\"TitleId\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert PlacesList != null : "fx:id=\"PlacesList\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert PlacesLbl != null : "fx:id=\"PlacesLbl\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert BackBtn != null : "fx:id=\"BackBtn\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert ToursList != null : "fx:id=\"ToursList\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";

		Tnames =new ArrayList<String>();
		Tnames.add("GetToursForCity");
		Tnames.add(CityController.getCityName());
		Tnames.add(LoginController.type);                                ////256
		try {
			Main.getClient().getClient().StringsToServer(Tnames);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//incase the job is to get city names for combobox
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list;
		list = FXCollections.observableArrayList(Main.getClient().getClient().getToursNames());
		ToursList.setItems(list);
		assert toursLabel != null : "fx:id=\"toursLabel\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert CityNameLbl != null : "fx:id=\"CityNameLbl\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert CityNameTxt != null : "fx:id=\"CityNameTxt\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		CityNameTxt.setText(CityController.getCityName());
		CityNameTxt.setEditable(false);
		assert DescriptionTxt != null : "fx:id=\"DescriptionTxt\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert DescriptionLbl != null : "fx:id=\"DescriptionLbl\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert TimeLbl != null : "fx:id=\"TimeLbl\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";
		assert TimeTxt != null : "fx:id=\"TimeTxt\" was not injected: check your FXML file 'ToursPageCustomer.fxml'.";

	}
}
