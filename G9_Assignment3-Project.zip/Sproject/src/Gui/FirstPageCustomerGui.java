package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.CityController;
import Controller.LoginController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * this class is responsible for representing and handling all the actions in the first customer page 
 * @author sahar & eyal
 *
 */
public class FirstPageCustomerGui {
	   ArrayList<String> cities;
	   CityController cityName;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    private Button LogOutBtn;

    @FXML
    private Button ProfileBtn;
    @FXML
    private Button viewmessageBtn;


    @FXML
    private Button HomeBtn;

    @FXML
    private ImageView GcmImage;

    @FXML
    private Label TitleId;

    @FXML
    private TextField SearchTxt;

    @FXML
    private Button SearchBtn;

    @FXML
    private Label CityLbl;

    @FXML
    private ListView<String> CityList;
    /**
     * this handles the action of select a city from the city listview , forwarding the user (employee in this case) to the city's page
     * @param event
     */
    @FXML
    void CityListFunc(MouseEvent event) {
  if(CityList.getSelectionModel().getSelectedItem()!=null)
  {
    	cityName.setCityName(CityList.getSelectionModel().getSelectedItem());
    try {
    	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityGuiCustomer.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
		Stage stage = new Stage();
		stage.setScene(scene);
		((Node) event.getSource()).getScene().getWindow().hide(); 
		stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
  }
    	
    	
    }
    /**
	 * this method works as a handler for a click on the view message button, it forwards the user to his messages page
	 * @param event
	 */
    @FXML
    void viewmessage(ActionEvent event) {
    	 try {
    	    	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/MyMessages.fxml"));
    			Scene scene = new Scene(root);
    			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
    			Stage stage = new Stage();
    			stage.setScene(scene);
    			((Node) event.getSource()).getScene().getWindow().hide(); 
    			stage.show();
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}//build the gui
    }

    /**
     * this button works as a handler that closes the current page and returns the user to the home page according to the user's type
     * @param event
     */
    @FXML
    void HomeButton(ActionEvent event) {
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    /**
     * this method is used as a handler for clicking the logout button, it logs out the client returning him to the login page
     * and removing him from the list of online users
     * @param event
     */
    @FXML
    void LogOutButton(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
     	try {
        	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
    		Scene scene = new Scene(root);
    		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
    		Stage stage = new Stage();
    		stage.setScene(scene);
    		((Node) event.getSource()).getScene().getWindow().hide(); 
    		stage.show();
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}//build the gui
        	
    }
    /**
     * this method works as a handler for a click on the profile button , it forwards the user to his profile page
     * @param event
     */
    @FXML
    void ProfileButton(ActionEvent event) {
    	try {
        	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/UserProfile.fxml"));
    		Scene scene = new Scene(root);
    		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
    		Stage stage = new Stage();
    		stage.setScene(scene);
    		((Node) event.getSource()).getScene().getWindow().hide(); 
    		stage.show();
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}//build the gui
    }
    /**
	    * this method works as a handler for a click on the search button, it searches the city's listview for an entered input
	    * @param event
	    */
    @FXML
    void SearchButton(ActionEvent event) {

    	String s =new String(SearchTxt.getText());
    	ArrayList<String> result=new ArrayList<String>();
    	int flag=0;
    	if(s=="")
    	{
    		 Alert alert = new Alert(AlertType.INFORMATION);
			 alert.setContentText("Please enter text to search!");
			 alert.setTitle("Note");
			 alert.setHeaderText(null);
			 alert.showAndWait();
			 
			 
    	}
    	else
    	{
    		for(int i=0;i<cities.size();i++)
    		{
    			if(s.equals(cities.get(i)))
    			{
    				result.add(s);
    				flag=1;
    			}
    			
    		}
    		if(flag==0)
    		{
    			 Alert alert = new Alert(AlertType.INFORMATION);
    			 alert.setContentText("There is no results!");
    			 alert.setTitle("Note");
    			 alert.setHeaderText(null);
    			 alert.showAndWait();
    		}
    		else
    		{
    			 ObservableList<String> list;
    		    list = FXCollections.observableArrayList(result);
    	        CityList.setItems(list);
    		}
    	}
    	
    	
    	
    }
    /**
     * this method is called when the fxml file is loaded, it initializes the variables and some Gui elements.
     */
    @FXML
    void initialize() {
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'FirstPageCus.fxml'.";
   	    Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
	    assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'FirstPageCustomer.fxml'.";
        assert ProfileBtn != null : "fx:id=\"ProfileBtn\" was not injected: check your FXML file 'FirstPageCustomer.fxml'.";
        assert TitleId != null : "fx:id=\"TitleId\" was not injected: check your FXML file 'FirstPageCus.fxml'.";
        assert SearchTxt != null : "fx:id=\"SearchTxt\" was not injected: check your FXML file 'FirstPageCus.fxml'.";
        assert SearchBtn != null : "fx:id=\"SearchBtn\" was not injected: check your FXML file 'FirstPageCus.fxml'.";
        assert CityLbl != null : "fx:id=\"CityLbl\" was not injected: check your FXML file 'FirstPageCus.fxml'.";
        assert CityList != null : "fx:id=\"CityList\" was not injected: check your FXML file 'FirstPageCus.fxml'.";
        assert viewmessageBtn != null : "fx:id=\"viewmessageBtn\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
        cityName= new CityController();
        cities =new ArrayList<String>();
        try {
        	Main.getClient().sendToMyCLient("GetCitiesForComboBox");
        } catch (IOException e1) {
        	// TODO Auto-generated catch block
        	e1.printStackTrace();
        }//incase the job is to get city names for combobox
         try {
        		Thread.currentThread().sleep(1000);
        	} catch (InterruptedException e) {
        		// TODO Auto-generated catch block
        		e.printStackTrace();
        	}
        ObservableList<String> list;
      
        list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
        CityList.setItems(list);

        cities= Main.getClient().getClient().getCityNames();
        try {
    		Thread.currentThread().sleep(1000);
    	} catch (InterruptedException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'FirstPageCustomer.fxml'.";

    }
}
