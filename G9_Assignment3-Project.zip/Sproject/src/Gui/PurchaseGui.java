package Gui;


import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

import Controller.DownloadController;
import Controller.LoginController;
import Controller.ReportController;
import application.Main;
import entities.Purchase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;
/**
 * This class for displaying the Purchase page for buying cities. 
 * @author Soaad + Anan
 *
 */
public class PurchaseGui  {

	ReportController reportController;
	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private ComboBox<String> ComboBoxCity;

	@FXML
	private RadioButton OneTimeRad;

	@FXML
	private DatePicker DatePicker;

	@FXML
	private Button PurchaseBtn;
	@FXML
	private DatePicker endDatePicker;

	@FXML
	private ImageView GcmImage;

	@FXML
	private Label PurchaseLbl;

	@FXML
	private Button LogOutBtn;

	@FXML
	private Button HomeBtn;

	@FXML
	private Button cancelBTN;

	@FXML
	private TextField PriceText;

	@FXML
	private TextField discountText;
	@FXML
	private Label pricelbl;

	@FXML
	private Label discountlbl;

	/**
	 * this method handles the cancel button, when the user clicks on this button he will cancels the 
	 * buying operation
	 * @param event
	 */
	@FXML
	void Cancel(ActionEvent event) {
		if(LoginController.type.equals("Employee")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (LoginController.type.equals("Manager")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Customer"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Big Boss"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}

	}


	/**
	 * this method handles the clicks on the combo box city list.
	 * after clicking on the city, the price will appears.
	 * @param event
	 * @throws InterruptedException
	 */
	@FXML
	void CmbCity(ActionEvent event) throws InterruptedException {
		String id;
		if((String)ComboBoxCity.getSelectionModel().getSelectedItem()!=null) 
		{
			ArrayList<String> getprice=new ArrayList<String>();
			getprice.add("getprice");
			getprice.add((String)ComboBoxCity.getSelectionModel().getSelectedItem());
			id=LoginController.id; // HAS TO BE CUSTOMER ID
			getprice.add(id);

			try {
				Main.getClient().getClient().StringsToServer(getprice);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			double price=Main.getClient().getClient().getPrice();
			String pricetxt = Double.toString(price);	
			this.PriceText.setText(pricetxt);
			if(OneTimeRad.isSelected()) {
				this.discountText.setText("No Discount");
				this.discountText.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");}
			else if(Main.getClient().getClient().isDiscount())
			{
				this.discountText.setText("Discount Applied");
				this.discountText.setStyle("-fx-text-fill: green; -fx-font-size: 16px;");
			}
			else {
				this.discountText.setText("No Discount");
				this.discountText.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");
			}
		}
	}
	 /**
     * this method handles the home button that takes back to the home page according to the logger's type
     * @param event
     */
	@FXML
	void HomeButton(ActionEvent event) {
		if(LoginController.type.equals("Employee")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (LoginController.type.equals("Manager")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Customer"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Big Boss"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}


	}
	 /**
     * this method handles the logout button that makes the user logs out from the app
     * @param event
     */
	@FXML
	void LogOutButton(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * this method handles the One Time Purchase. 
	 * after clicking on this button the user can download the city once 
	 * @param event
	 */
	@FXML
	void OneTimePurchase(ActionEvent event) {
		if(OneTimeRad.isSelected()) {
			if(Main.getClient().getClient().isDiscount()) {
				double price=Main.getClient().getClient().getPrice();
				price= price/90 * 100;
				String pricetxt = Double.toString(price);	
				this.PriceText.setText(pricetxt);
			}
			DatePicker.setDisable(true);
			endDatePicker.setDisable(true);
			this.discountText.setText("No Discount");
			this.discountText.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");
		}
		else {
			DatePicker.setDisable(false);
			endDatePicker.setDisable(false);
			if(Main.getClient().getClient().isDiscount()) {
				this.discountText.setText("Discount Applied");
				this.discountText.setStyle("-fx-text-fill: green; -fx-font-size: 16px;");
				double price=Main.getClient().getClient().getPrice();
				String pricetxt = Double.toString(price);	
				this.PriceText.setText(pricetxt);
			}
			else {
				this.discountText.setText("No Discount");
				this.discountText.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");
			}
		}
	}

	@FXML
	void PickDate(ActionEvent event) {
	}
	/**
	 * this method handles the date picker, it will save the date that the user chose.
	 * @param event
	 */
	@FXML
	void endDatePickerHandle(ActionEvent event) {
		if(DatePicker.getValue().compareTo(endDatePicker.getValue()) > 0)
		{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("End Date cannot earlier than start date!!!");
			alert.setTitle("Failed" );
			alert.setHeaderText(null);
			alert.showAndWait();
			endDatePicker.getEditor().clear();
		}	    	
	}
	/**
	 * this method handles Purchase button, after clicking on this button 
	 * he will be able to review the city's information and maps
	 * @param event
	 */
	@FXML
	void PurchaseBtn(ActionEvent event) {
		if((String)ComboBoxCity.getSelectionModel().getSelectedItem()!=null) // eyal 266
		{
			int flag=1;
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setContentText("Are you sure you wish to buy this city?!");
			alert.setTitle("Confirmation");
			alert.setHeaderText(null);
			Optional<ButtonType> result=alert.showAndWait();
			if(result.get() == ButtonType.OK)
			{
				if((!(OneTimeRad.isSelected())))
				{
					Purchase purchase = new Purchase();
					purchase.setCityname((String)ComboBoxCity.getSelectionModel().getSelectedItem());
					purchase.setCustomerid(LoginController.id);; // HAS TO BE CUSTOMER ID
					purchase.setDateStart(DatePicker.getValue());
					purchase.setDateEnd(endDatePicker.getValue());
					purchase.setPurchaseType("subscription");
					purchase.setPurchaseDate(LocalDate.now());
					try {
						Main.getClient().getClient().AddingNewData(purchase);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						Thread.currentThread().sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(Main.getClient().getClient().getS().equals("CityAlreadyPurchased"))
					{
						Alert alert1 = new Alert(AlertType.CONFIRMATION);
						alert1.setContentText("City Already Purchased!!! Do you wish to renew this subscription?");
						alert1.setTitle("Renew" );
						alert1.setHeaderText(null);
						Optional<ButtonType> result2= alert1.showAndWait();
						if(result2.get()==ButtonType.OK)
						{
							purchase.setPurchaseType("renew");
							try {
								Main.getClient().getClient().AddingNewData(purchase);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						}
					}

				}        
				else
				{
					Purchase purchase = new Purchase();
					purchase.setCityname((String)ComboBoxCity.getSelectionModel().getSelectedItem());
					purchase.setCustomerid(LoginController.id); // HAS TO BE CUSTOMER ID
					purchase.setPurchaseDate(LocalDate.now());
					purchase.setPurchaseType("OneTime");
					try {
						Main.getClient().getClient().AddingNewData(purchase);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						Thread.currentThread().sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(Main.getClient().getClient().getS().equals("CityAlreadyPurchased"))
					{
						Alert alert1 = new Alert(AlertType.ERROR);
						alert1.setContentText("You already own this city!!");
						alert1.setTitle("Failed" );
						alert1.setHeaderText(null);
						alert1.showAndWait();

						Main.getClient().getClient().setS("trash");
						flag=0;	
					}
					else {
						Alert alert3 = new Alert(AlertType.INFORMATION);
						alert3.setContentText("Thanks for buying! your will now be taken to download page!");
						alert3.setTitle("Download notification" );
						alert3.setHeaderText(null);
						alert3.showAndWait();
						DownloadController.CityToDownload=purchase.getCityname();
						try {
							flag=0;
							((Node) event.getSource()).getScene().getWindow().hide(); 
							Pane root = FXMLLoader.load(getClass().getResource("/Fxml/LoadingDownload.fxml"));
							Scene scene = new Scene(root);
							scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
							Stage stage = new Stage();
							stage.setScene(scene);
							stage.show();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}//build the gui
					} 

				}

			}
			if(flag==1)
			{
				try {
					Pane root = FXMLLoader.load(getClass().getResource("/Fxml/MyCities.fxml"));
					Scene scene = new Scene(root);
					scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
					Stage stage = new Stage();
					stage.setScene(scene);
					((Node) event.getSource()).getScene().getWindow().hide(); 
					stage.show();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}//build the gui
			}		
			else {
				alert.close();
			}
		}
		else   // eyal 266
		{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("No city was selected! ");
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.showAndWait();
		}
	}
	 /**
		 * This method is called when the FXML file is loaded, it initializes the
		 * variables and some GUI elements.
		 */
	@FXML
	void initialize() {
		assert ComboBoxCity != null : "fx:id=\"ComboBoxCity\" was not injected: check your FXML file 'Purchase.fxml'.";
		reportController=new ReportController();
		reportController.GetCityComboBox();
		ObservableList<String> list;
		list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
		ComboBoxCity.setItems(list);//update the ComboxBox with the list of cities 
		new AutoCompleteComboBoxListener<>(ComboBoxCity);
		assert PriceText != null : "fx:id=\"PriceText\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert OneTimeRad != null : "fx:id=\"OneTimeRad\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert DatePicker != null : "fx:id=\"DatePicker\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert PurchaseLbl != null : "fx:id=\"PurchaseLbl\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'Purchase.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
		assert PurchaseBtn != null : "fx:id=\"PurchaseBtn\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert cancelBTN != null : "fx:id=\"cancelBTN\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert discountText != null : "fx:id=\"discountText\" was not injected: check your FXML file 'Purchase.fxml'.";
		assert endDatePicker != null : "fx:id=\"endDatePicker\" was not injected: check your FXML file 'Purchase.fxml'.";
		LocalDate in6months=LocalDate.now();
		in6months=in6months.plusMonths(6);
		endDatePicker.setValue(in6months); // Max date available will be the date + 6 months
		DatePicker.setValue(LocalDate.now());
		final Callback<DatePicker, DateCell> dayCellFactory;

		dayCellFactory = (final DatePicker datePicker) -> new DateCell() {
			@Override
			public void updateItem(LocalDate item, boolean empty) {
				super.updateItem(item, empty);
				if (item.isAfter(endDatePicker.getValue())) { //Disable all dates after required date
					setDisable(true);
					setStyle("-fx-background-color: #ffc0cb;"); //To set background on different color
				}
			}
		};
		LocalDate minDate;
		LocalDate maxDate;
		minDate = LocalDate.now();
		maxDate = minDate.plusMonths(6);
		DatePicker.setDayCellFactory(d ->
		new DateCell() {
			@Override public void updateItem(LocalDate item, boolean empty) {
				super.updateItem(item, empty);
				setDisable(item.isBefore(minDate));
			}});
		endDatePicker.setDayCellFactory(d ->
		new DateCell() {
			@Override public void updateItem(LocalDate item, boolean empty) {
				super.updateItem(item, empty);
				setDisable(item.isAfter(maxDate));
			}});
	}}