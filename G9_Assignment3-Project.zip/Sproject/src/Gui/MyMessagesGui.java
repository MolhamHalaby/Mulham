package Gui;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import entities.Message;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

/**
 * this class handles the messages page, displaying all message with titles to the user and allowing him to reply and take 
 * actions according to what he wants
 * @author eyal
 *
 */
public class MyMessagesGui {

	int i;
	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private ImageView LogoImg;

	@FXML
	private Button LogOutBtn;

	@FXML
	private Button ProfileBtn;

	@FXML
	private Button HomeBtn;

	@FXML
	private ListView<String> MessagesList;

	@FXML
	private Button BackBtn;

	@FXML
	private TextField answerTitle;

	@FXML
	private TextArea ReceivedMsg;

	@FXML
	private TextArea AnswerMsg;

	@FXML
	private Button SendBtn;
/**
 * a method to handle a click on the back button in the page, it returns him to his previously visited page (first page according to type)
 * @param event
 */
	@FXML
	void BackBtn(ActionEvent event) { // to do functionality for the previous page        ///266

		if(LoginController.type.equals("Employee")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (LoginController.type.equals("Manager")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Customer"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Big Boss"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		
	}
	 /**
     * this button works as a handler that closes the current page and returns the user to the home page according to the user's type
     * @param event
     */
	@FXML
	void HomeBtn(ActionEvent event) {  ////// be careful that the Types are OK and the firstPage.fxml is OK 

		if(LoginController.type.equals("Employee")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (LoginController.type.equals("Manager")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Customer"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Big Boss"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	 /**
     * this method is used as a handler for clicking the logout button, it logs out the client returning him to the login page
     * and removing him from the list of online users
     * @param event
     */
	@FXML
	void LogOutBtn(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
/**
 * this method handles a click on the title of a message list , it gets the message according to the title and displays it in the 
 * messages listview for the user to read
 * @param event
 */
	@FXML
	void MessagesList(MouseEvent event) {
		i=-1;
		if(MessagesList.getSelectionModel().getSelectedItem()!=null)
		{	
			Message Messages1= new Message();

			try {
				Main.getClient().sendToMyCLient("GetMessages");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Messages1= Main.getClient().getClient().getMessage();
			ObservableList<String> list1;
			ObservableList<String> list2;
			list1 = FXCollections.observableArrayList(Main.getClient().getClient().getMessage().getTitles());
			i=	MessagesList.getSelectionModel().getSelectedIndex();

			list2 = FXCollections.observableArrayList(Main.getClient().getClient().getMessage().getMessages());
			ReceivedMsg.setText(list2.get(i));
		}
	}
	 /**
     * this method works as a handler for a click on the profile button , it forwards the user to his profile page
     * @param event
     */
	@FXML
	void ProfileBtn(ActionEvent event) {// be careful for the fxml of the profile page!!!
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Profile.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
/**
 * this method handles the cick on the send button , it fills up the reciever and sender along with the message accordingly
 * and sends the message to be added to the database and sent to the reciever
 * @param event
 * @throws IOException
 */
	@FXML
	void SendBtn(ActionEvent event) throws IOException { // to do functionality of the sending message!!
		int index=0;
		String sendTo;
		String receivedMessage;
		receivedMessage = ReceivedMsg.getText();
		String answer;
		answer = AnswerMsg.getText();
		ArrayList<String> numOfMessages = new ArrayList<String>();
		numOfMessages= Main.getClient().getClient().getMessage().getdateOfMessage();
		if (answer!=null)
		{
			index=Main.getClient().getClient().getMessage().getMessages().indexOf(receivedMessage);
			sendTo=Main.getClient().getClient().getMessage().getSenders().get(index);

			Message sendBack = new Message();
			sendBack.setRtnMessage(answer);
			sendBack.setRtnReceiver(sendTo);
			sendBack.setRtnSender(Main.getClient().getClient().getMessage().getReceivers().get(index));
			sendBack.setRtnTitle(answerTitle.getText());
			sendBack.setRtnDate(LocalDate.now());
			Main.getClient().getClient().AddingNewData(sendBack);

			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setContentText("The Message To " +sendTo+ " Was Sent Successfully");       //266
			alert.setTitle("Success");
			alert.setHeaderText(null);
			alert.showAndWait();
			answerTitle.setText(null);
			AnswerMsg.setText(null);
		}
		else {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("No Message was sent");
			alert.setTitle("ERROR");
			alert.setHeaderText(null);
			alert.showAndWait();
		}
	}


	/**
     * this method is called when the fxml file is loaded, it initializes the variables and some Gui elements.
     */
	@FXML
	void initialize() {
		i=-1;
		assert LogoImg != null : "fx:id=\"LogoImg\" was not injected: check your FXML file 'MyMessages.fxml'.";

		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		LogoImg.setImage(logo);

		assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'MyMessages.fxml'.";
		assert ProfileBtn != null : "fx:id=\"ProfileBtn\" was not injected: check your FXML file 'MyMessages.fxml'.";
		assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'MyMessages.fxml'.";
		assert MessagesList != null : "fx:id=\"MessagesList\" was not injected: check your FXML file 'MyMessages.fxml'.";

		Message Messages= new Message();

		try {
			Main.getClient().sendToMyCLient("GetMessages");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Messages= Main.getClient().getClient().getMessage();

		ObservableList<String> list3;
		list3 = FXCollections.observableArrayList(Main.getClient().getClient().getMessage().getTitles());
		MessagesList.setItems(list3);

		assert BackBtn != null : "fx:id=\"BackBtn\" was not injected: check your FXML file 'MyMessages.fxml'.";
		assert ReceivedMsg != null : "fx:id=\"ReceivedMsg\" was not injected: check your FXML file 'MyMessages.fxml'.";
		assert AnswerMsg != null : "fx:id=\"AnswerMsg\" was not injected: check your FXML file 'MyMessages.fxml'.";
		assert SendBtn != null : "fx:id=\"SendBtn\" was not injected: check your FXML file 'MyMessages.fxml'.";
		assert answerTitle != null : "fx:id=\"answerTitle\" was not injected: check your FXML file 'MyMessages.fxml'.";

	}
}
