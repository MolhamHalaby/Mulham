package Gui;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.DownloadController;
import Controller.LoginController;
import application.Main;
import entities.DownloadMap;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * this class handles the my cities page, displaying the user's owned cities and giving him option to download it.
 * @author anan & eyal
 *
 */
public class MyCitiesGui {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label MyCitiesLBL;

    @FXML
    private ImageView GcmImage;

    @FXML
    private ListView<String> MyCitiesList;

    @FXML
    private Button LogOutBtn;

    @FXML
    private Button HomeBtn;

    @FXML
    private Button DownloadBtn;
/**
 * this method handles the event of clicking on the download button , downloading the cities along with the places text files
 * to the user's downloads in his computer
 * @param event
 */
    @FXML
    void DownloadCity(ActionEvent event) {
    	
if(!MyCitiesList.isDisable())
{
    	if((MyCitiesList.getSelectionModel().getSelectedItem()!=null))
    	{
    		DownloadController.CityToDownload=(String)MyCitiesList.getSelectionModel().getSelectedItem();
    		DownloadController Downloader=new DownloadController();
    		ArrayList<String> DownloadMyCity = new ArrayList<String>();
    		DownloadMyCity.add("DownloadMap");
    		DownloadMyCity.add(Downloader.CityToDownload);
    		try {
    			Downloader.DownloadMap(DownloadMyCity);
    		} catch (IOException e1) {
    			// TODO Auto-generated catch block
    			e1.printStackTrace();
    		}
    		try {
    			Thread.currentThread().sleep(1000);
    		} catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    		DownloadMap gettingmaps=new DownloadMap();
    		gettingmaps=Main.getClient().getClient().getTransferdata();
    		int i=0;
    		int j=0;
    		while(i<gettingmaps.getImages().size())
    		{
    			 byte barr[];
    			try {
    				String home = System.getProperty("user.home");
    				FileOutputStream fout=new FileOutputStream(home+"/Downloads/"+gettingmaps.getMapsnames().get(i)+".jpg");
    				fout.write(gettingmaps.getImages().get(i));
    				fout.close();
    				PrintWriter writer = new PrintWriter(home+"/Downloads/"+gettingmaps.getMapsnames().get(i)+"places.txt", "UTF-8");
    				while(j<gettingmaps.getTextfilestrings().size()) {
    					writer.println(gettingmaps.getTextfilestrings().get(j));
    					j++;
    				}
    				writer.close();
    				i++;
    			}  catch (FileNotFoundException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    		}
    		
    		Alert alert3 = new Alert(AlertType.INFORMATION);
    		alert3.setContentText("the selected city's maps were downloaded!");
    		alert3.setTitle("Downloaded!");
    		alert3.setHeaderText(null);
    		alert3.showAndWait();
    	}
    	else
    	{
    		Alert alert3 = new Alert(AlertType.INFORMATION);
    		alert3.setContentText("No city was selected!!");
    		alert3.setTitle("Warning");
    		alert3.setHeaderText(null);
    		alert3.showAndWait();
    	}
}

    }
    /**
     * this button works as a handler that closes the current page and returns the user to the home page according to the user's type
     * @param event
     */
    @FXML
    void HomeButton(ActionEvent event) {
    	
    	if(LoginController.type.equals("Employee"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
		else if(LoginController.type.equals("Customer"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
    }
    /**
     * this method is used as a handler for clicking the logout button, it logs out the client returning him to the login page
     * and removing him from the list of online users
     * @param event
     */
    @FXML
    void LogOutButton(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

    	try {
	    	
	    	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//build the gui
    	
    	
    }
    /**
     * this method is called when the fxml file is loaded, it initializes the variables and some Gui elements.
     */
    @FXML
    void initialize() {
        assert MyCitiesLBL != null : "fx:id=\"MyCitiesLBL\" was not injected: check your FXML file 'mycities.fxml'.";
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'mycities.fxml'.";
	 Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
        assert MyCitiesList != null : "fx:id=\"MyCitiesList\" was not injected: check your FXML file 'mycities.fxml'.";
        ArrayList<String> toServer= new ArrayList<String>();
        toServer.add("GetMyCities");
        toServer.add(LoginController.id);
        try {
          	Main.getClient().getClient().StringsToServer(toServer);
          } catch (IOException e1) {
          	// TODO Auto-generated catch block
          	e1.printStackTrace();
          }//incase the job is to get city names for combobox
     	  try {
       		Thread.currentThread().sleep(1000);
       	} catch (InterruptedException e) {
       		// TODO Auto-generated catch block
       		e.printStackTrace();
       	}
     	 ArrayList<String> myCities=new ArrayList<String>();
     	 ObservableList<String> list1;
     	  if(Main.getClient().getClient().getCityNames().size()==0)
     	  {
     		 myCities.add("No purchase has been made yet!");
     	     list1 = FXCollections.observableArrayList(myCities);
     	     MyCitiesList.setItems(list1);
     	     MyCitiesList.setDisable(true);
     		 
     	  }
     	  else
     	  {
     		  list1= FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
     		  MyCitiesList.setItems(list1);
     	  }
        
        assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'mycities.fxml'.";
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'mycities.fxml'.";
        assert DownloadBtn != null : "fx:id=\"DownloadBtn\" was not injected: check your FXML file 'MyCities.fxml'.";
        
        
        

    }
}
