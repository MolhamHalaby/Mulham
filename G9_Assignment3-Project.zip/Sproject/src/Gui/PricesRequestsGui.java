package Gui;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import entities.Message;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * this class handles the page in which the big boss can view price requests and decide to take action on them
 * deciding whether to confirm them or decline the requests influencing the DB accordingly
 * @author anan
 *
 */
public class PricesRequestsGui {
ArrayList<String> citypricesaver= new ArrayList<String>();
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button HomeBtn;

    @FXML
    private Button ConfirmBtn;

    @FXML
    private Button DeclineBtn;
    
    @FXML
    private ImageView GcmImage;

    @FXML
    private Button logoutBtn;
    @FXML
    private ListView<String> citypriceview;
/**
 * a method to handle the click on the confirm button after selecting a city with its price , it updates the confirmed price
 * in the database accordingly and removed the request from the requests list
 * @param event
 */
    @FXML
    void Confirm(ActionEvent event) {
    	if(citypriceview.getSelectionModel().getSelectedItem()!=null) {
    	Alert alert1 = new Alert(AlertType.CONFIRMATION);
		alert1.setContentText("Are you sure you want to approve the new price of this city?!");
		alert1.setTitle("Confirmation");
		alert1.setHeaderText(null);
		Optional<ButtonType> result = alert1.showAndWait();
		if (result.get() == ButtonType.OK)
		{
    	Alert alert = new Alert(AlertType.INFORMATION);
		alert.setContentText("You have approved this city's price request!");
		alert.setTitle("City Price Confirmed");
		alert.setHeaderText(null);
		alert.showAndWait(); 
        ArrayList<String> ReleaseNewPrice=new ArrayList<String>();
        ReleaseNewPrice.add("AcceptPrice");
        ReleaseNewPrice.add((String)citypriceview.getSelectionModel().getSelectedItem().replaceAll(".*,", ""));

    	try {
			Main.getClient().getClient().StringsToServer(ReleaseNewPrice);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		citypricesaver.remove(citypriceview.getSelectionModel().getSelectedIndex());
		citypriceview.setItems(null);
		 ObservableList<String> list;
	        list = FXCollections.observableArrayList(citypricesaver);
	        citypriceview.setItems(list);
		}
    }
    }
/**
 * a method to handle the big boss's decision to decline a price change request, it functions as following: removing the request 
 * from the requests list and alerts the content manager about his declined change request
 * @param event
 */
    @FXML
    void Decline(ActionEvent event) {
    	if(citypriceview.getSelectionModel().getSelectedItem()!=null) {
    	Alert alert1 = new Alert(AlertType.CONFIRMATION);
		alert1.setContentText("Are you sure you want to decline this new price request of this city?!");
		alert1.setTitle("Confirmation");
		alert1.setHeaderText(null);
		Optional<ButtonType> result = alert1.showAndWait();
		if (result.get() == ButtonType.OK)
		{
	    Alert alert = new Alert(AlertType.INFORMATION);
		alert.setContentText("You have declined this city's new price request! a message will be sent to alarm content manager!");
		alert.setTitle("Price Update Declined");
		alert.setHeaderText(null);
		alert.showAndWait();
		ArrayList<String> sendtocontentmanager=new ArrayList<String>();
		sendtocontentmanager.add("contentmanagermail");
		sendtocontentmanager.add((String)citypriceview.getSelectionModel().getSelectedItem().replaceAll(".*,", ""));
		try {
			Main.getClient().getClient().StringsToServer(sendtocontentmanager);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int i=0;
		ArrayList<String> contentmanager = new ArrayList<String>();
		contentmanager=Main.getClient().getClient().getContentEmails();
	    	 Message SendAlarm= new Message();
		    while(i<contentmanager.size()) {
		    SendAlarm.setRtnMessage("the new price request of City:" + citypriceview.getSelectionModel().getSelectedItem() + " was declined by the Big Boss!");
		    SendAlarm.setRtnSender("system");
		    SendAlarm.setRtnReceiver(contentmanager.get(i));
		    SendAlarm.setRtnTitle("Price Request Declined!");
		    SendAlarm.setRtnDate(LocalDate.now());
		    i++;
		    try {
				Main.getClient().getClient().AddingNewData(SendAlarm);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			citypricesaver.remove(citypriceview.getSelectionModel().getSelectedIndex());
			citypriceview.setItems(null);
			 ObservableList<String> list;
		        list = FXCollections.observableArrayList(citypricesaver);
		        citypriceview.setItems(list);
		    }
		
    }
    }
    /**
     * this button works as a handler that closes the current page and returns the user to the home page according to the user's type
     * @param event
     */
    @FXML
    void home(ActionEvent event) {
    	Pane root;
		try {
		root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
		Stage stage = new Stage();
		stage.setScene(scene);
		((Node) event.getSource()).getScene().getWindow().hide(); 
		stage.show();
    } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}//build the gu
    }
    /**
     * this method is used as a handler for clicking the logout button, it logs out the client returning him to the login page
     * and removing him from the list of online users
     * @param event
     */
    @FXML
    void logout(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	Pane root;
		try {
		root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
		Stage stage = new Stage();
		stage.setScene(scene);
		((Node) event.getSource()).getScene().getWindow().hide(); 
		stage.show();
    } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}//build the gu
    }
    /**
     * this method is called when the fxml file is loaded, it initializes the variables and some Gui elements.
     */
    @FXML
    void initialize() {
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'PricesRequests.fxml'.";
        assert ConfirmBtn != null : "fx:id=\"ConfirmBtn\" was not injected: check your FXML file 'PricesRequests.fxml'.";
        assert DeclineBtn != null : "fx:id=\"DeclineBtn\" was not injected: check your FXML file 'PricesRequests.fxml'.";
        assert logoutBtn != null : "fx:id=\"logoutBtn\" was not injected: check your FXML file 'PricesRequests.fxml'.";
        assert citypriceview != null : "fx:id=\"citypriceview\" was not injected: check your FXML file 'PricesRequests.fxml'.";
         
        
        ArrayList<String> getrequests=new ArrayList<String>();
        getrequests.add("getfromcityprice");
        try {
        	Main.getClient().getClient().StringsToServer(getrequests);
        } catch (IOException e1) {
        	// TODO Auto-generated catch block
        	e1.printStackTrace();
        }//incase the job is to get city names for combobox
         try {
        		Thread.currentThread().sleep(1000);
        	} catch (InterruptedException e) {
        		// TODO Auto-generated catch block
        		e.printStackTrace();
        	}
        ObservableList<String> list;
        list = FXCollections.observableArrayList(Main.getClient().getClient().getCityprice());
        
        citypricesaver=Main.getClient().getClient().getCityprice();
        
        citypriceview.setItems(list);
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'PricesRequests.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
        
    }
}
