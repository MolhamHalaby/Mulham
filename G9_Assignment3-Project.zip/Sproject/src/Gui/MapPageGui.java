package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import Controller.CityController;
import Controller.LoginController;
import Controller.MapController;
import application.Main;
import entities.MapPlace;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.input.SwipeEvent;
import javafx.scene.input.ZoomEvent;
import javafx.scene.layout.Pane;
import javafx.scene.transform.Scale;
import javafx.stage.Stage;
import javafx.util.Duration;
/**
 * This class is the GUI controller responsible for add,view and edit places to the selected map according to the logger's type
 * @author Molham
 * 
 */
public class MapPageGui {
	String PlaceName;
	ArrayList<MapPlace> mapPlaces; 
	MapPlace PlaceToUpdate;
	int temp=0;
	int flag;
	int index=0;
	Group zoomGroup;
	@FXML
	private ResourceBundle resources;


	@FXML
	private URL location;


	@FXML
	private Label zoomLBL;

	@FXML
	private ScrollPane ScrolPaneID;

	@FXML
	private Button ZoomOutBtn;

	@FXML
	private Pane paneId;

	@FXML
	private Slider ScrollZoom;

	@FXML
	private Button HomeId;

	@FXML
	private Button ProfileId;

	@FXML
	private Button LogOutID;

	@FXML
	private Button ZoomInBtn;

	@FXML
	private ImageView MapImage;

	@FXML
	private ListView<String> PlacesList;



	/**
	 * This method changing the location of the place on the map if its exist,
	 * if not, user can add a new location to the selected place.
	 * only employee can edit the map
	 * if the logger is customer he can only view the map.
	 * @param event
	 */
	@FXML
	void MapClick(MouseEvent event) {
		if(flag==1)
		{
			double x=0,y=0;
			if(LoginController.type!="Customer")
			{
				x=event.getX();
				y= event.getY();
				if(mapPlaces.get(index).getCorX()==0&&mapPlaces.get(index).getCorY()==0)
				{	
					ImageView s = new ImageView();
					s.setLayoutX(x);
					s.setLayoutY(y);
					s.setFitHeight(25.0);
					s.setFitWidth(25.0);
					s.setPickOnBounds(true);
					s.setPreserveRatio(true);
					s.setSmooth(true);
					Image image=new Image(getClass().getResourceAsStream("../Img/iconLoc.png"));
					s.setImage(image);
					paneId.getChildren().add(s);


					mapPlaces.get(index).setCorX(x);
					mapPlaces.get(index).setCorY(y);
					mapPlaces.get(index).setMapName(MapController.MapName);
					mapPlaces.get(index).setCityName(CityController.CityName);
					PlaceToUpdate=mapPlaces.get(index);
					PlaceToUpdate.setPlaceName(PlaceName);

					try { 
						Main.getClient().getClient().MapToUpdate(PlaceToUpdate);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					try {
						Thread.currentThread().sleep(1000);

					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


				}
				else
				{

					Alert alert = new Alert(AlertType.CONFIRMATION);
					alert.setTitle("Confirmation");
					alert.setHeaderText(null);
					alert.setContentText("Place is apear on the map,\nwould you want to change it's location?");

					Optional<ButtonType> result = alert.showAndWait();
					if (result.get() == ButtonType.OK)
					{
						ImageView s = new ImageView();
						s.setLayoutX(x);
						s.setLayoutY(y);
						s.setFitHeight(25.0);
						s.setFitWidth(25.0);

						s.setPickOnBounds(true);
						s.setPreserveRatio(true);
						s.setSmooth(true);

						Image image=new Image(getClass().getResourceAsStream("../Img/iconLoc.png"));
						s.setImage(image);
						paneId.getChildren().add(s);

						mapPlaces.get(index).setCorX(x);
						mapPlaces.get(index).setCorY(y);
						mapPlaces.get(index).setMapName(MapController.MapName);
						PlaceToUpdate=mapPlaces.get(index);
						PlaceToUpdate.setPlaceName(PlaceName);

						try { 
							Main.getClient().getClient().MapToUpdate(PlaceToUpdate);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						try {
							Thread.currentThread().sleep(1000);

						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} 

				}

			}
		}
	}

	/**
	 * This method shows the location of the place on the map if its exist, by clicking on the places list,
	 * employee will see all the places in the city 
	 * customer will see only places that related to the selected map
	 * @param event
	 */


	@FXML
	void PlaceClick(MouseEvent event) {
		if(!(PlacesList.getSelectionModel().isEmpty()))
		{
			flag=1;
			PlaceName= PlacesList.getSelectionModel().getSelectedItem();
			for(int i=0;i<mapPlaces.size();i++)
			{
				if(mapPlaces.get(i).getPlaceName().equals(PlaceName))
				{
					index=i;
					if(mapPlaces.get(i).getCorX()==0&&mapPlaces.get(i).getCorY()==0)
					{
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setContentText("Place Pin does not appear on the map!\n please choose location on the map.");
						alert.setTitle("Note");
						alert.setHeaderText(null);
						alert.showAndWait();

					}
					else
					{
						ImageView s = new ImageView();
						s.setLayoutX(mapPlaces.get(i).getCorX());
						s.setLayoutY(mapPlaces.get(i).getCorY());
						s.setFitHeight(25.0);
						s.setFitWidth(25.0);
						s.setPickOnBounds(true);
						s.setPreserveRatio(true);
						s.setSmooth(true);

						Image image=new Image(getClass().getResourceAsStream("../Img/iconLoc.png"));
						s.setImage(image);
						paneId.getChildren().add(s);

						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setContentText("PlaceName="+PlaceName+"\nCordinate X= "+ s.getLayoutX()+"\nCordinate Y= "+s.getLayoutY());
						alert.setTitle("Information");
						alert.getDialogPane().setPrefSize(300, 150);
						alert.setHeaderText(null);
						alert.setX(620);
						alert.setY(120);
						alert.showAndWait();


					}

				}
			}
		}

	}

	/**
	 * This method handles the zooming function
	 */

	@FXML
	void ZoomInButton(ActionEvent event) {
		double sliderValue= ScrollZoom.getValue();
		ScrollZoom.setValue(sliderValue+=0.1);
	}
	/**
	 * This method handles the zooming function
	 */
	@FXML
	void ZoomOutButton(ActionEvent event) {

		double sliderValue= ScrollZoom.getValue();
		ScrollZoom.setValue(sliderValue-=0.1);
	}
	/**
	 * * This method closes the current window and goes back to the "Home" window, according to the logger's type.
	 * @param event
	 */
	@FXML
	void HomeFunc(ActionEvent event) {

		if(LoginController.type.equals("Employee"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
		else if(LoginController.type.equals("Customer"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstCustomer.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}


	}
	/**
	 *  This method handles the event where the user click on "LogOut" button to log out from the system
	 *  and remove the user id from the logged in table in DB
	 * @param event
	 */
	@FXML
	void LogOutFunc(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui

	}
	/**
	 *  This method closes the current window and goes back to the profile window.
	 * @param event
	 */

	@FXML
	void toProfile(ActionEvent event) {
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/UserProfile.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
	}

	ZoomingPane zoomingPane;
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	@FXML
	void initialize() {
		assert zoomLBL != null : "fx:id=\"zoomLBL\" was not injected: check your FXML file 'map1.fxml'.";
		assert ZoomOutBtn != null : "fx:id=\"ZoomOutBtn\" was not injected: check your FXML file 'map1.fxml'.";
		assert ScrollZoom != null : "fx:id=\"ScrollZoom\" was not injected: check your FXML file 'map1.fxml'.";
		ScrollZoom.setMin(0.5);
		ScrollZoom.setMax(1.5);
		ScrollZoom.setValue(1.0);



		assert ZoomInBtn != null : "fx:id=\"ZoomInBtn\" was not injected: check your FXML file 'map1.fxml'.";
		assert HomeId != null : "fx:id=\"HomeId\" was not injected: check your FXML file 'Map.fxml'.";
		assert ProfileId != null : "fx:id=\"ProfileId\" was not injected: check your FXML file 'Map.fxml'.";
		assert LogOutID != null : "fx:id=\"LogOutID\" was not injected: check your FXML file 'Map.fxml'.";
		assert PlacesList != null : "fx:id=\"PlacesList\" was not injected: check your FXML file 'map1.fxml'.";
		PlaceName= new String();
		mapPlaces= new ArrayList<MapPlace>();
		ArrayList<String> placesNames= new ArrayList<String>();
		ObservableList<String> list1;
		
		if(LoginController.type=="Customer")
		{
			ArrayList<String> MaptoServer= new ArrayList<String>();
			MaptoServer.add("GetplacesWithCordinatesForList");
			MaptoServer.add(MapController.MapName);
			try {
				Main.getClient().getClient().StringsToServer(MaptoServer);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}//incase the job is to get city names for combobox
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mapPlaces= Main.getClient().getClient().getMapPlaces();



			for(int i=0;i<mapPlaces.size();i++)
			{
				if(Main.getClient().getClient().getMapPlaces().get(i).getCorX()!=0&&Main.getClient().getClient().getMapPlaces().get(i).getCorY()!=0)
					placesNames.add(Main.getClient().getClient().getMapPlaces().get(i).getPlaceName());
			}

		}
		else
		{
			ArrayList<String> MaptoServer= new ArrayList<String>();
			MaptoServer.add("GetplacesWithCordinatesForList");
			MaptoServer.add(MapController.MapName);
			MaptoServer.add(CityController.CityName);
			try {
				Main.getClient().getClient().StringsToServer(MaptoServer);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}//incase the job is to get city names for combobox
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mapPlaces= Main.getClient().getClient().getMapPlaces();


			for(int i=0;i<mapPlaces.size();i++)
			{
				placesNames.add(Main.getClient().getClient().getMapPlaces().get(i).getPlaceName());

			}
		}
	
		list1 = FXCollections.observableArrayList(placesNames);
		PlacesList.setItems(list1);
		assert ScrolPaneID != null : "fx:id=\"ScrolPaneID\" was not injected: check your FXML file 'Map.fxml'.";
		assert paneId != null : "fx:id=\"paneId\" was not injected: check your FXML file 'Map.fxml'.";
		zoomingPane = new ZoomingPane(paneId);
		zoomingPane.zoomFactorProperty().bind(ScrollZoom.valueProperty());

		assert MapImage != null : "fx:id=\"MapImageView\" was not injected: check your FXML file 'Map.fxml'.";

		ArrayList<String> MapImageToServer= new ArrayList<String>();
		MapImageToServer.add("GetImageForMap");
		MapImageToServer.add(MapController.MapName);
		MapImageToServer.add(LoginController.type);
		try {
			Main.getClient().getClient().StringsToServer(MapImageToServer);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//incase the job is to get city names for combobox
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MapImage.setImage(Main.getClient().getClient().getImage());
		flag=0;






	}   
}


