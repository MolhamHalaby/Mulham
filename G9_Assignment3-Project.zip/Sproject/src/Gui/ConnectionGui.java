package Gui;
import java.net.URL;
import java.util.ResourceBundle;

import application.ClientConsole;
import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 *  This class is the GUI controller responsible for receiving the IP of the server in order to connect 
 * @author Molham 
 */
public class ConnectionGui {
ClientConsole clt;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView GcmImage;

    @FXML
    private Label ConLbl;

    @FXML
    private Label EnterIPLbl;

    @FXML
    private TextField IPTXT;

    @FXML
    private Button ConnectBtn;
    
    /**
   	 * This method handles the event where the user enter the IP of the server to for connecting.
   	 * @param event 
   	 */
    @FXML
    void ConnectButton(ActionEvent event) {

    	clt=new ClientConsole(IPTXT.getText(), 5555);
    	Main.setClient(clt);
    	try {
			( (Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Catalog.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	
    }
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
    @FXML
    void initialize() {
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'conn.fxml'.";
        Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
        assert ConLbl != null : "fx:id=\"ConLbl\" was not injected: check your FXML file 'conn.fxml'.";
        assert EnterIPLbl != null : "fx:id=\"EnterIPLbl\" was not injected: check your FXML file 'conn.fxml'.";
        assert IPTXT != null : "fx:id=\"IPTXT\" was not injected: check your FXML file 'conn.fxml'.";
        assert ConnectBtn != null : "fx:id=\"ConnectBtn\" was not injected: check your FXML file 'conn.fxml'.";

    }
}
