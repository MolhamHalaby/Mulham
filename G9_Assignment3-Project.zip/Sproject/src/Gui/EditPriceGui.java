package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * this class is responsible for handling the edit price action , displaying the price requests and functionizing the 
 * confirm and decline buttons.
 * @author anan
 *
 */
public class EditPriceGui {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button LogoutBtn;

    @FXML
    private Button RequestBtn;

    @FXML
    private Button HomeBtn;



    @FXML
    private TextField currentpriceTxt;
    @FXML
    private ListView<String> CityList;
    @FXML
    private TextField changetoTxt;

    /**
     * this button works as a handler that closes the current page and returns the user to the home page according to the user's type
     * @param event
     */

    @FXML
    void Home(ActionEvent event) {

		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    /**
     * this method is used as a handler for clicking the logout button, it logs out the client returning him to the login page
     * and removing him from the list of online users
     * @param event
     */
    @FXML
    void Logout(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    /**
     * this method is used as a handler for the send change request button , it forwards the price change request to the big boss
     * @param event
     */
    @FXML
    void SendChangeRequest(ActionEvent event) {
     String WantedPrice=changetoTxt.getText();
     ArrayList<String> wantedlist=new ArrayList<String>();
      wantedlist.add("addtocityprice");
      wantedlist.add((String)CityList.getSelectionModel().getSelectedItem());
      wantedlist.add(WantedPrice);
      try {
		Main.getClient().getClient().StringsToServer(wantedlist);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
      Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText("Price Request Sent");
		alert.setTitle("Success");
		alert.setHeaderText(null);
		alert.showAndWait();
      
    }
    /**
     * this method functions as follows: grabs the selected city name and gets it's price from the DB
     * @param event
     */
    @FXML
    void CityListPriceGet(MouseEvent event) {
    	currentpriceTxt.setEditable(false);
       ArrayList<String> getcityprice = new ArrayList<String>();
       getcityprice.add("getpureprice");
       getcityprice.add((String)CityList.getSelectionModel().getSelectedItem());
       try {
		Main.getClient().getClient().StringsToServer(getcityprice);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       try {
		Thread.currentThread().sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       currentpriceTxt.setText(Integer.toString(Main.getClient().getClient().getPureprice()));
       
    }
	/**
     * this method is called when the fxml file is loaded, it initializes the variables and some Gui elements.
     */
    @FXML
    void initialize() {
        assert LogoutBtn != null : "fx:id=\"LogoutBtn\" was not injected: check your FXML file 'EditPrice.fxml'.";
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'EditPrice.fxml'.";
        assert currentpriceTxt != null : "fx:id=\"currentpriceTxt\" was not injected: check your FXML file 'EditPrice.fxml'.";
        assert changetoTxt != null : "fx:id=\"changetoTxt\" was not injected: check your FXML file 'EditPrice.fxml'.";
        assert RequestBtn != null : "fx:id=\"RequestBtn\" was not injected: check your FXML file 'EditPrice.fxml'.";

        try {
        	Main.getClient().sendToMyCLient("GetCitiesForComboBox");
        } catch (IOException e1) {
        	// TODO Auto-generated catch block
        	e1.printStackTrace();
        }//incase the job is to get city names for combobox
         try {
        		Thread.currentThread().sleep(1000);
        	} catch (InterruptedException e) {
        		// TODO Auto-generated catch block
        		e.printStackTrace();
        	}
        ObservableList<String> list;
      
        list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
        CityList.setItems(list);
        try {
    		Thread.currentThread().sleep(1000);
    	} catch (InterruptedException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
        
    }
}
