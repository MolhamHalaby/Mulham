package Gui;

import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import Controller.LoginController;
import Controller.ReportController;
import application.Main;
import entities.timedCityReport;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * This class for displaying a city report for a limited period. 
 * @author Eyal + Anan
 *
 */
public class ReportGui {

	ReportController reportController;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    private ComboBox<String> Citycmb;

    @FXML
    private Button ShowReportBtn;

    @FXML
    private Button ExitBtn;

    @FXML
    private TextField NumOfMaps;

    @FXML
    private TextField NumOfPurchases;

    @FXML
    private TextField NumOfSubscriptions;

    @FXML
    private TextField NumOfViews;
    @FXML
    private DatePicker frompicker;

    @FXML
    private DatePicker untillpicker;
    
    @FXML
    private ImageView GcmImage;

    @FXML
    private Button LogOutBtn;

    @FXML
    private Button HomeBtn;

    @FXML
    private Button BackBtn;

    @FXML
    private Label CityReportLbl;

    @FXML
    private TextField NumOfRenewals;

    @FXML
    private TextField NumOfDownloads;
    /**
     * this method handles the back button, that gets the user to previous page. 
     * @param event
     */

    @FXML
    void BackButton(ActionEvent event) throws IOException {
    	((Node) event.getSource()).getScene().getWindow().hide(); 
		Pane root = FXMLLoader.load(getClass().getResource("/Fxml/ChooseReportGui.fxml"));//build the gui
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
		Stage stage = new Stage();
		stage.setScene(scene);
		stage.show();
    }
    /**
     * this method handles the Exit button, that gets the user to previous page. 
     * @param event
     */

    @FXML
    void Exit(ActionEvent event) throws IOException {
    	((Node) event.getSource()).getScene().getWindow().hide(); 
		Pane root = FXMLLoader.load(getClass().getResource("/Fxml/ChooseReportGui.fxml"));//build the gui
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
		Stage stage = new Stage();
		stage.setScene(scene);
		stage.show();
    }
    
    /**
     * this method handles the home button that takes back to the home page according to the logger's type
     * @param event
     */
    @FXML
    void HomeButton(ActionEvent event) {

		if (LoginController.type.equals("Manager")) {
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else  if (LoginController.type.equals("Big Boss"))
		{
			try {
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
    	
    }
    /**
     * this method handles the logout button that makes the user logs out from the app
     * @param event
     */
    @FXML
    void LogOutButton(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
/**
 * this method handles the shoe report button, when the user clicks on this button, he 
 * will get a report that he asked for
 * @param event
 * @throws ParseException
 */
    @FXML
    void ShowReport(ActionEvent event) throws ParseException {
    	 if((String)this.Citycmb.getSelectionModel().getSelectedItem()!=null) // eyal 266
     	{
        LocalDate from=frompicker.getValue();
        LocalDate untill=untillpicker.getValue();
        ArrayList<String> GetTimedReport= new ArrayList<String>();
        GetTimedReport.add("GetCityReport");
        GetTimedReport.add((String)this.Citycmb.getSelectionModel().getSelectedItem());
	    String formattedStartDate = from.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
	    String formattedEndDate = untill.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
	    GetTimedReport.add(formattedStartDate);
	    GetTimedReport.add(formattedEndDate);
	    try {
    		Main.getClient().getClient().StringsToServer(GetTimedReport);
    	} catch (IOException e1) {
    		// TODO Auto-generated catch block
    		e1.printStackTrace();
    	}
    	try {
    		Thread.currentThread().sleep(1000);
    	} catch (InterruptedException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
	    ArrayList<String> CityReport=new ArrayList<String>();
	    timedCityReport timedcityreport=new timedCityReport();
	    timedcityreport=Main.getClient().getClient().getTimedreport();
	    ArrayList<String> cityname,Datestr;
		int totalNumOfMaps=0, totalNumOfPurchases=0, totalNumOfSubscriptions=0, totalNumOfRenewals=0, totalNumOfViews=0, totalNumOfDownloads=0;
		cityname=new ArrayList<String>();
		Datestr=new ArrayList<String>();	
	    int i=0;
		int j=0;
		DateFormat formatter = DateFormat.getDateInstance(DateFormat.SHORT,Locale.getDefault());
		Date startingdate = formatter.parse(formattedStartDate);
		Date endingdate = formatter.parse(formattedEndDate);
        Date firstdate=formatter.parse(((timedcityreport.Datestr).get(i)));
        
	    while(i < timedcityreport.cityname.size())
		{
			if( (firstdate.compareTo(startingdate) >= 0) && (firstdate.compareTo(endingdate) <= 0))
			{
                totalNumOfMaps=totalNumOfMaps+timedcityreport.NumOfMaps.get(i);
                totalNumOfPurchases+=timedcityreport.NumOfPurchases.get(i);
                totalNumOfSubscriptions+=timedcityreport.NumOfSubscriptions.get(i);
                totalNumOfRenewals+=timedcityreport.NumOfRenewals.get(i);
                totalNumOfViews+=timedcityreport.NumOfViews.get(i);
                totalNumOfDownloads+=timedcityreport.NumOfDownloads.get(i);
			}
			else {				
			}
			i++;
			if(i<timedcityreport.cityname.size())
			firstdate=formatter.parse(((timedcityreport.Datestr).get(i)));
		}
	        NumOfMaps.setText(Integer.toString(totalNumOfMaps));
    		NumOfPurchases.setText(Integer.toString(totalNumOfPurchases));
    		NumOfSubscriptions.setText(Integer.toString(totalNumOfSubscriptions));
    		NumOfRenewals.setText(Integer.toString(totalNumOfRenewals));
    		NumOfViews.setText(Integer.toString(totalNumOfViews));
    		NumOfDownloads.setText(Integer.toString(totalNumOfDownloads));
    	}
         else   
     	{
 			Alert alert = new Alert(AlertType.ERROR);
 			alert.setContentText("No city was selected! ");
 			alert.setTitle("Error");
 			alert.setHeaderText(null);
 			alert.showAndWait();
     	}
    	}
    
    @FXML
    void citycmb(ActionEvent event) {

    }
    
    /**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
    @FXML
    void initialize() {
    	 assert Citycmb != null : "fx:id=\"Citycmb\" was not injected: check your FXML file 'ReportGui.fxml'.";
    	 reportController=new ReportController();
    	 reportController.GetCityComboBox();
         ObservableList<String> list;
         list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
 		Citycmb.setItems(list);//update the ComboxBox with the list of cities 
        assert ShowReportBtn != null : "fx:id=\"ShowReportBtn\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert ExitBtn != null : "fx:id=\"ExitBtn\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert NumOfMaps != null : "fx:id=\"NumOfMaps\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert NumOfPurchases != null : "fx:id=\"NumOfPurchases\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert NumOfSubscriptions != null : "fx:id=\"NumOfSubscriptions\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert NumOfViews != null : "fx:id=\"NumOfViews\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert NumOfRenewals != null : "fx:id=\"NumOfRenewals\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert NumOfDownloads != null : "fx:id=\"NumOfDownloads\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert frompicker != null : "fx:id=\"frompicker\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert untillpicker != null : "fx:id=\"untillpicker\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'ReportGui.fxml'.";
        Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
        GcmImage.setImage(logo);
        assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert BackBtn != null : "fx:id=\"BackBtn\" was not injected: check your FXML file 'ReportGui.fxml'.";
        assert CityReportLbl != null : "fx:id=\"CityReportLbl\" was not injected: check your FXML file 'ReportGui.fxml'.";
      
    }
}
