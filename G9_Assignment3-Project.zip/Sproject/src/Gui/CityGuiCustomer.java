package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.CityController;
import Controller.LoginController;
import Controller.MapController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 *  This class is the GUI controller responsible for showing maps that related to the selected city from the previews page
 *   user can view maps and their places, descriptions and tours.
 * @author Molham & Anan
 */
public class CityGuiCustomer {
MapController selectedMap;
ArrayList<String> mapNames;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label MapsLbl;

    @FXML
    private ImageView GcmImage;

    @FXML
    private Label CityNameLbl;

    @FXML
    private Label MapDescriptionLbl;

    @FXML
    private Button LogOutBtn;

    @FXML
    private Button HomeBtn;

    @FXML
    private TextField CityNameTxt;

    @FXML
    private TextArea MapDescriptionTxt;

    @FXML
    private ListView<String> MapsList;

    @FXML
    private Button ShowMapBtn;

    @FXML
    private Button ViewToursBtn;

    @FXML
    private Button BuyCityBtn;

    @FXML
    private Label TitleId;

    /**
	 * This method handles the event where the user click on "buy" button 
	 * the current window will be close and goes to the "buy" page.
	 * @param event 
	 */
    @FXML
    void BuyCityButton(ActionEvent event) {
    	try {
        	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Purchase.fxml"));
    		Scene scene = new Scene(root);
    		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
    		Stage stage = new Stage();
    		stage.setScene(scene);
    		((Node) event.getSource()).getScene().getWindow().hide(); 
    		stage.show();
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}//build the gui
    		
    }

    /**
     * * This method closes the current window and goes back to the "Home" page, according to the logger's type.
     * @param event
     */
    @FXML
    void HomeButton(ActionEvent event) {
    	try {
        	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageCustomer.fxml"));
    		Scene scene = new Scene(root);
    		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
    		Stage stage = new Stage();
    		stage.setScene(scene);
    		((Node) event.getSource()).getScene().getWindow().hide(); 
    		stage.show();
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}//build the gui
    }
    /**
  	 * This method handles the event where the user click on "LogOut" button to log out from the system
  	 * @param event
  	 */
    @FXML
    void LogOutButton(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	try {
    	
    	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
		Stage stage = new Stage();
		stage.setScene(scene);
		((Node) event.getSource()).getScene().getWindow().hide(); 
		stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
    }
    /**
   	 * This method handles the event where the user click on one of the maps in the list, user can view the description
   	 * and places of the selected map
   	 * @param event 
   	 */
    @FXML
    void MapsListOnClick(MouseEvent event) {
    	if(MapsList.getSelectionModel().getSelectedItem()!=null)
    	{
        selectedMap.setMapName(MapsList.getSelectionModel().getSelectedItem());
        ArrayList<String> toServer= new ArrayList<String>();
    	toServer.add("GetDescription");
    	toServer.add(MapsList.getSelectionModel().getSelectedItem());
    	toServer.add(LoginController.type);                              ////256
    	try {
         	Main.getClient().getClient().StringsToServer(toServer);
         } catch (IOException e1) {
         	// TODO Auto-generated catch block
         	e1.printStackTrace();
         }//incase the job is to get city names for combobox
          try {
         		Thread.currentThread().sleep(1000);
         	} catch (InterruptedException e) {
         		// TODO Auto-generated catch block
         		e.printStackTrace();
         	}
          MapDescriptionTxt.setText(Main.getClient().getClient().getS());
          MapDescriptionTxt.setEditable(false);
    	}
    }
    
    /**
   	 * This method handles the event where the user click on "ShowMap" button 
   	 * user can view the map and it's places.
   	 * @param event 
   	 */
    @FXML
    void ShowMapButton(ActionEvent event) {

    	if(MapsList.getSelectionModel().isEmpty())
    	{
    		Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Please select map from the list!");
			alert.setTitle("Information");
			alert.getDialogPane().setPrefSize(300, 150);
			alert.setHeaderText(null);
			alert.showAndWait();
    	}
    	else
    	{
    		try {
    			  ArrayList<String> toServer= new ArrayList<String>();
    		        toServer.add("GetMyCities");
    		        toServer.add(LoginController.id);
    		        try {
    		          	Main.getClient().getClient().StringsToServer(toServer);
    		          } catch (IOException e1) {
    		          	// TODO Auto-generated catch block
    		          	e1.printStackTrace();
    		          }//incase the job is to get city names for combobox
    		     	  try {
    		       		Thread.currentThread().sleep(1000);
    		       	} catch (InterruptedException e) {
    		       		// TODO Auto-generated catch block
    		       		e.printStackTrace();
    		       	}
    		     	 ArrayList<String> myCities=new ArrayList<String>();
    		     	myCities=Main.getClient().getClient().getCityNames(); 
    		     	if(myCities.contains(CityController.CityName))
    		     	{ 		
    			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Map.fxml"));//build the gui
    			Scene scene = new Scene(root);
    			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
    			Stage stage = new Stage();
    			stage.setScene(scene);
    			((Node) event.getSource()).getScene().getWindow().hide(); 
    			stage.show();
    		     	
    		}
    		     	else {
    		     		Alert alert = new Alert(AlertType.ERROR);
    					alert.setContentText("You must buy a subscription of this city in order to view its map!");
    					alert.setTitle("Failed");
    					alert.setHeaderText(null);
    					alert.showAndWait();
    		     	}
    }
    		catch(Exception e)
    		{
    			e.printStackTrace();
    		}
    		
    	}
    	
    	
    }
    /**
   	 * This method handles the event where the user click on "ShowTours" button 
   	 * customer can view the tours of the city and it's places.
   	 * @param event 
   	 */
    @FXML
    void ViewToursButton(ActionEvent event) {

     	try {
        	
        	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/ToursPageCustomer.fxml"));
    		Scene scene = new Scene(root);
    		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
    		Stage stage = new Stage();
    		stage.setScene(scene);
    		((Node) event.getSource()).getScene().getWindow().hide(); 
    		stage.show();
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}//build the gui
    	
    	
    }
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
    @FXML
    void initialize() {
        assert MapsLbl != null : "fx:id=\"MapsLbl\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
     	 Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
   			GcmImage.setImage(logo);
        assert CityNameLbl != null : "fx:id=\"CityNameLbl\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert MapDescriptionLbl != null : "fx:id=\"MapDescriptionLbl\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert CityNameTxt != null : "fx:id=\"CityNameTxt\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        CityNameTxt.setText(CityController.getCityName());
        CityNameTxt.setEditable(false);
        assert MapDescriptionTxt != null : "fx:id=\"MapDescriptionTxt\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert MapsList != null : "fx:id=\"MapsList\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        mapNames =new ArrayList<String>();
        ArrayList<String> toServer= new ArrayList<String>();
    	toServer.add("GetMapsForList");
    	toServer.add(CityController.getCityName());
    	toServer.add(LoginController.type);                        ///256
    	try {
         	Main.getClient().getClient().StringsToServer(toServer);
         } catch (IOException e1) {
         	// TODO Auto-generated catch block
         	e1.printStackTrace();
         }//incase the job is to get city names for combobox
          try {
         		Thread.currentThread().sleep(1000);
         	} catch (InterruptedException e) {
         		// TODO Auto-generated catch block
         		e.printStackTrace();
         	}
         ObservableList<String> list;
         list = FXCollections.observableArrayList(Main.getClient().getClient().getMapsNames());
         MapsList.setItems(list);	
        assert ShowMapBtn != null : "fx:id=\"ShowMapBtn\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert ViewToursBtn != null : "fx:id=\"ViewToursBtn\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert BuyCityBtn != null : "fx:id=\"BuyCityBtn\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        assert TitleId != null : "fx:id=\"TitleId\" was not injected: check your FXML file 'CityGuiCustomer.fxml'.";
        selectedMap= new MapController();
        
        ArrayList<String> toServer1= new ArrayList<String>();
     	toServer1.add("AddViewers");
     	toServer1.add(CityController.getCityName());
     	try {
          	Main.getClient().getClient().StringsToServer(toServer1);
          } catch (IOException e1) {
          	e1.printStackTrace();
          }
           try {
          		Thread.currentThread().sleep(1000);
          	} catch (InterruptedException e) {
          		// TODO Auto-generated catch block
          		e.printStackTrace();
          	}	

    }
}
