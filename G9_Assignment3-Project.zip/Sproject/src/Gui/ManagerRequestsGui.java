package Gui;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import entities.Message;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
/**
 * this class is resposible for showing the new version requests to the manager and handling his actions accordingly
 * @author molham & sahar
 *
 */
public class ManagerRequestsGui {
 ArrayList<String> requestsaver=new ArrayList<String>();
	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private ListView<String> RequestsView;

	@FXML
	private Button ConfirmBtn;

	@FXML
	private Button DeclineBtn;
	
    @FXML
    private ImageView GcmImage;

    @FXML
    private Button LogOutBtn;

    @FXML
    private Button HomeBtn;
/**
 * this method handles the acceptance of the new version release , it forwards the choice to the DB in order to act accordingly
 * @param event
 */
	@FXML
	void Confirm(ActionEvent event) {
		if (RequestsView.getSelectionModel().getSelectedItem()!=null) // eyal 266
		{
			Alert alert1 = new Alert(AlertType.CONFIRMATION);
			alert1.setContentText("Are you sure you want to release a new version of this city?!");
			alert1.setTitle("Confirmation");
			alert1.setHeaderText(null);
			Optional<ButtonType> result = alert1.showAndWait();
			if (result.get() == ButtonType.OK)
			{
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("You have released this city's version! a message will be sent to alarm all Customers!");
				alert.setTitle("City Updates Confirmed");
				alert.setHeaderText(null);
				alert.showAndWait(); 
				ArrayList<String> ReleaseNewVersion=new ArrayList<String>();
				ReleaseNewVersion.add("ReleaseVersion");
				ReleaseNewVersion.add((String)RequestsView.getSelectionModel().getSelectedItem().replaceAll(",*,", ""));    
				try {
					Main.getClient().getClient().StringsToServer(ReleaseNewVersion);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ArrayList<String> sendtoecustomers=new ArrayList<String>();
				sendtoecustomers.add("customersemails");
				sendtoecustomers.add((String)RequestsView.getSelectionModel().getSelectedItem());
				try {
					Main.getClient().getClient().StringsToServer(sendtoecustomers);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					Thread.currentThread().sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				int i=0;
				ArrayList<String> CustomersToAlarm = new ArrayList<String>();
				CustomersToAlarm=Main.getClient().getClient().getCustomersEmails();
				Message SendAlarm= new Message();
				while(i<CustomersToAlarm.size()) {
					SendAlarm.setRtnMessage("A new version of City : " + RequestsView.getSelectionModel().getSelectedItem() + "  was released! go redownload!");
					SendAlarm.setRtnSender("system");
					SendAlarm.setRtnReceiver(CustomersToAlarm.get(i));
					SendAlarm.setRtnTitle("A new version of was released!");
					SendAlarm.setRtnDate(LocalDate.now());
					i++;
					try {
						Main.getClient().getClient().AddingNewData(SendAlarm);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				requestsaver.remove(RequestsView.getSelectionModel().getSelectedIndex());
				RequestsView.setItems(null);
				 ObservableList<String> list;
			        list = FXCollections.observableArrayList(requestsaver);
			        RequestsView.setItems(list);
			}
			
		}

		else  // eyal 266
		{
			Alert alert1 = new Alert(AlertType.ERROR);
			alert1.setContentText("No city was selected! ");
			alert1.setTitle("Error");
			alert1.setHeaderText(null);
			alert1.showAndWait();
		}
	}
/**
 * this method handles the decline action took by the manager, forwarding the option to the DB to remove the request and alert the employees
 * @param event
 */
	@FXML
	void Decline(ActionEvent event) {
		if (RequestsView.getSelectionModel().getSelectedItem()!=null) // eyal 266
		{
			Alert alert1 = new Alert(AlertType.CONFIRMATION);
			alert1.setContentText("Are you sure you want to decline this new version of this city?!");
			alert1.setTitle("Confirmation");
			alert1.setHeaderText(null);
			Optional<ButtonType> result = alert1.showAndWait();
			if (result.get() == ButtonType.OK)
			{
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("You have declined this city's version! a message will be sent to alarm all Employees!");
				alert.setTitle("City Updates Declined");
				alert.setHeaderText(null);
				alert.showAndWait();
				ArrayList<String> sendtoemployees=new ArrayList<String>();
				sendtoemployees.add("employeesmails");
				sendtoemployees.add((String)RequestsView.getSelectionModel().getSelectedItem());
				try {
					Main.getClient().getClient().StringsToServer(sendtoemployees);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					Thread.currentThread().sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				int i=0;
				ArrayList<String> EmployeesToAlarm = new ArrayList<String>();
				EmployeesToAlarm=Main.getClient().getClient().getEmployeesEmails();
				Message SendAlarm= new Message();
				while(i<EmployeesToAlarm.size()) {
					SendAlarm.setRtnMessage("the new version request of City:" + RequestsView.getSelectionModel().getSelectedItem() + "was declined by the manager!");
					SendAlarm.setRtnSender("system");
					SendAlarm.setRtnReceiver(EmployeesToAlarm.get(i));
					SendAlarm.setRtnTitle("Version Release Request Declined!");
					SendAlarm.setRtnDate(LocalDate.now());
					i++;
					try {
						Main.getClient().getClient().AddingNewData(SendAlarm);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				requestsaver.remove(RequestsView.getSelectionModel().getSelectedIndex());
				RequestsView.setItems(null);
				 ObservableList<String> list;
			        list = FXCollections.observableArrayList(requestsaver);
			        RequestsView.setItems(list);

			}
		}
		else  // eyal 266
		{
			Alert alert1 = new Alert(AlertType.ERROR);
			alert1.setContentText("No city was selected! ");
			alert1.setTitle("Error");
			alert1.setHeaderText(null);
			alert1.showAndWait();
		}
	}
	
	 /**
     * this button works as a handler that closes the current page and returns the user to the home page according to the user's type
     * @param event
     */
    @FXML
    void HomeButton(ActionEvent event) {
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    /**
     * this method is used as a handler for clicking the logout button, it logs out the client returning him to the login page
     * and removing him from the list of online users
     * @param event
     */
    @FXML
    void LogOutButton(ActionEvent event) {
    	
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    /**
     * this method is called when the fxml file is loaded, it initializes the variables and some Gui elements.
     */
	@FXML
	void initialize() {
		assert RequestsView != null : "fx:id=\"RequestsView\" was not injected: check your FXML file 'ManagerRequests.fxml'.";
		assert ConfirmBtn != null : "fx:id=\"ConfirmBtn\" was not injected: check your FXML file 'ManagerRequests.fxml'.";
		assert DeclineBtn != null : "fx:id=\"DeclineBtn\" was not injected: check your FXML file 'ManagerRequests.fxml'.";

		ArrayList<String> getrequests=new ArrayList<String>();
		getrequests.add("GetRequestsForList");
		try {
			Main.getClient().getClient().StringsToServer(getrequests);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//incase the job is to get city names for combobox
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list;
		list = FXCollections.observableArrayList(Main.getClient().getClient().getRequestsNames());
		RequestsView.setItems(list);
		requestsaver=Main.getClient().getClient().getRequestsNames();
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'ManagerRequests.fxml'.";
        assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'ManagerRequests.fxml'.";
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'ManagerRequests.fxml'.";
        Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
	}
}
