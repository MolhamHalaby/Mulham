package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.CityController;
import Controller.LoginController;
import Controller.MapController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * this class is responsible for representing and handling all the actions in the first content manager page 
 * @author anan & eyal
 *
 */
public class FirstPageContentManagerGui {

	ArrayList<String> cities;
	ArrayList<String> mapsNotRelated;
	CityController toAdd;

	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView GcmImage;

    @FXML
    private TextField SearchTxt;
    @FXML
    private Button EditPrice;

    @FXML
    private Label WelcomeLBL;

    @FXML
    private Button SearchBtn;

    @FXML
    private ListView<String> CityList;

    @FXML
    private ListView<String> MapsNotRelatedList;

    @FXML
    private Label CityLbl;

    @FXML
    private Button LogOut;

    @FXML
    private Button Profile;

    @FXML
    private Button Home;

    @FXML
    private Button viewmessageBtn;

    @FXML
    private Button VersionRequestsBtn;

    @FXML
    private Button ViewReports;
    /**
     * this button works as a handler for the edit price button forwading the content manager to a page where he can 
     * select which city's price to edit and then send the request for the new price release
     * @param event
     */
    @FXML
    void EditPage(ActionEvent event) {
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/EditPrice.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
    }
    /**
     * forwards him to a page where he can choose which report he wishes to see.
     * @param event
     */
    @FXML
    void ViewReports(ActionEvent event) {
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/ChooseReportGui.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
    }
    /**
     * this method works as a handler for a click on the new versions requests page forwarding him to the page
     * @param event
     */
    @FXML
    void ViewRequests(ActionEvent event) {
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/ManagerRequests.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
    }

    /**
     * this handles the action of select a city from the city listview , forwarding the user (employee in this case) to the city's page
     * @param event
     */
    @FXML
	void CityListFunc(MouseEvent event) {
	
		if(CityList.getSelectionModel().getSelectedItem()!=null)
		{
			CityController.CityName=CityList.getSelectionModel().getSelectedItem();
			try {

				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				((Node) event.getSource()).getScene().getWindow().hide(); 
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}


	}
    /**
     * this button works as a handler that closes the current page and returns the user to the home page according to the user's type
     * @param event
     */
	@FXML
	void Home(ActionEvent event) {
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	/**
	 * this method works as a handler after clicking on the new version request button , forwarding the user (employee) to 
	 * a page where he can request a new city version
	 * @param event
	 */
    @FXML
    void NewVersionReqButton(ActionEvent event) {
    	try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/VersionRequestEmp.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    	
    	
    }
    /**
     * this method is used as a handler for clicking the logout button, it logs out the client returning him to the login page
     * and removing him from the list of online users
     * @param event
     */
	@FXML
	void LogOut(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

	/**
	 * this works as a handler for selecting and clicking on one of the listview's maps, it opens a page where the user (employee) 
	 * can link the selected map to a city of his choosing or creating a new city involving this map.
	 * @param event
	 */
	@FXML
	void MapsNotRelatedList(MouseEvent event) {
		MapController.MapName=MapsNotRelatedList.getSelectionModel().getSelectedItem();
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/AddCity.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
	}
	/**
	 * this method works as a handler for a click on the profile button , it forwards the user to his profile page
	 * @param event
	 */
	@FXML
	void Profile(ActionEvent event) {
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/UserProfile.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui
	}
	/**
	 * this method works as a handler for a click on the view message button, it forwards the user to his messages page
	 * @param event
	 */
	   @FXML
	    void viewmessage(ActionEvent event) {
		   try {
   	    	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/MyMessages.fxml"));
   			Scene scene = new Scene(root);
   			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
   			Stage stage = new Stage();
   			stage.setScene(scene);
   			((Node) event.getSource()).getScene().getWindow().hide(); 
   			stage.show();
   			} catch (IOException e) {
   				// TODO Auto-generated catch block
   				e.printStackTrace();
   			}//build the gui
	    }
	   /**
	    * this method works as a handler for a click on the search button, it searches the city's listview for an entered input
	    * @param event
	    */
	@FXML
	void SearchButton(ActionEvent event) {

		if(cities.contains((String)SearchTxt.getText()))
		{
			CityList.setItems(null);
			ObservableList<String> list1;
			list1 = FXCollections.observableArrayList((String)SearchTxt.getText());
			CityList.setItems(list1);
		}

	}
	/**
     * this method is called when the fxml file is loaded, it initializes the variables and some Gui elements.
     */
    
    @FXML
    void initialize() {
    	assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);

		assert SearchTxt != null : "fx:id=\"SearchTxt\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		assert WelcomeLBL != null : "fx:id=\"WelcomeLBL\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		assert SearchBtn != null : "fx:id=\"SearchBtn\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		assert CityList != null : "fx:id=\"CityList\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		toAdd= new CityController();
	
		cities= new ArrayList<String>();
		try {
			Main.getClient().sendToMyCLient("GetCitiesForComboBox");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//incase the job is to get city names for combobox
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list;
		list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
		CityList.setItems(list);
		cities= Main.getClient().getClient().getCityNames();




		assert MapsNotRelatedList != null : "fx:id=\"MapsNotRelatedList\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		mapsNotRelated = new ArrayList<String>();
		try {
			Main.getClient().sendToMyCLient("GetNotRelatedMaps");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//incase the job is to get city names for combobox
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ObservableList<String> list2;
		list2 = FXCollections.observableArrayList(Main.getClient().getClient().getMapsNames());
		MapsNotRelatedList.setItems(list2);

		assert CityLbl != null : "fx:id=\"CityLbl\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		assert LogOut != null : "fx:id=\"LogOut\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		assert Profile != null : "fx:id=\"Profile\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
		assert Home != null : "fx:id=\"Home\" was not injected: check your FXML file 'FirstPageEmployee.fxml'.";
        assert viewmessageBtn != null : "fx:id=\"viewmessageBtn\" was not injected: check your FXML file 'FirstPageCustomer.fxml'.";
        
        assert VersionRequestsBtn != null : "fx:id=\"VersionRequestsBtn\" was not injected: check your FXML file 'FirstPageContentManager.fxml'.";
        assert ViewReports != null : "fx:id=\"ViewReports\" was not injected: check your FXML file 'FirstPageContentManager.fxml'.";

        
        
        
    }
}
