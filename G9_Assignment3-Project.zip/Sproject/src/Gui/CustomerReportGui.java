package Gui;

import java.awt.ScrollPane;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import entities.Customer;
import entities.CustomerOperations;
import entities.Purchase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
/**
*  This class is the GUI controller responsible for showing purchases history of customers
 * @author Anan
 */
public class CustomerReportGui {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;
	@FXML
	private Label CustomerTitle;
	
	@FXML
	private Button LogOutBtn; 

	@FXML
	private Button ProfileBtn; 

	@FXML
	private Button HomeBtn; 

	@FXML
	private ImageView LogoImg; 
	
	@FXML
	private Button ProfileBTN;
	@FXML
	private DatePicker FromDatepicker;

	@FXML
	private DatePicker UntillDatepicker;
	@FXML
	private ComboBox<String> CustomerBox;

	@FXML
	private Button ShowBtn;
	
	/**
	 * This method handles the event where the user chose a customer from the comboBox,
	 * and view his profile.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void ProfileShow(ActionEvent event) {
		Customer SelectedCus=new Customer();
		ArrayList<String> CustomerProfile=new ArrayList<String>();
		CustomerProfile.add("CustomerProfile");
		CustomerProfile.add((String)CustomerBox.getSelectionModel().getSelectedItem().replaceAll(".*,", ""));
		try {
			Main.getClient().getClient().StringsToServer(CustomerProfile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SelectedCus=Main.getClient().getClient().getDetails();
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setContentText("Customer First Name:  " + SelectedCus.getFirstName() + "\n" +
				"Customer Last Name:  " + SelectedCus.getLastName() + "\n" + 
				"Customer Phone Number:  " + SelectedCus.getMobileNum() + "\n" +
				"Customer Email:  " + SelectedCus.geteMail() + "\n" +
				"Customer ID:  " + SelectedCus.getID() + "\n" +
				"Customer Password:  " + SelectedCus.getPassword());
		alert.setTitle(SelectedCus.getFirstName() + " " + "Information:");
		alert.setHeaderText(null);
		alert.showAndWait();
	}

	@FXML
	void CustomerComboWombo(ActionEvent event) {

	}

	/**
	 * This method handles the event where the user chose a customer from the comboBox,
	 * and view his purchase history
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void ShowCusRep(ActionEvent event) throws ParseException {
		ArrayList<String> CustomerInfo=new ArrayList<String>();
		CustomerInfo.add("CustomerInfo");
		CustomerInfo.add((String)CustomerBox.getSelectionModel().getSelectedItem().replaceAll(".*,", ""));
		String FromDate = (FromDatepicker.getValue().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)));
		String UntillDate = (UntillDatepicker.getValue().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT)));		try {
			Main.getClient().getClient().StringsToServer(CustomerInfo);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CustomerOperations Operations=new CustomerOperations();
		Operations=Main.getClient().getClient().getOperations();
		ArrayList<String> CombinedOperations = new ArrayList<String>();
		int i=0;
		int j=0;
		DateFormat formatter = DateFormat.getDateInstance(DateFormat.SHORT,Locale.getDefault());
		Date From = formatter.parse(FromDate);
		Date Untill = formatter.parse(UntillDate);
		//Date From = format.parse(FromDate);
		//Date Untill = format.parse(UntillDate);
		//if(((formatter.parse((Operations.getDateOfPurchase()).get(i)).compareTo(From)) <= 0) || (formatter.parse(((Operations.getDateOfPurchase()).get(i))).compareTo(Untill) >= 0))
         Date firstdate=formatter.parse(((Operations.getDateOfPurchase()).get(i)));
         while(i < Operations.getCityName().size())
		{
			if( (firstdate.compareTo(From) >= 0) && (firstdate.compareTo(Untill) <= 0))
			{
			CombinedOperations.add(j,Operations.getCityName().get(i) + "  " +  Operations.getType().get(i) + "  " + Operations.getDateOfPurchase().get(i));
			CombinedOperations.add("\n");
			j++;
			}
			else {				
			}
			i++;
			if(i<Operations.getCityName().size())
			firstdate=formatter.parse(((Operations.getDateOfPurchase()).get(i)));
		}
		String listString = String.join("\n", CombinedOperations);
		Alert alert = new Alert(AlertType.INFORMATION);
		TextArea area = new TextArea(listString);
		area.setWrapText(true);
		area.setEditable(false);
		alert.getDialogPane().setContent(area);
		alert.setTitle( (String)CustomerBox.getSelectionModel().getSelectedItem() + " " + "Operations:");
		alert.setHeaderText(null);
		alert.showAndWait();
	}
	 /**
     * * This method closes the current window and goes back to the "Home" window, according to the logger's type.
     * @param event
     */
	@FXML
	void HomeBtn(ActionEvent event) {
		if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
	}
	  /**
		 * This method handles the event where the user click on "LogOut" button to log out from the system
		 * @param event
		 */
	@FXML
	void LogOutBtn(ActionEvent event) {// 266
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			( (Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 *  This method closes the current window and goes back to the profile window.
	 * @param event
	 */

	@FXML
	void ProfileBtn(ActionEvent event) { // 266
		try {
			((Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/UserProfile.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	@FXML
	void initialize() {
		assert CustomerBox != null : "fx:id=\"CustomerBox\" was not injected: check your FXML file 'CustomerReport.fxml'.";
		try {
			Main.getClient().sendToMyCLient("GetCustomersNames");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list;
		list = FXCollections.observableArrayList(Main.getClient().getClient().getCustomersNamesIds());
		CustomerBox.setItems(list);//update the ComboxBox with the list of cities 
		new AutoCompleteComboBoxListener<>(CustomerBox);
		assert ShowBtn != null : "fx:id=\"ShowBtn\" was not injected: check your FXML file 'CustomerReport.fxml'.";
		assert ProfileBTN != null : "fx:id=\"ProfileBTN\" was not injected: check your FXML file 'CustomerReport.fxml'.";
		assert FromDatepicker != null : "fx:id=\"FromDatepicker\" was not injected: check your FXML file 'CustomerReport.fxml'.";
		assert UntillDatepicker != null : "fx:id=\"UntillDatepicker\" was not injected: check your FXML file 'CustomerReport.fxml'.";
		FromDatepicker.setValue(LocalDate.now());
		UntillDatepicker.setValue(LocalDate.now());
		assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'CustomerReport.fxml'.";
		assert ProfileBtn != null : "fx:id=\"ProfileBtn\" was not injected: check your FXML file 'CustomerReport.fxml'.";
		assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'CustomerReport.fxml'.";
	    assert LogoImg != null : "fx:id=\"LogoImg\" was not injected: check your FXML file 'CustomerReport.fxml'.";
	/* 266 */ Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
	/* 266 */ LogoImg.setImage(logo);
	}
}
