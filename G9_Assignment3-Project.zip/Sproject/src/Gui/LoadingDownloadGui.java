package Gui;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.DownloadController;
import application.Main;
import entities.DownloadMap;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * this class is used to represent a one time purchase download page for a user. 
 * @author anan & eyal
 *
 */
public class LoadingDownloadGui {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button StartDownload;
    
    @FXML
    private ImageView GcmImage;
    
    @FXML
    private ProgressBar PB;
    /**
     * this method works as a handler in the case that a user has clicked on start download button, it gathers up the data to 
     * be downloaded and then downloads it into his downloads file in his computer
     * @param event
     */
    @FXML
    void StartDownload(ActionEvent event) {
    	PB.setProgress(0.3);
    	try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	DownloadController Downloader=new DownloadController();
    	ArrayList<String> DownloadMyCity = new ArrayList<String>();
        DownloadMyCity.add("DownloadMap");
        DownloadMyCity.add(Downloader.CityToDownload);
    	try {
              Downloader.DownloadMap(DownloadMyCity);
    	} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	PB.setProgress(1);
		DownloadMap gettingmaps=new DownloadMap();
		gettingmaps=Main.getClient().getClient().getTransferdata();
		int i=0;
		int j=0;
		while(i<gettingmaps.getImages().size())
		{
			 byte barr[];
			try {
				String home = System.getProperty("user.home");
				FileOutputStream fout=new FileOutputStream(home+"/Downloads/"+gettingmaps.getMapsnames().get(i)+".jpg");
				fout.write(gettingmaps.getImages().get(i));
				fout.close();
				PrintWriter writer = new PrintWriter(home+"/Downloads/"+gettingmaps.getMapsnames().get(i)+"places.txt", "UTF-8");
				while(j<gettingmaps.getTextfilestrings().size()) {
					writer.println(gettingmaps.getTextfilestrings().get(j));
					j++;
				}
				writer.close();
				i++;
			}  catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
    	Alert alert3 = new Alert(AlertType.INFORMATION);
		alert3.setContentText("Thanks for buying! your purchased map was downloaded!");
		alert3.setTitle("Download Finished!" );
		alert3.setHeaderText(null);
		alert3.showAndWait();

		try {
        	Pane root = FXMLLoader.load(getClass().getResource("/Fxml/MyCities.fxml"));
    		Scene scene = new Scene(root);
    		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
    		Stage stage = new Stage();
    		stage.setScene(scene);
    		stage.show();
    		} catch (IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}//build the gui
		((Node) event.getSource()).getScene().getWindow().hide(); 

    }
    /**
     * this method is called when the fxml file is loaded, it initializes the variables and some Gui elements.
     */
    @FXML
    void initialize() {
        assert PB != null : "fx:id=\"PB\" was not injected: check your FXML file 'LoadingDownload.fxml'.";
        assert StartDownload != null : "fx:id=\"StartDownload\" was not injected: check your FXML file 'LoadingDownload.fxml'.";
        PB.setProgress(0);
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'LoadingDownload.fxml'.";
        Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
    }
}


