package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * This class serves the employee in asking for releasing a new city version.
 * @author Soaad
 *
 */
public class VersionRequestEmpGui {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView GcmImage;

    @FXML
    private Label virsionLbl;

    @FXML
    private ComboBox<String> CityCombo;

    @FXML
    private Label CityNameLbl;

    @FXML
    private Button SendBtn;
    
    @FXML
    private Button LogOutBtn;

    @FXML
    private Button HomeBtn;

    /**
     * this method handles the home button that takes back to the home page according to the logger's type
     * @param event
     */
    @FXML
    void HomeButton(ActionEvent event) {
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
    	catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    
    /**
     * this method handles the logout button that makes the user logs out from the app
     * @param event
     */
    @FXML
    void LogOutButton(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
    	catch(Exception e)
		{
			e.printStackTrace();
		}
    }

    /**
     * this method handles the send button, when the employee clicks on this button the version
     * request will be sent to the manager for confirmation 
     * @param event
     */
    @FXML
    void SendButton(ActionEvent event) {
        if(CityCombo.getSelectionModel().getSelectedItem()!=null)
        {
        	ArrayList<String> toServer= new ArrayList<String>();
        	toServer.add("RequestNewVersion");
        	toServer.add(CityCombo.getSelectionModel().getSelectedItem());	
        	try {
				Main.getClient().getClient().StringsToServer(toServer);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Your request was sent ");
			alert.setTitle("Success");
			alert.setHeaderText(null);
			alert.showAndWait();
        }
        else   
    	{
			Alert alert = new Alert(AlertType.ERROR);
			alert.setContentText("No city was selected! ");
			alert.setTitle("Error");
			alert.setHeaderText(null);
			alert.showAndWait();
    	}
    }
    /**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
    @FXML
    void initialize() {
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'versions.fxml'.";
        Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
        assert virsionLbl != null : "fx:id=\"virsionLbl\" was not injected: check your FXML file 'versions.fxml'.";
        assert CityCombo != null : "fx:id=\"CityCombo\" was not injected: check your FXML file 'versions.fxml'.";
        try {
			Main.getClient().sendToMyCLient("GetCitiesForComboBox");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        ObservableList<String> list;
        
        list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
        CityCombo.setItems(list);
        assert CityNameLbl != null : "fx:id=\"CityNameLbl\" was not injected: check your FXML file 'versions.fxml'.";
        assert SendBtn != null : "fx:id=\"SendBtn\" was not injected: check your FXML file 'versions.fxml'.";

    }
}

