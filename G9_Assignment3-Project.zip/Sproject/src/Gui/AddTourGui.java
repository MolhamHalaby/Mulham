
package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;


import Controller.AddTourController;
import Controller.CityController;
import Controller.LoginController;
import application.Main;
import entities.Tour;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 *  This class is the GUI controller responsible for adding new tours to the DB.
 * @author Molham & Anan
 *
 */
public class AddTourGui {

	Tour newTour; 
	int temp;
	ArrayList<String> placesNames;
	ObservableList<String> items;
	AddTourController addTourController;
	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Label EditTourLbl;

	@FXML
	private Label TourNameLbl;

	@FXML
	private TextField TourNameTxt;

	@FXML
	private Label DescriptionLbl;

	@FXML
	private TextField DescriptionTxt;

	@FXML
	private Label IncludedPlacesLbl;

	@FXML
	private ComboBox<String> PlacesCombo;

	@FXML
	private Button PlusForCombo;

	@FXML
	private ListView<String> PlacesList;

	@FXML
	private Label RecommendedTimeLbl;

	@FXML
	private TextField RecommendedTimeTxt;

	@FXML
	private Button FinishButton;

	@FXML
	private Button CancelButton;

	@FXML
	private ComboBox<String> ToursCombo;

	@FXML
	private Button LogOutBtn;

	@FXML
	private Button HomeBtn;

	@FXML
	private Button BackBtn;

	@FXML
	private Label ChooseTourLbl;

	@FXML
	private Button RemoveBtn;

	@FXML
	private ImageView GcmImage;

	@FXML
	private Button DeleteBtn;

	/**
	 * This method closes the current window and goes back to the previous window.
	 * @param event
	 */
	@FXML
	void BackButton(ActionEvent event) {
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		


		
	}
	/**
	 * This method closes the current window and goes back to the previous window, according to the logger's type.
	 * @param event
	 */
	@FXML
	void CancelBtn(ActionEvent event) {
	
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		

	}
	/**
	 * This method handles the event where the user chose a tour from the comboBox 
	 * and click on "Delete" button.
	 * then the current window closed and go back to the previous window, according to the logger's type.
	 * @param event 
	 */
	@FXML
	void DeleteButton(ActionEvent event) {

		if(ToursCombo.getSelectionModel().getSelectedItem()!=null)
		{
			ArrayList<String> toDelete=new ArrayList<String>();
			toDelete.add("DeleteTour");
			toDelete.add(ToursCombo.getSelectionModel().getSelectedItem());   
			try {
				Main.getClient().getClient().StringsToServer(toDelete);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
	


	}
	/**
	 * This method handles the event where the user chose a tour from the comboBox and click on "finish" button
	 * to save new tour details or changes for existing tour.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void FinishBtn(ActionEvent event) throws IOException {


		newTour=new Tour((String)this.TourNameTxt.getText(),(String)this.DescriptionTxt.getText(),(String)this.RecommendedTimeTxt.getText());
		newTour.setLocations(placesNames);
		newTour.setCityName(CityController.CityName);
		Main.getClient().getClient().AddingNewData(newTour);
		
		try {
			((Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
/**
 * * This method closes the current window and goes back to the "Home" window, according to the logger's type.
 * @param event
 */
	@FXML
	void HomeButton(ActionEvent event) {
		if(LoginController.type.equals("Employee"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}

	}
	/**
	 *  This method handles the event where the user click on "LogOut" button to log out from the system
	 *  and remove the user id from the logged in table in DB
	 * @param event
	 */
	@FXML
	void LogOutButton(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			((Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}


/**
 * This method handles the event where the user click on plus button after he chose place
 *  from the combo box in order to add it to the selected tour
 * @param event
 */
	@FXML
	void PlusFunc(ActionEvent event) {

		if ((String)this.PlacesCombo.getSelectionModel().getSelectedItem()!= null) // eyal 266
		{
			if(!(placesNames.contains((String)this.PlacesCombo.getSelectionModel().getSelectedItem())))
			{
				placesNames.add((String)this.PlacesCombo.getSelectionModel().getSelectedItem());
				if(temp==0)
				{
					items =FXCollections.observableArrayList (placesNames);
					temp=1;
				}
				else
				{
					items =FXCollections.observableArrayList (placesNames);
					//items.add((String)this.PlacesCombo.getSelectionModel().getSelectedItem());
				}
				this.PlacesList.setItems(items);
			}
		}

	}

/**
 * This method handles the event where the user click on remove button after he chose a place from the places list 
 * then the  selected place deleted from the selected tour.
 * @param event
 */
	@FXML
	void RemoveButton(ActionEvent event) {
		if(PlacesList.getSelectionModel().getSelectedItem()!=null)
		{
			placesNames.remove(placesNames.indexOf(PlacesList.getSelectionModel().getSelectedItem()));
			System.out.println(placesNames);
			PlacesList.setItems(null);
			ObservableList<String> list2;
			list2 = FXCollections.observableArrayList(placesNames);
			PlacesList.setItems(list2);

		}
	}
/**
 *  This method handles the event where the user choose tour from the combo box, tour details will appear,
 *  if he choose "new tour" from the combo box he need to enter new details and add places to the new tour.
 * @param event
 */
	@FXML
	void ToursComboFunc(ActionEvent event) {

		ArrayList<String> details=new ArrayList<String>();
		if(ToursCombo.getSelectionModel().getSelectedItem()!="New Tour.."&&ToursCombo.getSelectionModel().getSelectedItem()!=null)
		{
			details.add("getTourDetails");
			details.add(ToursCombo.getSelectionModel().getSelectedItem());
			details.add(LoginController.type);                      ////256
			try {
				Main.getClient().getClient().StringsToServer(details);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			TourNameTxt.setText(ToursCombo.getSelectionModel().getSelectedItem());
			DescriptionTxt.setText(Main.getClient().getClient().getTourDetails().get(0));
			RecommendedTimeTxt.setText(Main.getClient().getClient().getTourDetails().get(1));

			details.clear();
			details.add("getPlacesForTour");
			details.add(ToursCombo.getSelectionModel().getSelectedItem());
			details.add(LoginController.type);        ///256
			try {
				Main.getClient().getClient().StringsToServer(details);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			ObservableList<String> list;
			list = FXCollections.observableArrayList(Main.getClient().getClient().getPlacesNames());
			PlacesList.setItems(list);      
			placesNames=Main.getClient().getClient().getPlacesNames();
		}
		else if(ToursCombo.getSelectionModel().getSelectedItem()=="New Tour..")
		{
			TourNameTxt.setText(null);
			DescriptionTxt.setText(null);
			RecommendedTimeTxt.setText(null);
			PlacesList.setItems(null);
			placesNames.clear();
		}
	}
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	@FXML
	void initialize() throws IOException {
		assert EditTourLbl != null : "fx:id=\"EditTourLbl\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert TourNameLbl != null : "fx:id=\"TourNameLbl\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert TourNameTxt != null : "fx:id=\"TourNameTxt\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert DescriptionLbl != null : "fx:id=\"DescriptionLbl\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert DescriptionTxt != null : "fx:id=\"DescriptionTxt\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert IncludedPlacesLbl != null : "fx:id=\"IncludedPlacesLbl\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert PlacesCombo != null : "fx:id=\"PlacesCombo\" was not injected: check your FXML file 'AddTour.fxml'.";
		temp=0;
		ArrayList<String> places=new ArrayList<String>();
		places.add("GetPlacesNames");
		places.add(CityController.CityName);
		places.add(LoginController.type);             ///256
		Main.getClient().getClient().StringsToServer(places);
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list;
		list = FXCollections.observableArrayList(Main.getClient().getClient().getPlacesNames());
		placesNames=new ArrayList<String>();
		PlacesCombo.setItems(list);//update the ComboxBox with the list of cities
		assert PlusForCombo != null : "fx:id=\"PlusForCombo\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert PlacesList != null : "fx:id=\"PlacesList\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert RecommendedTimeLbl != null : "fx:id=\"RecommendedTimeLbl\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert RecommendedTimeTxt != null : "fx:id=\"RecommendedTimeTxt\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert FinishButton != null : "fx:id=\"FinishButton\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert CancelButton != null : "fx:id=\"CancelButton\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert ToursCombo != null : "fx:id=\"ToursCombo\" was not injected: check your FXML file 'AddTour.fxml'.";
		ArrayList<String> tours=new ArrayList<String>();
		tours.add("GetToursForCity");
		tours.add(CityController.CityName);
		tours.add(LoginController.type);                         ///256
		Main.getClient().getClient().StringsToServer(tours);
		try {
			Thread.currentThread().sleep(500);
		} catch (InterruptedException e) { 
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list2;
		list2 = FXCollections.observableArrayList(Main.getClient().getClient().getToursNames());
		list2.add("New Tour..");
		ToursCombo.setItems(list2);


		assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert BackBtn != null : "fx:id=\"BackBtn\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert ChooseTourLbl != null : "fx:id=\"ChooseTourLbl\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert RemoveBtn != null : "fx:id=\"RemoveBtn\" was not injected: check your FXML file 'AddTour.fxml'.";
		assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'AddTour.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
		assert DeleteBtn != null : "fx:id=\"DeleteBtn\" was not injected: check your FXML file 'AddTour.fxml'.";
	}
}
