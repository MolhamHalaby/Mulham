package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.AddCityController;
import Controller.CityController;
import Controller.FirstPageEmployeeController;
import Controller.LoginController;
import Controller.MapController;
import Controller.ReportController;
import application.Main;
import entities.City;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * This class is the GUI controller responsible for relating maps to existing cities 
 * and also to new cities. 
 * @author Molham + Eyal
 * 
 */
public class AddCityGui {

	String cityToAdd;
	ReportController reportController;
	AddCityController cityNew;
	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private TextField NewCityName;

	@FXML
	private Button AddCityBtn;

	@FXML
	private Label CityNameLbl;

	@FXML
	private Button CancelBtn;

	@FXML
	private ImageView GcmImage;

	@FXML
	private ComboBox<String> citiesCombo;

	@FXML
	private Button LogOutBtn;

	@FXML
	private Button homeBtn;

	@FXML
	private Button profileBtn;


	@FXML
	private Button nextBtn;
	/**
	 * This method handles the event where the user chose a city from the comboBox if the user choose "New City" 
	 * he should enter new city name and clicked next.
	 * @param event 
	 */
	@FXML
	void NextButton(ActionEvent event) {
		if(NewCityName.isVisible()==false&&citiesCombo.getSelectionModel().getSelectedItem()!=null)
		{
			if((String)this.NewCityName.getText()!=null)
			{
				cityToAdd=new String(citiesCombo.getSelectionModel().getSelectedItem());
				CityController.CityName=citiesCombo.getSelectionModel().getSelectedItem();
				try {
					cityNew.AddCity(cityToAdd);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


			}

		}
		try {
			((Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);

			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	}

	/**
	 * This method handles the event where the user chose "New City" from the comboBox,
	 *  text field and Add button will appear, then the user should enter new city name.
	 * @param event
	 */
	@FXML
	void citiesCombo(ActionEvent event) {

		String newCity= new String();
		if (citiesCombo.getSelectionModel().getSelectedItem()!=null)
		{
			newCity=(String)citiesCombo.getSelectionModel().getSelectedItem();
			if (newCity.equals("New City..."))
			{
				NewCityName.setVisible(true);
				AddCityBtn.setVisible(true);


			}
			else
			{
				NewCityName.setVisible(false);
				AddCityBtn.setVisible(false);
				CityController.CityName=(String)citiesCombo.getSelectionModel().getSelectedItem();

			}
		}

	}
	/**
	 * This method handles the event where the user chose "New City" from the comboBox,and after he enter a new city name 
	 * and click on "add" button to add new city to the DB. 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void AddCityBtn(ActionEvent event) throws IOException {


		if((String)this.NewCityName.getText()!=null)
		{
			cityToAdd=new String((String)this.NewCityName.getText());
			CityController.CityName=NewCityName.getText();
			cityNew.AddCity(cityToAdd);


		}
		else
		{
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Please enter a new city name to add!");
			alert.setTitle("Information");
			alert.getDialogPane().setPrefSize(300, 150);
			alert.setHeaderText(null);
			alert.showAndWait();
		}


	}
	/**
	 * This method handles the event where the user click on "LogOut" button to log out from the system
	 * @param event
	 */
	@FXML
	void LogOutBtn(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			((Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 *  This method closes the current window and goes back to the home window, according to the logger's type.
	 * @param event
	 */
	@FXML
	void homeBtn(ActionEvent event) {

		if(LoginController.type.equals("Employee"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}

	}
	/**
	 *  This method closes the current window and goes back to the profile window.
	 * @param event
	 */
	@FXML
	void profileBtn(ActionEvent event) {
		try {
			((Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/UserProfile.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	/**
	 * This method closes the current window and goes back to the previous window.
	 * @param event
	 */

	@FXML
	void btnCancel(ActionEvent event) {


		if(LoginController.type.equals("Employee"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
	}
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	@FXML
	void initialize() {
		assert NewCityName != null : "fx:id=\"NewCityName\" was not injected: check your FXML file 'AddCity.fxml'.";
		assert AddCityBtn != null : "fx:id=\"AddCityBtn\" was not injected: check your FXML file 'AddCity.fxml'.";
		assert CityNameLbl != null : "fx:id=\"CityNameLbl\" was not injected: check your FXML file 'AddCity.fxml'.";
		assert CancelBtn != null : "fx:id=\"CancelBtn\" was not injected: check your FXML file 'AddCity.fxml'.";
		assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'AddCity.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
		cityNew=new AddCityController();
		assert citiesCombo != null : "fx:id=\"citiesCombo\" was not injected: check your FXML file 'AddCity.fxml'.";
		reportController=new ReportController();
		reportController.GetCityComboBox();
		ObservableList<String> list;
		list = FXCollections.observableArrayList(Main.getClient().getClient().getCityNames());
		String newCity=new String("New City...");
		list.add(newCity);
		citiesCombo.setItems(list);//update the ComboxBox with the list of cities 

		assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'AddCity.fxml'.";
		assert homeBtn != null : "fx:id=\"homeBtn\" was not injected: check your FXML file 'AddCity.fxml'.";
		assert profileBtn != null : "fx:id=\"profileBtn\" was not injected: check your FXML file 'AddCity.fxml'.";
		assert nextBtn != null : "fx:id=\"nextBtn\" was not injected: check your FXML file 'AddCity.fxml'.";
	}
}