package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.LoginController;
import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * This class is the GUI controller responsible for showing types of reports 
 * user can choose one of this reports to view according to his desire. 
 * @author Anan & Sahar
 *
 */
public class ChooseReportGui {               ////266 adding buttons + logo

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    private Label ReportsLbl;

    @FXML
    private RadioButton CityRadio;

    @FXML
    private RadioButton CustomerRadio;

    @FXML
    private Button MoveButton;

    @FXML
    private Button CancelButton;

    @FXML
    private RadioButton DailyReportBTN;
    

    @FXML
    private ImageView GcmImage;

    @FXML
    private Button LogOutBtn;

    @FXML
    private Button HomeBtn;

    /**
     * This method closes the current window and goes back to the previous window, according to the logger's type.
     * @param event
     */

    @FXML
    void CancelBtn(ActionEvent event) {
    	if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
    	
    	
    }
    
    /**
	 * This method handles the event where the user choose to view a city report
	 * @param event
	 */
    @FXML
    void CityRad(ActionEvent event) {
        DailyReportBTN.setSelected(false);
        CustomerRadio.setSelected(false);
    }
    /**
	 * This method handles the event where the user choose to view a customers report
	 * @param event
	 */
    @FXML
    void CusRad(ActionEvent event) {
        DailyReportBTN.setSelected(false);
        CityRadio.setSelected(false);
    }
    /**
	 * This method handles the event where the user choose to view a daily report
	 * @param event
	 */
    @FXML
    void DailyReportRad(ActionEvent event) {
    	CustomerRadio.setSelected(false);
    	CityRadio.setSelected(false);
    }
    
    /**
     * * This method closes the current window and goes back to the "Home" window, according to the logger's type.
     * @param event
     */
    @FXML
    void HomeButton(ActionEvent event) {
   	
		if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
    }

	/**
	 *  This method handles the event where the user click on "LogOut" button to log out from the system
	 *  and remove the user id from the logged in table in DB
	 * @param event
	 */
    @FXML
    void LogOutButton(ActionEvent event) {
    	ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	try {
			((Node) event.getSource()).getScene().getWindow().hide(); 
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }
    /**
	 * This method handles the event where the user chose one of the reports 
	 * and click on "move" button to show the selected report
	 * @param event 
	 */
    @FXML
    void MoveBtn(ActionEvent event) {
    if(CityRadio.isSelected())
    {
    	try {
	        ((Node) event.getSource()).getScene().getWindow().hide(); 
	        Pane root = FXMLLoader.load(getClass().getResource("/Fxml/ReportGui.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
	        }
	        catch(Exception e)
	        {
				e.printStackTrace();

	        }
    }
    if(DailyReportBTN.isSelected()) {
   
    		try {
	        ((Node) event.getSource()).getScene().getWindow().hide(); 
	        Pane root = FXMLLoader.load(getClass().getResource("/Fxml/DailyReport.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.show();
    		  }
	        catch(Exception e)
	        {
				e.printStackTrace();

	        }
    	}
    if(CustomerRadio.isSelected()) {
    	   
		try {
        ((Node) event.getSource()).getScene().getWindow().hide(); 
        Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CustomerReport.fxml"));//build the gui
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
		Stage stage = new Stage();
		stage.setScene(scene);
		stage.show();
		  }
        catch(Exception e)
        {
			e.printStackTrace();

        }
	}
    }
  
    /**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
    @FXML
    void initialize() {
        assert ReportsLbl != null : "fx:id=\"ReportsLbl\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
        assert CityRadio != null : "fx:id=\"CityRadio\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
        assert CustomerRadio != null : "fx:id=\"CustomerRadio\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
        assert MoveButton != null : "fx:id=\"MoveButton\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
        assert CancelButton != null : "fx:id=\"CancelButton\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
        assert DailyReportBTN != null : "fx:id=\"DailyReportBTN\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
        assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
    	Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
        assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
        assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'ChooseReportGui.fxml'.";
       
    }
}
