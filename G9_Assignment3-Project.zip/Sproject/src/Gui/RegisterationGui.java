package Gui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import Controller.RegisterationController;
import application.Main;
import entities.Customer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * This class for the registration page 
 * @author Eyal + Anan
 *
 */
public class RegisterationGui {

	Customer ToAdd;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Label FNameLbl;

	@FXML
	private Label LNameLbl;

	@FXML
	private Label CreditCardLbl;

	@FXML
	private TextField CreditCardTXT;

	@FXML
	private Label IDLbl;

	@FXML
	private Label EmailLbl;

	@FXML
	private Label MobileLbl;

	@FXML
	private Label PasswordLbl;

	@FXML
	private TextField FNametxt;

	@FXML
	private TextField LNameTxt;

	@FXML
	private TextField IDtxt;

	@FXML
	private TextField EmailTxt;

	@FXML
	private TextField MobileTxt;

	@FXML
	private TextField PasswordTxt;

	@FXML
	private Button CancelBtn;

	@FXML
	private Button FinishBtn;

	@FXML
	private ImageView GcmImage;
/**
 * this method handles the cancel button, for canceling the registration operation 
 * @param event
 */
	@FXML
	void CancelButton(ActionEvent event) {
		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//build the gui    }
	}
	/**
	 * this method handles the finish button, for finishing the registration operation 
	 * after that the user will be registered
	 * @param event
	 */
	@FXML
	void FinishButton(ActionEvent event) throws IOException {

		ToAdd=new Customer((String)this.IDtxt.getText(),(String)this.FNametxt.getText(),(String)this.LNameTxt.getText(),
				(String)this.EmailTxt.getText(),(String)this.MobileTxt.getText(),(String)this.PasswordTxt.getText(),(String)this.CreditCardTXT.getText());
		RegisterationController newCust= new RegisterationController();
		newCust.newCustomer(ToAdd);
		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	@FXML
	void initialize() {
		assert FNameLbl != null : "fx:id=\"FNameLbl\" was not injected: check your FXML file 'Untitled'.";
		assert LNameLbl != null : "fx:id=\"LNameLbl\" was not injected: check your FXML file 'Untitled'.";
		assert IDLbl != null : "fx:id=\"IDLbl\" was not injected: check your FXML file 'Untitled'.";
		assert EmailLbl != null : "fx:id=\"EmailLbl\" was not injected: check your FXML file 'Untitled'.";
		assert MobileLbl != null : "fx:id=\"MobileLbl\" was not injected: check your FXML file 'Untitled'.";
		assert PasswordLbl != null : "fx:id=\"PasswordLbl\" was not injected: check your FXML file 'Untitled'.";
		assert FNametxt != null : "fx:id=\"FNametxt\" was not injected: check your FXML file 'Untitled'.";
		assert LNameTxt != null : "fx:id=\"LNameTxt\" was not injected: check your FXML file 'Untitled'.";
		assert IDtxt != null : "fx:id=\"IDtxt\" was not injected: check your FXML file 'Untitled'.";
		assert EmailTxt != null : "fx:id=\"EmailTxt\" was not injected: check your FXML file 'Untitled'.";
		assert MobileTxt != null : "fx:id=\"MobileTxt\" was not injected: check your FXML file 'Untitled'.";
		assert PasswordTxt != null : "fx:id=\"PasswordTxt\" was not injected: check your FXML file 'Untitled'.";
		assert CreditCardLbl != null : "fx:id=\"CreditCardLbl\" was not injected: check your FXML file 'Untitled'.";
		assert CreditCardTXT != null : "fx:id=\"CreditCardTXT\" was not injected: check your FXML file 'Untitled'.";
		assert CancelBtn != null : "fx:id=\"CancelBtn\" was not injected: check your FXML file 'Untitled'.";
		assert FinishBtn != null : "fx:id=\"FinishBtn\" was not injected: check your FXML file 'Untitled'.";
		assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'Registeration.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
	}
}

