package Gui;


import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Controller.EditPlaceController;
import Controller.LoginController;
import Controller.CityController;
import application.Main;
import entities.Place;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * This class is the GUI controller responsible for edit/add places to the selected city
 * @author Soaad & Sahar & Anan
 * 
 */

public class EditPlaceGui {

	EditPlaceController placeToADD;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Label EditPlaceLabel;

	@FXML
	private Label ExistingPlaceLbl;

	@FXML
	private Label DescriptionLabel;

	@FXML
	private Label ClassificationLabel;

	@FXML
	private TextField DescriptionTxt;

	@FXML
	private TextField ClassificationTxt;

	@FXML
	private Label AccessibleLabel;

	@FXML
	private RadioButton YesRadio;

	@FXML
	private Label TimeOfVisitLabel;

	@FXML
	private TextField TimeOfVisittxt;

	@FXML
	private Button FinishBtn;

	@FXML
	private Button CancelBtn;

	@FXML
	private ComboBox<String> PlaceCombo;

	@FXML
	private Button LogOutBtn;

	@FXML
	private Button HomeBtn;

	@FXML
	private Button BackBtn;

	@FXML
	private ImageView GcmImage;

	@FXML
	private TextField PlaceNameTxt;

	@FXML
	private Label PlaceNameLbl;

	@FXML
	private Button DeleteBtn;
	/**
	 * This method closes the current window and goes back to the previous window, according to the logger's type
	 * @param event
	 */
	@FXML
	void BackButton(ActionEvent event) {

			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
		

	}

	/**
	 * This method closes the current window and goes back to the Home page, according to the logger's type
	 * @param event
	 */
	@FXML
	void HomeButton(ActionEvent event) {
		if(LoginController.type.equals("Employee"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageEmployee.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Manager"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageContentManager.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else if(LoginController.type.equals("Big Boss"))
		{
			try {
				((Node) event.getSource()).getScene().getWindow().hide(); 
				Pane root = FXMLLoader.load(getClass().getResource("/Fxml/FirstPageBigBoss.fxml"));//build the gui
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				Stage stage = new Stage();
				stage.setScene(scene);
				stage.show();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
	}
	/**
	 * This method handles the event where the user click on "LogOut" button to log out from the system
	 * @param event
	 */
	@FXML
	void LogOutButton(ActionEvent event) {
		ArrayList<String> logoutsender= new ArrayList<String>();
		logoutsender.add("LogOutClient");
		logoutsender.add(LoginController.id);
		try {
			Main.getClient().getClient().StringsToServer(logoutsender);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {

			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/Login.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * This method handles the event where the user chose one of the places from the comboBox,
	 *  user can edit the details of the selected place.
	 *  user can choose "addplace" from the combo box and add new place to the selected city.
	 * @param event
	 */
	@FXML
	void PlaceComboFunc(ActionEvent event) {

		EditPlaceController.previousName=PlaceCombo.getSelectionModel().getSelectedItem();
		if(!(PlaceCombo.getSelectionModel().getSelectedItem().equals("NewPlace")))
		{
			if(PlaceCombo.getSelectionModel().getSelectedItem()!= null) // eyal 266
			{
				placeToADD.GetPLaceDetails(PlaceCombo.getSelectionModel().getSelectedItem());

				PlaceNameTxt.setText(Main.getClient().getClient().getPdetails().getLocName());
				DescriptionTxt.setText(Main.getClient().getClient().getPdetails().getLocDescription());
				ClassificationTxt.setText(Main.getClient().getClient().getPdetails().getLocType());
				TimeOfVisittxt.setText(Main.getClient().getClient().getPdetails().getSumRecommendedTime());
				YesRadio.setSelected(Main.getClient().getClient().getPdetails().getSpecial());
			}
		}

	}

	/**
	 * This method closes the current window and goes back to the previous window, according to the logger's type
	 * @param event
	 */
	@FXML
	void CancelButton(ActionEvent event) {
		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		} 
	}
	/**
	 * This method handles the event where the user chose a place from the comboBox 
	 * and click on "Delete" button.
	 * then the current window closed and go back to the previous window.
	 * @param event 
	 */
	@FXML
	void DeleteButton(ActionEvent event) {

		if(PlaceCombo.getSelectionModel().getSelectedItem()!=null)
		{
			ArrayList<String> toDelete=new ArrayList<String>();
			toDelete.add("DeletePlace");
			toDelete.add(PlaceCombo.getSelectionModel().getSelectedItem());   
			try {
				Main.getClient().getClient().StringsToServer(toDelete);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	/**
	 * This method handles the event where the user chose a place from the comboBox 
	 * and click on "Finish" button.
	 * changes will be saved on DB
	 * then the current window closed and go back to the previous window.
	 * @param event 
	 */
	@FXML
	void FinishButton(ActionEvent event) throws IOException {
		if(PlaceCombo.getSelectionModel().getSelectedItem().equals("NewPlace"))
		{
			Place newPlace=new Place((String)this.PlaceNameTxt.getText(),(String)this.ClassificationTxt.getText(),(String)this.DescriptionTxt.getText(),
					(boolean)this.YesRadio.isSelected(),(String)this.TimeOfVisittxt.getText());
			newPlace.setCityName(CityController.CityName);
			placeToADD.addPlace(newPlace);
		}
		else
		{

			Place newPlace=new Place((String)this.PlaceNameTxt.getText(),(String)this.ClassificationTxt.getText(),(String)this.DescriptionTxt.getText(),
					(boolean)this.YesRadio.isSelected(),(String)this.TimeOfVisittxt.getText());
			newPlace.setCityName(CityController.CityName);
			placeToADD.UpdatePlace(newPlace);


		}

		try {
			Pane root = FXMLLoader.load(getClass().getResource("/Fxml/CityEmployee.fxml"));//build the gui
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
			Stage stage = new Stage();
			stage.setScene(scene);
			((Node) event.getSource()).getScene().getWindow().hide(); 
			stage.show();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	/**
	 * This method is called when the FXML file is loaded, it initializes the
	 * variables and some GUI elements.
	 */
	@FXML
	void initialize() {
		assert EditPlaceLabel != null : "fx:id=\"EditPlaceLabel\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert ExistingPlaceLbl != null : "fx:id=\"ExistingPlaceLbl\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert DescriptionLabel != null : "fx:id=\"DescriptionLabel\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert ClassificationLabel != null : "fx:id=\"ClassificationLabel\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert DescriptionTxt != null : "fx:id=\"DescriptionTxt\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert ClassificationTxt != null : "fx:id=\"ClassificationTxt\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert AccessibleLabel != null : "fx:id=\"AccessibleLabel\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert YesRadio != null : "fx:id=\"YesRadio\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert TimeOfVisitLabel != null : "fx:id=\"TimeOfVisitLabel\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert TimeOfVisittxt != null : "fx:id=\"TimeOfVisittxt\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert FinishBtn != null : "fx:id=\"FinishBtn\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert CancelBtn != null : "fx:id=\"CancelBtn\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert PlaceCombo != null : "fx:id=\"PlaceCombo\" was not injected: check your FXML file 'AddPlace.fxml'.";
		ArrayList<String> toServer=new ArrayList<String>();
		toServer.add("GetPlacesForThisCity");
		toServer.add(CityController.CityName);
		toServer.add(LoginController.type);                 /////256
		try {
			Main.getClient().getClient().StringsToServer(toServer);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//incase the job is to get city names for combobox
		try {
			Thread.currentThread().sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObservableList<String> list;
		list = FXCollections.observableArrayList(Main.getClient().getClient().getPlacesNames());
		list.add("NewPlace");
		PlaceCombo.setItems(list);//update the ComboxBox with the list of cities 
		new AutoCompleteComboBoxListener<>(PlaceCombo);
		placeToADD= new EditPlaceController();
		assert LogOutBtn != null : "fx:id=\"LogOutBtn\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert HomeBtn != null : "fx:id=\"HomeBtn\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert BackBtn != null : "fx:id=\"BackBtn\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert GcmImage != null : "fx:id=\"GcmImage\" was not injected: check your FXML file 'AddPlace.fxml'.";
		Image logo= new Image(getClass().getResourceAsStream("/Img/Logo.png"));
		GcmImage.setImage(logo);
		assert PlaceNameTxt != null : "fx:id=\"PlaceNameTxt\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert PlaceNameLbl != null : "fx:id=\"PlaceNameLbl\" was not injected: check your FXML file 'AddPlace.fxml'.";
		assert DeleteBtn != null : "fx:id=\"DeleteBtn\" was not injected: check your FXML file 'EditPlace.fxml'.";
	}
}

