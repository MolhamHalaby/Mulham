package Controller;

import java.io.IOException;

import application.Main;
/**
 * This class is for getting places for new tour in the comboBox
 * @author Eyal
 *
 */
public class AddTourController {

	public void GetPlacesForTour() throws IOException
	{
		  Main.getClient().sendToMyCLient("GetPlacesForNewTour");//incase the job is to get city names for combobox
	        try {
				Thread.currentThread().sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	}
	
	
	
}
