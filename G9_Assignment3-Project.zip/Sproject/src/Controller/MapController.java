package Controller;

/**
 * This class is for saving the maps names 
 * @author Eyal
 *
 */
public class MapController {
	public static String MapName;

	public static String getMapName() {
		return MapName;
	}

	public static void setMapName(String mapName) {
	    MapName = mapName;
	} 
}
