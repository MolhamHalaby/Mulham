
package Controller;

import java.io.IOException;
import application.Main;
import entities.City;
/**
 * This class is for saving the map's name for the related city and sending it to the server in order to save 
 * the info in the DB.
 * @author Eyal
 *
 */
public class AddCityController {
     
	public static String newCity;
	/**
	 * This method is called for saving map's name and the related city and then send it to the server.
	 * @param City name  
	 * @throws IOException
	 */
	public void AddCity(String name) throws IOException
	{
		City toAdd=new City(name);
		toAdd.getMaps().add(MapController.MapName);
		toAdd.setNumOfMaps(1);
	   	 Main.getClient().getClient().AddingNewData(toAdd);
	}
}
