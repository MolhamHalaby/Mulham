package Controller;
/**
 * This class is for saving the city's name, and when we 
 * move to the city's page the title will auto complete the text from this controller.
 * @author Eyal
 *
 */
public class CityController {
public static String CityName;

public CityController()
{
	CityName=new String();
}

public static String getCityName() {
	return CityName;
}

public static void setCityName(String cityName) {
	CityName = cityName;
} 
}