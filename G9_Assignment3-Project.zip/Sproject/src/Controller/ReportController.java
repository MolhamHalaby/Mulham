package Controller;

import java.io.IOException;
import java.util.ArrayList;

import application.Main;
/**
 * This class is for getting the cities reports from DB
 * @author Sahar
 *
 */
public class ReportController {
	/**
	 * This method is for getting the cities list for the comboBox
	 */
	public void GetCityComboBox()
	{
	    try {
				Main.getClient().sendToMyCLient("GetCitiesForComboBox");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}//incase the job is to get city names for combobox
	         try {
	 			Thread.currentThread().sleep(2000);
	 		} catch (InterruptedException e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}	
	}
	/**
	 * This method is for getting the cities reports form DB
	 * @param cityName
	 */
	public void GetCityReport(String cityName)
	{
		ArrayList<String> CityForReport=new ArrayList<String>();
		CityForReport.add("GetCityReport");
    	CityForReport.add(cityName);//gets the selected city
    	
    	try {
    		Main.getClient().getClient().StringsToServer(CityForReport);
    	} catch (IOException e1) {
    		// TODO Auto-generated catch block
    		e1.printStackTrace();
    	}
    	try {
    		Thread.currentThread().sleep(1000);
    	} catch (InterruptedException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
	}	
}
