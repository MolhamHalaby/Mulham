package Controller;

import java.io.IOException;
import java.util.ArrayList;
import application.Main;
import entities.Place;

/**
 * This class saves the city's name that will be downloaded and send it to the server.
 * @author Eyal
 *
 */
public class DownloadController {
	
	public static String CityToDownload;
	
	public DownloadController()
	{	
	}
	
	public void DownloadMap(ArrayList<String> Strings) throws IOException
	{
	   	 Main.getClient().getClient().StringsToServer(Strings);
	}
}