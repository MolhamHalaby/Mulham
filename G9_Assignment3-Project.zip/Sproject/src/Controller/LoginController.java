package Controller;

import java.io.IOException;
import java.util.ArrayList;

import application.Main;
import entities.Place;
/**
 * This class is for saving the logger's ID and type while login operation
 * @author Eyal
 *
 */
public class LoginController {
	
	public static String id;
	public static String type;
	
	public LoginController()
	{
	}
	/**
	 * This method is for saving the loggers info in the DB
	 * @param Strings
	 * @throws IOException
	 */
	public void login(ArrayList<String> Strings) throws IOException
	{
	   	 Main.getClient().getClient().StringsToServer(Strings);
	}
}