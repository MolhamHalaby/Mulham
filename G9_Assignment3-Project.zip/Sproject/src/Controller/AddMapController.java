package Controller;

import java.io.IOException;

import application.Main;
import entities.Map;

/**
 * This class is for sending the new Map entity to the server. 
 * @author Eyal
 *
 */
public class AddMapController {
/**
 * This method receives new map entity and send it to the server for saving in the DB. 
 * @param Map 
 * @throws IOException
 */
	public void addMap(Map newM) throws IOException
	{
	   	 Main.getClient().getClient().AddingNewData(newM);
		
	}
	
	
}
