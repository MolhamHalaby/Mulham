package Controller;
/**
 * This class is for saving the name of the map not related 
 * @author Eyal
 *
 */
public class FirstPageEmployeeController {

	public static String MapNotRelate;
	public static String CityClicked;
	
	
	public FirstPageEmployeeController()
	{
	}


	public static String getMapNotRelate() {
		return MapNotRelate;
	}


	public static void setMapNotRelate(String mapNotRelate) {
		MapNotRelate = mapNotRelate;
	}


	public static String getCityClicked() {
		return CityClicked;
	}


	public static void setCityClicked(String cityClicked) {
		CityClicked = cityClicked;
	}
	
}
