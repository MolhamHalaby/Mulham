package Controller;

import java.io.IOException;
import java.util.ArrayList;

import application.Main;
import entities.City;
import entities.Place;

/**
 * This class is for controlling the places information 
 * @author Eyal
 *
 */

public class EditPlaceController {
 
	public static String previousName;
	
	/**
	 * This method is for adding new place to the DB 
	 * @param new place
	 * @throws IOException
	 */
	
	public void addPlace(Place newP) throws IOException
	{ 
		Main.getClient().getClient().AddingNewData(newP);
		  try {
	 			Thread.currentThread().sleep(1000);
	 		} catch (InterruptedException e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
	}
	/**
	 * This method is for updating the place in the DB
	 * @param place
	 * @throws IOException
	 */
	public void UpdatePlace(Place place) throws IOException
	{ 	 
		Main.getClient().getClient().UpdatePlace(place);
		  try {
	 			Thread.currentThread().sleep(1000);
	 		} catch (InterruptedException e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
	}
	/**
	 * This method is for getting the place's information from the DB
	 * @param name
	 */
	public void GetPLaceDetails(String name)
	{
		ArrayList<String> getPlaces=new ArrayList<String>();
		try {
			getPlaces.add("GetPlaceDetails");
			getPlaces.add(name);
			getPlaces.add(LoginController.type);                       
			Main.getClient().getClient().StringsToServer(getPlaces);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  try {
	 			Thread.currentThread().sleep(1000);
	 		} catch (InterruptedException e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
	}
}
